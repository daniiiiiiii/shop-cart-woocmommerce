<?php 

namespace cx_cpo;

if ( !class_exists("\\cx_cpo\\cx_base_taxonomy")) { 
	
	class cx_base_taxonomy extends cx_base {
		
		
		protected $object_type = [];


		// attes
		protected $taxonomy_attribute_list = [];

		protected $name_display ="";
		protected $labels = [];
		
		protected $register_attrs = [];
		protected $form_wraper = "";

		protected $taxonomy_name = "";

		private $labels_default = [];
		private $labels_list = [
			'name',
			'singular_name',
			'menu_name',
			'all_items',
			'parent_item',
			'parent_item_colon',
			'new_item_name',
			'add_new_item',
			'edit_item',
			'update_item',
			'separate_items_with_commas',
			'search_items',
			'add_or_remove_items',
			'choose_from_most_used',
		];

		protected $posthandler;


		private $default_register_attrs= [
			'hierarchical' => TRUE,
			'public' => TRUE,
			'show_ui' => TRUE,
			'show_admin_column' => TRUE,
			'show_in_nav_menus' => TRUE,
			'show_tagcloud' => TRUE,
			'has_archive'       =>  TRUE,

		];

		public function setup_attributes() {
			$this->taxonomy_attribute_list = $this->attributes();
		}
		private $object_type_default = ["post"];
		
		function __construct(){

			parent::__construct();


			add_action("wp_loaded", [$this,"setup_attributes"]);

			//$this->taxonomy_attribute_list = $this->attributes();

			$this->render_helper = $this->helper("render");
			
			$called_class = get_called_class();
			$called_class_expd  = explode("\\", $called_class);
			$actual_name_last = $called_class_expd[ count($called_class_expd) - 1 ];
			$actual_name = $this->get_plugin_namespace() . "_" . $actual_name_last;

			$this->class_actual_name = $actual_name_last;


			if ( strlen($actual_name) > 20 ) {

				$actual_name = explode("_", $actual_name);
				$actual_name = $actual_name[0] . "_" . $actual_name[2];

			}

			if ( strlen($actual_name) > 20 ) {

				$actual_name = explode("_", $actual_name);
				$actual_name = $actual_name[1];

			}
			if ( strlen($actual_name) > 20 ) {
				$actual_name = substr($actual_name, 0, 20);
				
			}



			// setting up taxonomy_name
			if ( !strlen($this->taxonomy_name) ){
				$this->taxonomy_name = $actual_name;
			}
			if ( !strlen($this->name_display) ) {
				$this->name_display = $actual_name;

			}
			
			/*
				setting up labels
			*/
			$taxonomy_name = $this->name_display;

			$this->labels_default = [
				'name'                       => __("$taxonomy_name" .'s',"xwt"),
		        'singular_name'              => __("$taxonomy_name","xwt"),
		        "menu_name"                  => __("$taxonomy_name" .'s',"xwt"),
		        "all_items"                  => __("All $taxonomy_name","xwt"),
		        "parent_item"                => __("Parent $taxonomy_name","xwt"),
		        "parent_item_colon"          => __("Parent $taxonomy_name","xwt"),
		        "new_item_name"              => __("New $taxonomy_name Name","xwt"),
		        "add_new_item"               => __("Add New $taxonomy_name","xwt"),
		        "edit_item"                  => __("Edit $taxonomy_name","xwt"),
		        "update_item"                => __("Update $taxonomy_name","xwt"),
		        "separate_items_with_commas" => __("Separate $taxonomy_name with commas","xwt"),
		        "search_items"               => __("Search $taxonomy_name","xwt"),
		        "add_or_remove_items"        => __("Add or remove $taxonomy_name","xwt"),
		        "choose_from_most_used"      => __("Choose from the most populat $taxonomy_name","xwt"),
				
			];

			foreach ($this->labels_list as $label) {
				if ( !isset($this->labels[$label]) ) {
					$this->labels[$label] = $this->labels_default[$label];
				}
			}

			
			// support default
			if ( !count($this->object_type )) {
				$this->object_type = $this->object_type_default;
			}

			foreach ($this->default_register_attrs as $key => $value) {
				if ( !isset($this->register_attrs[$key]) ) {
					$this->register_attrs[$key] = $value;
				}
			}
			

			$default_attr_attr = [
				"show_in_admin_gird"	=>0,
		        "show_in_admin_edit"	=>1,
			];
			
			// add defualt vals to attrs
			foreach ($this->taxonomy_attribute_list as $key => $attr) {
				foreach ($default_attr_attr as $attr_key => $default_value) {
					if ( !isset($attr[$attr_key]) ){
						$this->taxonomy_attribute_list[$key][$attr_key] = $default_value;
					}
				}
			}
			// if ( !strlen($this->form_post_wraper) ) {
			// 	$this->form_post_wraper = "";
			// }


			//add_action( 'manage_'.$this->taxonomy_name.'_posts_custom_column', [$this,"custom_column_content"],10,3);
			//add_filter( 'manage_edit-'.$this->taxonomy_name.'_columns', [$this,"custom_column_header"], 10, 2);

			add_action( 'init', [$this,"register_taxonomy"]);
			
			

			
			//add_action( $this->taxonomy_name . '_add_form', [$this,"render_taxonomy_attributes"] , 10, 2);
			add_action( $this->taxonomy_name . '_add_form_fields', [$this,"render_taxonomy_attributes"] , 10, 2);

			// edit page 
			add_action( $this->taxonomy_name . '_edit_form', [$this,"render_taxonomy_attributes"] , 10, 2);



			add_action( 'edited_' . $this->taxonomy_name , [$this,"save_taxonomy_attrs"], 10, 2 );
			add_action( 'created_' . $this->taxonomy_name , [$this,"save_taxonomy_attrs"], 10, 2 );

			add_action( 'delete_' . $this->taxonomy_name , [$this,"delete_taxonomy_attrs"], 10, 2 );
			add_action( 'admin_notices', array( $this, '_admin_notices' ) );


			//add_filter( 'wp_insert_post_data', [$this,"_insert_post_data"] );


		
			$this->set_up_styles_scripts_base();

			$this->set_up_post_handlers();
			foreach(glob(__DIR__  . "/../". get_called_class().  "/controllers/*.php") as $file){
    
			    require_once($file);
			    
			}


			add_filter( 'template_include',[$this,"_template_include"] );

		}
		protected function taxonomy_save_notices() {

		}
		protected function delete_additional_taxonomy_attrs($term_id,$taxonomy_term_id) {

		}
		// for adding customer meta boxs on override
		protected function render_additional_meta_box($p,$args) {

		}
		// for adding customer meta boxs on override
		protected function save_additional_taxonomy_attrs($pid, $p, $post) {

		}
		// for adding customer meta boxs on override
		protected function taxonomy_additional_metaboxes() {

		}
		// for adding customer meta boxs on override
		
		protected function custom_column_additional_content($cols) {

		}

		protected function set_up_styles_scripts(){

			
		}
		
		public function setup_front_styles_scripts() {
			
		}

		public function _admin_notices() {
			$msg = cx_get_session_msg_html();
			echo $msg;
			$this->taxonomy_save_notices();
		}
		public function get_meta_box_class($class){
 			return $class;
 		}
 		public function insert_post_data($data , $postarr){
			return $data;
		}
		protected function custom_column_additional_header($cols) {
			return $cols;
		}









	
		public function _template_include( $template_path ) {

			    global $_plugin_uri;
			    global $post;

			   
			    $condition_my_pages = 0;

			 
			    if ( is_archive() && is_tax( $this->taxonomy_name )  ) {

			      	$this->setup_front_styles_scripts();
			 
		            if ( $theme_file = locate_template( array ( 'archive-'.$this->taxonomy_name.'.php' ) ) ) {

		                $template_path = $theme_file;

		            } else {

		            	$path = $this->_plugin_dir . 'template/archive/'.$this->taxonomy_name.'/archive.php';

		            	if ( file_exists($path)) {
		            		$template_path = $path;	
		            	}
		                
		            
		            }
			       
			      

			    }
			    return $template_path;
		}
	
		

		/*
		public function _insert_post_data($data =[], $postarr =[]){
			if( $data[ 'post_type' ] === $this->taxonomy_name ) {
				$updated = $this->insert_post_data($data , $postarr);
				return ($updated) ?  $updated : $data;
			}
		}
		*/

		

		public static function get_attributes(){
			$self = new static;
			return $self->taxonomy_attribute_list;
		}

		public function get_posthandels(){
			$self = new static;
			return $self->posthandler;
		}

		public static function get_attributes_value($id, $prefix = "", $remove_prefix = 1){

			$self = new static;
			$attrs =  $self->taxonomy_attribute_list;
			

			if ( !strlen($prefix) ) {
				$prefix = array_keys($attrs)[0];
				$prefix = explode("_", $prefix);
				$prefix = array_slice($prefix, 0,3);
				$prefix = implode("_", $prefix) . "_";
			}
			
			$return = [];
			foreach ($attrs as $key => $value) {
				$elem_key =  $key;
				if ( $remove_prefix ) {
					$elem_key = str_replace($prefix, "", $key);
				}
				$return[$elem_key] = get_term_meta( $id, $key ,1);
			}
			return $return;
		}

		
		
		public function register_taxonomy() {
			
			global $wpdb;
			$prefix = $wpdb->get_blog_prefix( get_current_blog_id() );

			
			


			$attrs = $this->register_attrs;
			$attrs["labels"] = $this->labels;
			

			register_taxonomy($this->taxonomy_name,$this->object_type ,$attrs);

		}
		public function render_taxonomy_attributes($term){
			wp_enqueue_media();
			
			$this->taxonomy_additional_metaboxes();

			$meta_box_list = [];
			
			$hiddens = [];
			$sections = [];
			foreach ($this->taxonomy_attribute_list as $name => $e) { 
				
				$e["value"] =  get_term_meta( $term->term_id , $name ,1);
				
				if ( $e["type"] == "hidden" ) {
					
					$hiddens[$name] = $e;
				
				} else {
					$e["group"] = (isset($e["group"])) ? $e["group"] : "general";
					if ( !isset( $sections[$e["group"]] ) ) $sections[ $e["group"] ] = [];
					$sections[ $e["group"] ][$name] = $e;
				}	
				
			}

			

			foreach ($sections as $key => $attrs) {
				
				?><section class='form-section <?= $this->render_helper->slugify( $key ) ?>'>
					<header><?= __($key,"xwt") ?></header>
					<div class="section-attribute"><?php 

						foreach ($attrs as $name => $e) {
							$n = $this->taxonomy_name . "[" .$name . "]";
							$this->render_helper->render_form_field($n, $e["value"] ,$e);
						}

					?></div>
				</section><?php
			}
			?><div class='hidden-fields'><?php 

				foreach ($hiddens as $name => $e) {
					$n = $this->taxonomy_name . "[" .$name . "]";
					$this->render_helper->render_form_field($n, $e["value"] ,$e);
				}

			?></div><?php

			
			
		}
		
		protected function set_up_post_handlers() {
			cx_add_global_posthandels($this->posthandler);
 		}
 		
 		public function _get_meta_box_class(){

 			global $term;
 			if ( !$term->term_id ) {
 				return "";
 			}
 			$class_str = "";
 			// $class = [];
 			// $attrs = $this->get_attributes();
 			// foreach ($attrs as $key => $info) {
 			// 	if(  isset($info["add_in_metabox_class"]) && $info["add_in_metabox_class"] ){
 			// 		$_class= get_post_meta($post->ID,$key,1);
 			// 		$_class= sanitize_title($_class);
 			// 		$_class=$key ."--".$_class;
 			// 		$class[] = $_class;

 			// 	}
 			// }
 			// $new_classes=$this->get_meta_box_class($class);
 			// $return_classes =  ( $new_classes ) ? $new_classes : $new_classes;
 			// $class_str = "";
 			// foreach ($return_classes as $value) {
 			// 	$class_str .= " $value ";

 			// }
 			return $class_str;
 			
 		}
 		
		public function render_meta_box($p,$args){
			wp_enqueue_media();
			
			$this->render_additional_meta_box($p,$args);

			$metabox = explode("__", $args["id"]);
			$metabox = $metabox[ count($metabox) - 1];
			$metabox = implode(" ", explode("-", $metabox));
			
			$attrs_to_render = [];
			foreach ($this->taxonomy_attribute_list as $key => $value) {
				
				if ( $metabox == $value["group"] ) {
					$attrs_to_render[$key] = $value;
				}
			}
			
			

			$classes = $this->_get_meta_box_class();
			?><div class="hs-metabox-feilds-container <?php echo $classes; ?>"><?php
			foreach ($attrs_to_render as $key => $e) {
				if ( $e["show_in_admin_edit"] ) {
					$key_post = $this->taxonomy_name . "[" .$key .  "]";

					$val = null;
					if ($p->ID) {
						$val = get_post_meta( $p->ID , $key ,1);
					}
					$this->render_helper->render_form_field($key_post, $val ,$e);
				}
				
			}
			?></div><?php

		}
		public function delete_taxonomy_attrs($term_id, $taxonomy_term_id) {

			foreach ($this->taxonomy_attribute_list as $key => $info) {
	            
	            delete_term_meta( $term_id, $key );
	            
	        } 
	        $this->delete_additional_taxonomy_attrs($term_id,$taxonomy_term_id);
		}
		// saving term attrs
		public function save_taxonomy_attrs($term_id, $taxonomy_term_id) {

			

			if ( !$term_id ) return;

			$term = get_term($term_id);
			if ( $term->taxonomy == $this->taxonomy_name ) {

		        
		    	$postdata = $_POST[$this->taxonomy_name];
		    	if ( isset($postdata)) {
		    		foreach ($this->taxonomy_attribute_list as $key => $info) {
			            if ( isset( $postdata[$key]) ) {
			                update_term_meta( $term_id, $key, $postdata[$key] );
			            }
			        } 
		    	}  
		    	$this->save_additional_taxonomy_attrs($pid, $p, $postdata);
	    	}
	    	

		}
		public function custom_column_content($column_name) {
			
			global $post;
			$this->custom_column_additional_content($column_name);

			foreach ($this->taxonomy_attribute_list as $key => $opt) {
	            if ( isset($opt["show_in_admin_gird"]) && $opt["show_in_admin_gird"] && $column_name ==$key ) {
	                
	                $value = get_post_meta( $post->ID ,$key ,1);

	                $method_name = "render_gird_column_" . $key;
	                
	                ?><div class="
	                	wp-grid-col-val 
	                	grid-col-<?php echo $column_name; ?> 
	                	col-val-<?php echo sanitize_title($value); ?>" 
	                	data-colval="<?php echo $value ?>"><?php

		                if ( method_exists($this,$method_name) ) {
		                	echo $this->$method_name($value,$post );
		                } else {
		                	echo $value;
		                }
		            ?></div><?php
	               	return 0;
	            }
	        }

		}

		public function custom_column_header($cat_columns) {
			
			foreach ($this->taxonomy_attribute_list as $key => $opt) {
	            if ( isset($opt["show_in_admin_gird"]) && $opt["show_in_admin_gird"] ) {
	            	$label= $opt["label"];
	            	if ( $opt["admin_gird_label"] ) {
	            		$label= $opt["admin_gird_label"];
	            	}
	                $cat_columns[$key] = $label;
	            }
	        }
	       

	        $col_edit = $this->custom_column_additional_header($cat_columns);
	        
	        if( $col_edit ){
	        	return $col_edit;
	        } else {
	        	return $cat_columns;
	        }
			 
		}


		
		// setting up styles and scripts
		protected function set_up_styles_scripts_base() {
			
			$this->set_up_styles_scripts();

			$actual_name = $this->class_actual_name;
			$class = get_called_class();
			

			

			$url = $this->get_plugin_uri() ;
			

	        $path = realpath($this->get_plugin_path() . "/asset/taxonomy/$actual_name/");

			if ( is_admin() ) {
	           
				if ( file_exists($path. '/admin.css' )) {
					wp_enqueue_style( 
		                $class . '-adminstyles', 
		                "$url/asset/taxonomy/$actual_name/admin.css"
		            );
				}
				if ( file_exists($path. '/admin.js' )) {
					wp_enqueue_script( 
		                $class . '-adminscript', 
		                "$url/asset/taxonomy/$actual_name/admin.js" 
		            );
				}


	        } else {

	        	if ( file_exists($path. '/front.css' )) {
					wp_enqueue_style( 
		                $class . '-frontstyles', 
		                "$url/asset/taxonomy/$actual_name/front.css"
		            );
				}
				if ( file_exists($path. '/front.js' )) {
					wp_enqueue_script( 
		                $class . '-frontscript', 
		                "$url/asset/taxonomy/$actual_name/front.js"
		            );
				}

	        }
		}

	}


}