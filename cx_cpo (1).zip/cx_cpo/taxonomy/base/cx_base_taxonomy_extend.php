<?php 

namespace cx_cpo;


if ( !class_exists("\\cx_cpo\\cx_base_taxonomy_extend")) { 
	
	class cx_base_taxonomy_extend extends cx_cpo {
		

		protected $object_type = [];


		// attes
		protected $taxonomy_attribute_list = [];

	
		
		
		protected $form_wraper = "";

		protected $taxonomy_name = "";

		

		protected $posthandler;


	

		public function setup_attributes() {
			$this->taxonomy_attribute_list = $this->attributes();
		}
		private $object_type_default = ["post"];
		
		function __construct(){

			add_action("wp_loaded", [$this,"setup_attributes"]);

			//$this->taxonomy_attribute_list = $this->attributes();

			$path = realpath(__DIR__ . "/../../helpers/cx_helper_render.php");
			if ( $path ) include_once( $path ); 

			$this->render_helper = new cx_helper_render();
			
			$called_class = get_called_class();
			$called_class_expd  = explode("_", $called_class);
			$actual_name_last = $called_class_expd[ count($called_class_expd) - 1 ];
			$actual_name_namespace =  $called_class_expd[ 1];
			$actual_name = $actual_name_namespace . "_" . $actual_name_last;

			$this->class_actual_name = $actual_name_last;

			// setting up taxonomy_name
			if ( !strlen($this->taxonomy_name) ){
				$this->taxonomy_name = $actual_name;
			}
			if ( !strlen($this->name_display) ) {
				$this->name_display = $actual_name;

			}
			
			/*
				setting up labels
			*/
			$taxonomy_name = $this->name_display;

			

			
			
			// support default
			if ( !count($this->object_type )) {
				$this->object_type = $this->object_type_default;
			}

			
			

			$default_attr_attr = [
				"show_in_admin_gird"	=>0,
		        "show_in_admin_edit"	=>1,
			];
			
			// add defualt vals to attrs
			foreach ($this->taxonomy_attribute_list as $key => $attr) {
				foreach ($default_attr_attr as $attr_key => $default_value) {
					if ( !isset($attr[$attr_key]) ){
						$this->taxonomy_attribute_list[$key][$attr_key] = $default_value;
					}
				}
			}
			// if ( !strlen($this->form_post_wraper) ) {
			// 	$this->form_post_wraper = "";
			// }


			//add_action( 'manage_'.$this->taxonomy_name.'_posts_custom_column', [$this,"custom_column_content"],10,3);
			//add_filter( 'manage_edit-'.$this->taxonomy_name.'_columns', [$this,"custom_column_header"], 10, 2);

			
			
			

			
			//add_action( $this->taxonomy_name . '_add_form', [$this,"render_taxonomy_attributes"] , 10, 2);
			add_action( $this->taxonomy_name . '_add_form_fields', [$this,"render_taxonomy_attributes"] , 10, 2);

			// edit page 
			add_action( $this->taxonomy_name . '_edit_form', [$this,"render_taxonomy_attributes"] , 10, 2);



			add_action( 'edited_' . $this->taxonomy_name , [$this,"save_taxonomy_attrs"], 10, 2 );
			add_action( 'created_' . $this->taxonomy_name , [$this,"save_taxonomy_attrs"], 10, 2 );

			add_action( 'delete_' . $this->taxonomy_name , [$this,"delete_taxonomy_attrs"], 10, 2 );
			add_action( 'admin_notices', array( $this, '_admin_notices' ) );


			//add_filter( 'wp_insert_post_data', [$this,"_insert_post_data"] );


		
			$this->set_up_styles_scripts_base();

			$this->set_up_post_handlers();
			foreach(glob(__DIR__  . "/../". get_called_class().  "/controllers/*.php") as $file){
    
			    require_once($file);
			    
			}


			//add_filter( 'template_include',[$this,"_template_include"] );

		}
		protected function taxonomy_save_notices() {

		}
		protected function delete_additional_taxonomy_attrs($term_id,$taxonomy_term_id) {

		}
		// for adding customer meta boxs on override
		protected function render_additional_meta_box($p,$args) {

		}
		// for adding customer meta boxs on override
		protected function save_additional_taxonomy_attrs($pid, $p, $post) {

		}
		// for adding customer meta boxs on override
		protected function taxonomy_additional_metaboxes() {

		}
		// for adding customer meta boxs on override
		
		protected function custom_column_additional_content($cols) {

		}

		protected function set_up_styles_scripts(){

			
		}
		
		public function setup_front_styles_scripts() {
			
		}

		public function _admin_notices() {
			$msg = cx_get_session_msg_html();
			echo $msg;
			$this->taxonomy_save_notices();
		}
		public function get_meta_box_class($class){
 			return $class;
 		}
 		public function insert_post_data($data , $postarr){
			return $data;
		}
		protected function custom_column_additional_header($cols) {
			return $cols;
		}










		

		public static function get_attributes(){
			$self = new static;
			return $self->taxonomy_attribute_list;
		}

		public static function get_posthandels(){
			$self = new static;
			return $self->posthandler;
		}

		public static function get_attributes_value($id, $prefix = "", $remove_prefix = 1){

			$self = new static;
			$attrs =  $self->taxonomy_attribute_list;
			

			if ( !strlen($prefix) ) {
				$prefix = array_keys($attrs)[0];
				$prefix = explode("_", $prefix);
				$prefix = array_slice($prefix, 0,3);
				$prefix = implode("_", $prefix) . "_";
			}
			
			$return = [];
			foreach ($attrs as $key => $value) {
				$elem_key =  $key;
				if ( $remove_prefix ) {
					$elem_key = str_replace($prefix, "", $key);
				}
				$return[$elem_key] = get_term_meta( $id, $key ,1);
			}
			return $return;
		}

		
		
		public function render_taxonomy_attributes($term){
			wp_enqueue_media();
			
			$this->taxonomy_additional_metaboxes();

			$meta_box_list = [];
			
			$hiddens = [];
			$sections = [];
			foreach ($this->taxonomy_attribute_list as $name => $e) { 
				
				$e["value"] =  get_term_meta( $term->term_id , $name ,1);
				
				if ( $e["type"] == "hidden" ) {
					
					$hiddens[$name] = $e;
				
				} else {
					$e["group"] = (isset($e["group"])) ? $e["group"] : "general";
					if ( !isset( $sections[$e["group"]] ) ) $sections[ $e["group"] ] = [];
					$sections[ $e["group"] ][$name] = $e;
				}	
				
			}


			foreach ($sections as $key => $attrs) {
				
				?><section class='form-section <?= $this->render_helper->slugify( $key ) ?>'>
					<header><?= __($key,"xwt") ?></header>
					<div class="section-attribute"><?php 

						foreach ($attrs as $name => $e) {
							$n = $this->taxonomy_name . "[" .$name . "]";
							$this->render_helper->render_form_field($n, $e["value"] ,$e);
						}

					?></div>
				</section><?php
			}
			?><div class='hidden-fields'><?php 

				foreach ($hiddens as $name => $e) {
					$n = $this->taxonomy_name . "[" .$name . "]";
					$this->render_helper->render_form_field($n, $e["value"] ,$e);
				}

			?></div><?php

			
			
		}
		
		protected function set_up_post_handlers() {
			cx_add_global_posthandels($this->posthandler);
 		}
 		
 		public function _get_meta_box_class(){

 			global $term;
 			if ( !$term->term_id ) {
 				return "";
 			}
 			$class_str = "";
 			// $class = [];
 			// $attrs = $this->get_attributes();
 			// foreach ($attrs as $key => $info) {
 			// 	if(  isset($info["add_in_metabox_class"]) && $info["add_in_metabox_class"] ){
 			// 		$_class= get_post_meta($post->ID,$key,1);
 			// 		$_class= sanitize_title($_class);
 			// 		$_class=$key ."--".$_class;
 			// 		$class[] = $_class;

 			// 	}
 			// }
 			// $new_classes=$this->get_meta_box_class($class);
 			// $return_classes =  ( $new_classes ) ? $new_classes : $new_classes;
 			// $class_str = "";
 			// foreach ($return_classes as $value) {
 			// 	$class_str .= " $value ";

 			// }
 			return $class_str;
 			
 		}
 		
		public function render_meta_box($p,$args){
			wp_enqueue_media();
			
			$this->render_additional_meta_box($p,$args);

			$metabox = explode("__", $args["id"]);
			$metabox = $metabox[ count($metabox) - 1];
			$metabox = implode(" ", explode("-", $metabox));
			
			$attrs_to_render = [];
			foreach ($this->taxonomy_attribute_list as $key => $value) {
				
				if ( $metabox == $value["group"] ) {
					$attrs_to_render[$key] = $value;
				}
			}
			
			

			$classes = $this->_get_meta_box_class();
			?><div class="hs-metabox-feilds-container <?php echo $classes; ?>"><?php
			foreach ($attrs_to_render as $key => $e) {
				if ( $e["show_in_admin_edit"] ) {
					$key_post = $this->taxonomy_name . "[" .$key .  "]";

					$val = null;
					if ($p->ID) {
						$val = get_post_meta( $p->ID , $key ,1);
					}
					$this->render_helper->render_form_field($key_post, $val ,$e);
				}
				
			}
			?></div><?php

		}
		public function delete_taxonomy_attrs($term_id, $taxonomy_term_id) {

			foreach ($this->taxonomy_attribute_list as $key => $info) {
	            
	            delete_term_meta( $term_id, $key );
	            
	        } 
	        $this->delete_additional_taxonomy_attrs($term_id,$taxonomy_term_id);
		}
		// saving term attrs
		public function save_taxonomy_attrs($term_id, $taxonomy_term_id) {

			

			if ( !$term_id ) return;

			$term = get_term($term_id);
			if ( $term->taxonomy == $this->taxonomy_name ) {

		        
		    	$postdata = $_POST[$this->taxonomy_name];
		    	if ( isset($postdata)) {
		    		foreach ($this->taxonomy_attribute_list as $key => $info) {
			            if ( isset( $postdata[$key]) ) {
			                update_term_meta( $term_id, $key, $postdata[$key] );
			            }
			        } 
		    	}  
		    	$this->save_additional_taxonomy_attrs($pid, $p, $postdata);
	    	}
	    	

		}
		public function custom_column_content($column_name) {
			
			global $post;
			$this->custom_column_additional_content($column_name);

			foreach ($this->taxonomy_attribute_list as $key => $opt) {
	            if ( isset($opt["show_in_admin_gird"]) && $opt["show_in_admin_gird"] && $column_name ==$key ) {
	                
	                $value = get_post_meta( $post->ID ,$key ,1);

	                $method_name = "render_gird_column_" . $key;
	                
	                ?><div class="
	                	wp-grid-col-val 
	                	grid-col-<?php echo $column_name; ?> 
	                	col-val-<?php echo sanitize_title($value); ?>" 
	                	data-colval="<?php echo $value ?>"><?php

		                if ( method_exists($this,$method_name) ) {
		                	echo $this->$method_name($value,$post );
		                } else {
		                	echo $value;
		                }
		            ?></div><?php
	               	return 0;
	            }
	        }

		}

		public function custom_column_header($cat_columns) {
			
			foreach ($this->taxonomy_attribute_list as $key => $opt) {
	            if ( isset($opt["show_in_admin_gird"]) && $opt["show_in_admin_gird"] ) {
	            	$label= $opt["label"];
	            	if ( $opt["admin_gird_label"] ) {
	            		$label= $opt["admin_gird_label"];
	            	}
	                $cat_columns[$key] = $label;
	            }
	        }
	       

	        $col_edit = $this->custom_column_additional_header($cat_columns);
	        
	        if( $col_edit ){
	        	return $col_edit;
	        } else {
	        	return $cat_columns;
	        }
			 
		}


		
		// setting up styles and scripts
		protected function set_up_styles_scripts_base() {
			
			$this->set_up_styles_scripts();

		}

	}


}