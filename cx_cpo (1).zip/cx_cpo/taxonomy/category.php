<?php 

namespace cx_cpo\taxonomy;

include_once(__DIR__ . "/base/cx_base_taxonomy.php"); 

if ( !class_exists("category")) {

	class category extends \cx_cpo\cx_base_taxonomy { 
		
		
		
		protected $name_display;
		//protected $taxonomy_name;
		protected $object_type = ["cx_cpo_mixture"];
		
		protected $register_attrs = [
			'rewrite'           => [
				'slug' => 'category',
				'with_front' => true
			],
		];
		

		function __construct() {

			$this->labels = [
				'name'                       => $this->__("categories"),
		        'singular_name'              => $this->__("category"),
		        "menu_name"                  => $this->__("categories" ),
		        "all_items"                  => $this->__("All category"),
		        "parent_item"                => $this->__("Parent category"),
		        "parent_item_colon"          => $this->__("Parent category"),
		        "new_item_name"              => $this->__("New category "),
		        "add_new_item"               => $this->__("Add New category"),
		        "edit_item"                  => $this->__("Edit category"),
		        "update_item"                => $this->__("Update category"),
		        "separate_items_with_commas" => $this->__("Separate category with commas"),
		        "search_items"               => $this->__("Search category"),
		        "add_or_remove_items"        => $this->__("Add or remove category"),
		        "choose_from_most_used"      => $this->__("Choose from the most populate category"),
				
			];

			$this->name_display = __("category" , "cx");
			//$this->taxonomy_name = "auctiongroup";


			parent::__construct();
			

		}
		protected function attributes() {
			return [
				
			];

		}
	}
}