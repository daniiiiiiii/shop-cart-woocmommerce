<?php 

if ( !function_exists("cx_cpo_calculate_item_price")) {

	function cx_cpo_calculate_item_price_info( $size_id , $mixture_list = [] ) {
		$return = [
			'final_price'=> 0,
			'size'=> [],
			'mixture'=> [],

		];
		
		$price = get_post_meta( $size_id , 'cx_cpo_size_price', 1 );
		$price = floatval($price);

		$size_title = get_post_field( 'post_title', $size_id, 1 );
		$return['size'] = [
			'title'		=> $size_title,
			'price'		=> $price,
			
		];

		foreach ($mixture_list as $id ) {

			$mix_price = get_post_meta( $id, 'cx_cpo_mixture_price', 1 );
			$dynamic_price = get_post_meta( $id, 'cx_cpo_mixture_price_' . $size_id , 1 );
			if ( $dynamic_price ) {
				$mix_price = $dynamic_price;
			}

			$mix_price = floatval($mix_price);

			$mixture_title = get_post_field( 'post_title', $id, 1 );
			if ( isset($return['mixture'][$mixture_title])) {

				
					$qty = $return['mixture'][$mixture_title]['qty']; 
					$qty += 1;

					$unit_price = $return['mixture'][$mixture_title]['unit_price']; 

					$return['mixture'][$mixture_title]['qty'] = $qty;

					$return['mixture'][$mixture_title]['price'] = $$unit_price * $qty ; 
				
			} else {

				$return['mixture'][$mixture_title] = [

					'title'		=> $mixture_title,
					'unit_price'=> $mix_price,
					'price'		=> $mix_price,
					'qty'		=> 1,
				];
			}
			

			$price += $mix_price;

		}
		$return['final_price'] = $price;

		return $return;
	}

}

if ( !function_exists("cx_cpo_item_price_info")) {
	function cx_cpo_item_price_info( $item_title , $data ) { 

		$cur = get_woocommerce_currency_symbol();
		$price_info = \cx_cpo_calculate_item_price_info($data['size'], $data['mixture'] );
					
		?><div class="cart-custom-item-info item-<?= sanitize_title( $item_title ) ?>">
			
			<h3><?= $item_title; ?></h3>

			<table class='cx-cpo-item-info-table'>
				<tbody>
					<tr>
						<th colspan="2"><?= __('Size','cx') ?></th>
					</tr>
					<tr>
						<td><?= $price_info['size']['title'] ?></td>
						<td><?= $cur . " " . $price_info['size']['price'] ?></td>

					</tr>
					<tr>
						<th colspan="2"><?= __('Mixture','cx') ?></th>
						<?php 
							foreach ($price_info['mixture'] as $m) {
								?><tr>
									<td><?= $m['title'] ?></td>
									<td>
										<?php 
											if ( $m['qty'] > 1 ) {
												?><strong><?=  $m['qty'] ?>x	</strong><?php 
											}
										
										if ( $m['price'] ) {
											echo $cur . " " . $m['price'];
										} else {
											echo ' - ';
										}
										
										
									?></td>

								</tr><?php 
							}
						?>
					</tr>

				</tbody>
				<tfoot>
					<tr>
						<td>Total</td>
						<td><?= $cur . " " .  $price_info['final_price'] ?></td>
					</tr>
				</tfoot>
			</table>

		</div><?php 
	}
}
