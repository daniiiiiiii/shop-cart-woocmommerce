<?php 

namespace cx_cpo;

if ( !class_exists("\\cx_cpo\\cx_base_table")) { 
  
    class cx_base_table extends cx_base {


        protected $columns_info = [];

        protected $table_name = "";
        
        protected $columns = [];
        
        protected $primary_key = "id";

        protected $row_per_page = 50;
        
        protected $page_query_prefix = 'cx_';
        
        protected $data_model = null;

        private $total_items = -1;
        private $current_page = 0;

        private $_data = [];
        
        function __construct(){ 


            parent::__construct();
            $this->render_helper = $this->helper("render");
        }

        public function set_data($pram) {
            $this->_data = $pram;
        }
        public function get_data($key = null) {
            if ( is_null($key)) return $this->_data;
            return $this->_data[$key];
        }

        
        public function get_total_items() {

            if ( $this->total_items == -1 ) {

                $table_name = $this->table_name;
                $primary_key = $this->primary_key;

                $query = "
                    SELECT $primary_key 
                    FROM $table_name
                ";
                $this->total_items = $this->wpdb->query($query);

            }
            return $this->total_items;
        }
        public function set_row_per_page($count) {

            $count = is_numeric($count) ? $count : $this->row_per_page;
            $count = intval($count);
            $count = $count > 0 ? $count : $this->row_per_page;
            $this->row_per_page = $count;

        }
        public function get_total_pages() {

            $this->total_pages = ceil($this->get_total_items()/$this->row_per_page); 
            return $this->total_pages;

        }
        public function set_current_page($page) {
            
            $page = is_numeric($page) ? $page : 1;
            $page = intval($page);
            $page = $page > 0 ? $page : 1;
            $page = $page > $this->get_total_pages() ? $this->get_total_pages() : $page;

            $this->current_page = $page;

            return $this->current_page;
        }
        public function extra_tablenav( $which ) {
           if ( $which == "top" ){
              //The code that goes before the table is here
             
           }
           if ( $which == "bottom" ){
              //The code that goes after the table is there
              
           }
        }

       

        public function current_page() {

            if ( isset($this->current_page) && $this->current_page ) return $this->current_page;

            $paged = $_GET[ $this->page_query_prefix . 'page'];
            $paged = isset($paged) ? $paged : 1;
            $paged = intval($paged);
            $paged = is_numeric($paged) ? $paged : 1;
            $paged = $paged > 0 ? $paged : 1;
            $paged = $paged > $this->get_total_pages() ? $this->get_total_pages() : $paged;

            return $paged;
        }
        public function get_items_query() {
            return $this->item_query;
        }
        
        public function prepare_items() {

            
            $total_items = $this->get_total_items(); 

            $paged =  $this->current_page();
            
            
            $offset         =  ( $paged-1 ) * $this->row_per_page;  
            $offset_str     =  ' LIMIT ' . $offset . ',' . $this->row_per_page;


            if ( isset($this->data_model)) {

                $this->items = $this->data_model->get_selected_feilds(['*'], [] , $offset_str );

            } else {
                $query = "
                    SELECT * 
                    FROM `$this->table_name`
                ";
                $query .= $offset_str;

                $this->item_query = $query;

                $this->items = $this->wpdb->get_results($query);

            }

            
        }

        public function get_column_info(){
            return [
                $this->get_columns(),$this->get_hidden_columns(),$this->get_sortable_columns(),$this->primary_key
            ];
        }
        public function after_last_row() {
            
        }
        public function render_table() {

           

            //Get the records registered in the prepare_items method
            $records = $this->items;

            $this->render_helper->table([

                "fieldNames"=> $this->columns,
                "fieldSet"  => $records,

            ], $this);
           //Get the columns registered in the get_columns and get_sortable_columns methods
           // list( $columns, $hidden ) = $this->get_column_info();
           // $columns = $this->get_columns();
           // //Loop for each record
           //  if(!empty($records)){

           //      foreach($records as $rec){

           //          echo '<tr id="record_'.$rec->{$this->primary_key}.'">';

           //          foreach ( $columns as $column_name => $column_display_name ) {

           //              $render_function = "column_render_" . $column_name;
           //              $render_function = strtolower($render_function);
           //              $render_function = preg_replace("/[^0-9a-z_]/", "", $render_function); 

           //              //Style attributes for each col
           //              $class = "class='$column_name column-$column_name  $render_function '";
           //              $style = "";
           //              if ( in_array( $column_name, $hidden ) ) $style = ' style="display:none;"';
           //              $attributes = $class . $style;

           //               //edit link
           //              $editlink  = '/wp-admin/link.php?action=edit&link_id='.(int) $rec->link_id;



           //              if (  method_exists($this, $render_function) ) {
           //                  $value = $this->$render_function($rec->{$column_name} , $rec);
           //              }else {
           //                  $value =$rec->{$column_name};
           //              }
           //              echo '<td  '.$attributes.'>'.  $value.'</td>';   
                        
           //          }

           //          echo'</tr>';
           //      }
           //  }

            echo $this->after_last_row();
        }
        public function render_pagination() {

            $total_pages = $this->get_total_pages();
            $current_page =  $this->current_page();
            if ( $total_pages > 1) {

                ?><ul class="table-pagination table-<?= $this->table_name ?>"><?php 

                    for ( $i = 1; $i <= $total_pages; $i++ ) {

                        $class = ($current_page == $i) ? "current" : "";
                        ?><li class="table-page-link <?= $class ?> table-page-link-<?= $i ?> ">
                            <a href="<?= $this->table_page_url($i) ?>"><?= $i ?></a>
                        </li><?php     

                    }    
                ?></ul><?php 
            }
            

        }
        public function table_page_url($pram) {
            $http =  (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http");
            $host = "://" . $_SERVER['HTTP_HOST'];
            $page = explode("?", $_SERVER['REQUEST_URI'])[0];


            if ( is_array($pram)) {
                $p = [];
                foreach ($pram as $key => $value) {

                    $p[ $this->page_query_prefix . $key] = $value;

                }

                $pram = $p;

            } else {

                $page_number = $pram;
                $pram = [ 
                    $this->page_query_prefix . 'page' => $page_number,
                ];

                
            }
            $actual_link = $http . $host . $page . "?" . http_build_query(array_merge($_GET, $pram));
            return $actual_link;

        }
        public function render() {

            $this->prepare_items();
            $this->render_table();
            $this->render_pagination();

        }
    }
}
