<?php
  

// config goes here
global $_cx_config;

if (!isset($_cx_config )) {
	$_cx_config = [];
}


// defaults



