<?php

namespace cx_cpo\rest;

include(realpath(__DIR__ . "/base/cx_base_rest.php") ); 

if (!class_exists("\\cx_cpo\\rest\\mediauploader")) {

    class mediauploader extends \cx_cpo\cx_base_rest { 
        
        /* optional  */
        protected $version = "1";
        protected $namespace = "cx_rest_mediauploader";
        

        protected $public_methods = [
            
            "upload"=>["upload","POST"],
            "get"=>["get_media_item","GET"],
            "get_where"=>["get_media_items","GET"],
            "get_by_urls"=>["get_media_item_by_urls","POST"],
            "get_by_ids"=>["get_media_item_by_ids","POST"],

            "delete"=>["delete_media_item","GET"],
            "compress"=>["compress","GET"],
            "crop"=>["crop","GET"],


        ];
        /* /wp-json/cx_cpo_rest_mediauploader/v1/index */
        public function upload(){
            
            $wordpress_upload_dir = wp_upload_dir();

            $file = $_FILES['file'];
            

            $new_file_path = $wordpress_upload_dir['path'] . '/' . $file['name'];
            $new_file_mime = $file['type'] ;
             
            if( empty( $file ) )
                die( 'File is not selected.' );
             
            if( $file['error'] )
                die( $file['error'] );
             
            if( $file['size'] > wp_max_upload_size() )
                die( 'It is too large than expected.' );
             
            /*
            if( !in_array( $new_file_mime, get_allowed_mime_types() ) )
                die( 'WordPress doesn\'t allow this type of uploads.' );

            */
            // wp_generate_attachment_metadata() won't work if you do not include this file
            require_once( ABSPATH . 'wp-admin/includes/image.php' );
            require_once( ABSPATH . 'wp-admin/includes/file.php' );
            require_once( ABSPATH . 'wp-admin/includes/media.php' );

           
            
            $i = 0;
            while( file_exists( $new_file_path ) ) {
                $i++;
                $new_file_path = $wordpress_upload_dir['path'] . '/' . $i . '_' . $file['name'];
            }
            
            // looks like everything is OK
            if( move_uploaded_file( $file['tmp_name'], $new_file_path ) ) {
                
                chmod($new_file_path, 0755);

                $uploader_id = isset($_POST["uploader_id"] ) ? $_POST["uploader_id"] :"";

                $data = $this->add_img_to_wp_media($new_file_path,$uploader_id,$new_file_mime);

                

                

                // Show the uploaded file in browser
                
                return ["status"=>1, "data"=>$data];
             
            }
            return ["status"=>0,"msg"=>"failed","data"=>[]];
        }
        // private furntion for inner use
        private function get_media_item_object($args = []) {
            $args["post_type"] = "attachment";
            
            $items = get_posts($args);
            $ritems  = [ ];
            foreach ($items as $key => $item) {
                if ( is_numeric($item) ) {
                    $ritems[$item] = [
                        "ID"=>$item,
                        "url"=>wp_get_attachment_url($item),
                        
                    ];

                } else {
                    $ritems[$key] = (array) $item;
                    $ritems[$key]["url"] = wp_get_attachment_url($item->ID);
                }
                
            }

            return $ritems;

        }
        public function get_media_item_by_urls() {
            if ( isset($_POST["urls"]) ) {

                $set = get_posts([
                    "post_type"=>"attachment",
                    'fields' => 'ids',
                    "meta_query"=> [
                        [
                            "key"=>"url",
                            "value"=>$_POST["urls"],
                            "compare"=>"IN"
                        ]
                    ],
                ]);
            
                $return_data =[];

                foreach ($set as $key => $id) {
                    $return_data[] = [
                        "id"=>$id,
                        "url"=>wp_get_attachment_url( $id ),
                    ];
                }
                return [
                    "status"=>1,
                    "data"=>$return_data ,
                ];
            } else {

                return ["status"=>0,"msg"=>"url required"];
            }
        }
        public function get_media_item_by_ids() {
            if ( isset($_POST["ids"]) ) {

                $set = get_posts([
                    "post_type"=>"attachment",
                    "post__in"=>$_POST["ids"],
                    'fields' => 'ids'
                ]);

                $return_data =[];
                foreach ($set as $key => $id) {
                    $return_data[] = [
                        "id"=>$id,
                        "url"=>wp_get_attachment_url( $id ),
                    ];
                }
                return [
                    "status"=>1,
                    "data"=>$return_data ,
                ];
            } else {

                return ["status"=>0,"msg"=>"url required"];
            }
        }
        public function get_media_item(){

            if ( isset($_GET["ids"]) ) {

                $id = $_GET["ids"];
                if ( strpos($id, ",")>=0 ) {
                    $id=explode(",", $id);
                }
                return $this->get_media_item_object([
                    "post__in"=>$id ,
                   

                ]);
                

            } else {

                return ["status"=>0,"msg"=>"id required"];
            }
           
        }

        public function delete_media_item(){
            $id = $_GET["id"];
            $user_id = $_GET["uploader_id"];

            $uploader_id = get_post_meta($id,"uploader_id",1);
            
            if ( intval($uploader_id) == intval($user_id) ) {
                wp_delete_attachment( $id );
                return ["status"=>1,"msg"=>"item deleted"];
            }
            
            return ["status"=>0,"msg"=>"cannot delete the item,"];

        }

        public function get_media_items($pram){

            $key = $_GET["key"];
            $value = $_GET["value"];
            if ( !isset($key) || !isset($value)  ) {

                return ["status"=>0,"msg"=>"prams required"];
            
            } else {

                $data = [];
                $list = $this->get_media_item_object([
                        "numberposts"=>-1,
                        "meta_query"=>[
                            [
                                'key' => $key,
                                'value' => $value,
                                'compare' => '=',
                            ]
                        ], 
                    ]);
                foreach ($list as $media_item) {
                    
                    $data[] = [
                        "id"=> intval($media_item["ID"]),
                        "url"=> $media_item["url"],

                    ];
                }
                return [
                    "status"=>1,
                    "data"=> $data,
                ]; 
            }
            

        }
        public function compress(){
            
            $files= [];

            $has_something = 0;
            if ( isset($_GET["id"])) {
                $has_something = 1;
                $files= explode(",", $_GET["id"]);
            } 

            if ( $has_something ) {
                $files_paths = [];
                foreach ($files as $f) {
                    $path = get_attached_file($f);
                    if ( $path ) {
                        $files_paths[] = $path;     
                    }
                    
                }
                
                include_once(realpath(__DIR__ . "/../lib/CompressorIO.php"))  ;

                $compress = new CompressorIO();
                $compress->backup = true;
                
                $compress->compress($files_paths);
                
                return ["status"=>1,"msg"=>"sucess"];
            }

           
        }
        private function imagecreatefromfile( $filename ) {
            if (!file_exists($filename)) {
                return null;
                //throw new InvalidArgumentException('File "'.$filename.'" not found.');
            }
            switch ( strtolower( pathinfo( $filename, PATHINFO_EXTENSION ))) {
                case 'jpeg':
                case 'jpg':
                    return imagecreatefromjpeg($filename);
                break;

                case 'png':
                    return imagecreatefrompng($filename);
                break;

                case 'gif':
                    return imagecreatefromgif($filename);
                break;

                default:
                    return null;
                    throw new InvalidArgumentException('File "'.$filename.'" is not valid jpg, png or gif image.');
                break;
            }
        }
        private function add_img_to_wp_media($new_path,$uploader_id,$mine_type) {
            
            require_once( ABSPATH . 'wp-admin/includes/image.php' );
            require_once( ABSPATH . 'wp-admin/includes/file.php' );
            require_once( ABSPATH . 'wp-admin/includes/media.php' );
            
            $wordpress_upload_dir = wp_upload_dir();
            $img_url =  $wordpress_upload_dir['url'] . '/' . basename( $new_path );

            $img_id = wp_insert_attachment( array(

                'guid'           => $new_path, 
                'post_mime_type' => $mine_type,
                'post_title'     => preg_replace( '/\.[^.]+$/', '', basename($new_path,".png") ),
                'post_content'   => $uploader_id,
                'post_author'   => intval($uploader_id),

                'post_description'   => $uploader_id,
                'post_status'    => 'inherit',
                "meta_input"    => [
                    "uploader_id" => $uploader_id,
                    "url" => $img_url,
                ]

            ), $new_path );
                
            

            update_post_meta($img_id,"uploader_id",$uploader_id);

            $img_data = wp_generate_attachment_metadata( $img_id, $new_path );
            

            apply_filters('wp_handle_upload', array(
                'file'  =>  $new_path, 
                'url'   => $img_url, 
                'type'  => $mine_type), 
            'upload');

            wp_update_attachment_metadata( $img_id, $img_data );
            return ["id"=> intval($img_id),"url"=>$img_url];
        }
        public function crop() {
            

            $err = [
                "id" => "prams required id",
                "uploader_id" => "prams required uploader_id",
                "x" => "prams required x",
                "y" => "prams required y",
                "width" => "prams required width",
                "height" => "prams required height",

            ];
            foreach ($err as $key => $msg) {
                if (!isset($_GET[$key])) {
                    return ["status"=>0,"msg"=>$msg];
                }
            }
            
            $im_path = get_attached_file(intval($_GET["id"]));
            if ( !$im_path ) return ["status"=>0,"msg"=>"image path does not exist"];
            

            $im = $this->imagecreatefromfile($im_path);
            if ( !$im ) return ["status"=>0,"msg"=>"image type is not valid"];

            $im2 = imagecrop($im, [
                'x' => intval($_GET["x"]), 
                'y' => intval($_GET["y"]), 
                'width' => intval($_GET["width"]), 
                'height' => intval($_GET["height"])
            ]);
            

            $wordpress_upload_dir = wp_upload_dir();
            
            $new_path = $wordpress_upload_dir['path'] . "/" .  basename($im_path);
            $new_path = explode(".", $new_path);
            array_pop($new_path);
            $new_path = implode(".", $new_path);
            $new_path .= "-" .  $_GET["width"] . "X" . $_GET["height"] . ".png";
            
            imagepng($im2, $new_path);
            imagedestroy($im);
            imagedestroy($im2);


            $data = $this->add_img_to_wp_media($new_path,$_GET["uploader_id"],"image/png");
            return ["status"=>1, "data"=>$data];


        }
    }
}
