<?php 

namespace cx_cpo;

if ( !class_exists("\\cx_cpo\\cx_base_rest")) { 
	
	class cx_base_rest extends cx_base {
		
		protected $public_methods=[];

		protected $namespace = "";
		protected $version = "1";

		function __construct(){ 

			parent::__construct();
			
			if (!strlen($this->namespace)) {
				$class_name = get_called_class();
				$this->namespace = $class_name;
			}


			$namespace = $this->namespace;

			$version = $this->version;

			foreach ($this->public_methods as $key=>$func) {
			
				if ( is_numeric($key)) {
					$key=$func;
				}
				$this->currentKey = $key;
				$this->currentFunc = $func;

				add_action( "wp_loaded", function() {

					add_action( 'rest_api_init', function () {
						

						$namespace = $this->namespace;
						$version = $this->version;

						foreach ($this->public_methods as $key=>$func) {

							if ( !is_array($func)) {
								$func = [$func, "GET"];
							}
							if ( is_numeric($key)) {
								$key=$func[0];
							}

							$method = $func[1];


							register_rest_route( "$namespace/v$version", "/$key", array(
								'methods' => $method,
								'callback' => [$this, $func[0]],
							) );
						}

					});
  
				});
				
			}
		}

		public function get_public_methods() {
			return $this->public_methods;
		}
		
		
		public function get_api_namespace() {
			return $this->namespace;
		}
		public function get_api_version() {
			return $this->version;
		}

		protected function check_post_data($arr, $data_arr = 'POST') {
			$errors = [];
			foreach ($arr as $key => $value) {
				$keys = array_filter( explode(".", $key) );
				$val = ($data_arr == "POST") ? $_POST : $_GET;
				
				foreach ($keys as $i => $filed ) {
					if ( isset($val[$filed])) {
					 	$val = $val[$filed];
					} else {
						$errors[] = $value;
						break;
					}
				}
			}
			return $errors;
		}
		protected function res($status = 0, $data = [],$msg = '', $additional = []) {

			return array_merge([
				"status"=> $status,
				"data"=> $data,
				"msg"=> $msg,

			],$additional);
		}
		protected function res_success($data) {
			return $this->res(1, $data,"success" );
		}
		protected function res_error($errors , $error_code = null) {
			$add = [];
			if ( isset($error_code)) $add = ['error_code'=>$error_code];
			return $this->res(0, null ,$errors , $add);
		}

		
	}

}