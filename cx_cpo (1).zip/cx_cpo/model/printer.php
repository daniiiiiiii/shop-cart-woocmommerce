<?php 

namespace cx_cpo\model;

include_once(__DIR__ . "/base/cx_base_model_user.php"); 

if ( !class_exists("\\cx_cpo\\model\\printer")) {

	class printer extends \cx_cpo\cx_base_model_user { 
		
		protected function set_user_meta_attributes() {
			return [
				// "phone"=> [
				// 	"label"=>"phone",
				// 	"placeholder"=> "phone",
				// 	"required"=>1,
				// 	"use_in_signup"=>1,
				// ],
				// "country"=> [
				// 	"label"=>"country",
				// 	"placeholder"=> "country",
				// 	"required"=>1,
				// 	"use_in_signup"=>1,
				// ],
				// "zip"=> [
				// 	"label"=>"zip",
				// 	"placeholder"=> "zip",
				// ],

			];
		}

		protected function get_signup_email_template() {
			return cx_get_option_value( $this->_plugin_options, ["general", "template" , "user_signup"] );
			//return file_get_contents( $this->email_template_dir . "/signup.php");
		}
		protected function get_forgotpwd_email_template() {
			return cx_get_option_value( $this->_plugin_options, ["general", "template" , "user_reset_pass"] );
		}
		

	}

}
