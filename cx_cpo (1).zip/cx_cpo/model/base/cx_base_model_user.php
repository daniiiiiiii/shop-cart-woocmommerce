<?php 

namespace cx_cpo;

if ( !class_exists("cx_cpo\\cx_base_model_user")) {

	class cx_base_model_user extends cx_base {

		
		const USER_CLASS            = 'user';

		protected $user_class;
		// auto created
		protected $user_session_wraper;

		protected $email_template_dir ;
		// auto created 
		protected $user_meta_feilds = [];
		protected $user_meta_tables = [];

		protected $wp_user_login  = false;

		protected $base_feilds = [
			
			"user_email"=> [
				"type"=>"email",
				"label"=>"email address",
				"placeholder"=> "Enter your email address",
				"required"=>1,
				"use_in_signup"=>1,
			],
			"first_name"=> [
				"type"=>"text",
				"label"=>"name",
				"placeholder"=> "Enter your name",
				"required"=>1,
				"use_in_signup"=>1,	
			],
			"user_pass"=> [
				"type"=>"password",
				"label"=>"password",
				"placeholder"=> "********",
				"required"=>1,
				"use_in_signup"=>1,
				
			],


		];
		protected $default_role = 'subscriber';

		function __construct() {

			parent::__construct();

			if ( !isset($this->email_template_dir)) {
				$this->email_template_dir = $this->_plugin_dir . "/template/email/user/";
			}

			$this->user_class = static::USER_CLASS;

			$this->user_session_wraper = $this->_plugin_namespace . "_user_" . $this->user_class;

			global $wpdb;
			$this->wpdb = $wpdb;
		
			$prefix = $this->wpdb->prefix;
			
			$this->user_meta_tables = $this->set_user_meta_tables();

			
			$attrs = $this->set_user_meta_attributes();
			$full_attr_list = [];
			foreach ($attrs as $key => $opt) {
				if ( !isset($opt["store"]) ) {
					$opt["store"] = "meta";
				}
				if ( !isset($opt["visiblity"]) ) {
					$opt["visiblity"] = "public";
				}
				$full_attr_list[ $key ] = $opt;

			}
			$this->user_meta_feilds = $full_attr_list;

			add_filter( 'template_include',[$this,"_template_include"] );
			
			$this->add_posthandels($this->get_global_posthandels());

			//

			if ( $this->wp_user_login ) {
				add_action( "init", [$this, "syncing_user_status_with_wp_user"] );
			}
				// if wo user login 
				
		}
		public function syncing_user_status_with_wp_user() {
			//var_dump(is_user_logged_in());

			if ( \is_user_logged_in() ) {
				// if the role is accourging to the role
				if ( !$this->is_user_login() ) {

					$user = wp_get_current_user();
					if ( in_array($this->get_role(), $user->roles)) {
						$this->login($user->user_email);	
					}
					
				}
				
			} else {

				$this->logout();
			}
			
		}
		public function _template_include( $template_path ) {

		    global $_plugin_uri;
		   	global $wp_query;
		   	//var_dump($wp_query);
		    
		   	
		   	if ( is_author() && isset($wp_query->query["author_name"]) ) {
		   		$user_name = $wp_query->query["author_name"];

		   		$user = get_user_by("slug", $user_name );
		   		if ( in_array( $this->default_role , $user->roles)) {

		   			$path = $this->_plugin_dir . "/template/user/". $this->default_role . "/author.php" ;
		   			if ( file_exists($path)) {
		   				return $path;
		   			}
		   			

		   		}
		   	}
		    
		    return $template_path;
		}
		public function get_role() {
			return $this->default_role;
		}
		protected function set_user_meta_attributes() {
			return [];
		}
		protected function set_user_meta_tables() {
			return [];
		}
		public function get_table_user_id_field($table_name ) {
			return isset($this->user_meta_tables[ $table_name ]) ? $this->user_meta_tables[ $table_name ] : "user_id";
		}

		public function get_global_posthandels() {

			$class = get_called_class();
			$class = explode("\\",$class);
			$class = end($class);

			return [
				"cx_form_type"=>[
					"cx_model_user_". $this->user_session_wraper ."_signup"=> [
						realpath(__DIR__ . "/../" . $class . ".php") ,
						get_called_class(),
						"_signup"
					],
					"cx_model_user_". $this->user_session_wraper ."_login"=> [
						realpath(__DIR__ . "/../" . $class . ".php") ,
						get_called_class(),
						"_login"
					],
					"cx_model_user_". $this->user_session_wraper ."_forgotpwd"=> [
						realpath(__DIR__ . "/../" . $class . ".php") ,
						get_called_class(),
						"_forgotpwd"
					],
					"cx_model_user_". $this->user_session_wraper ."_editinfo"=> [
						realpath(__DIR__ . "/../" . $class . ".php") ,
						get_called_class(),
						"_editinfo"
					],
				]
			];
		}









		public function user_exists($email) {
			return get_user_by("email",$email );

		}

		// user_email, user_pass , first_name
		public function signup($user , $login_after_signup = 1, $send_signup_email = 1) {

			$user["role"] = $this->default_role;
			if ( !isset($user["user_pass"])) {
				$user["user_pass"] = wp_generate_password( 12 );
			}
			$id = $this->create($user);
			if ( !$id ) {
				cx_set_session_msg("error", "user email already exist");
				return false;
			}

			$_user = get_user_by("id",$id );

			if ( $login_after_signup ) {
				$this->login($user["user_email"]);	
			}
			

			if ( $send_signup_email ) {
				$this->send_signup_email( $id , $user["user_pass"]);	
			}
			
			
			return $id;

		}

		public function login($email, $pass=null) {

			$_user = get_user_by("email",$email );
			if ( !$_user ) $_user = get_user_by("login",$email );

			$auth =  1;

			
			if ( !in_array($this->default_role, $_user->roles) ) return 0;

			if ( strlen($pass) ) {
				$username = sanitize_user( $_user->user_login );
   				$password = trim( $pass );
   				
				$user = apply_filters( 'authenticate', null, $username, $password );
				
				if ( get_class($user) != "WP_User" ) { 
					$auth =  0;
				}
				
			}

			$status = 0;
			if ( $auth && $_user ) {

				$_SESSION[$this->user_session_wraper] = [
					"id" => $_user->ID,
					"email" => $_user->user_email,
					"username" => $_user->user_login,
					"name" => $_user->display_name,
				];
				$status = $_user->ID;
			}
			// wordpess login
			if  ( $this->wp_user_login ) {
				
				wp_clear_auth_cookie();
			    wp_set_current_user ( $user->ID );
			    wp_set_auth_cookie  ( $user->ID );

			}
			$this->after_login($status);


			return $status;
		}
		protected function after_login($id) {

		}

		public function logout() {

			if ( isset($_SESSION[$this->user_session_wraper]) ) {
				unset($_SESSION[$this->user_session_wraper]);
			}
			if  ( $this->wp_user_login ) {
				wp_logout();
			}

		}

		public function reset_password($email) {
			$_user = get_user_by("email",$email );
			if (  $_user ) {

				if ( in_array($this->default_role, $_user->roles) ) {

					$new_pass = wp_generate_password(12);
					wp_set_password($new_pass,$_user->ID);
					$this->logout();

					$this->send_forgotpwd_mail( $_user->ID , $new_pass );

				}

			}
			cx_set_session_msg("sucess","Password has been sent to email address of user. ");
		}
		public function get_user_class() {
			return $this->user_class;
		}
		public static function user_class() {
			return static::USER_CLASS;
		}
		
















		// user data 


		public function get_session_wraper() {
			return $this->user_session_wraper;
		}
		public function is_user_login() {
			

			if ( isset($_SESSION[$this->user_session_wraper]) && count($_SESSION[$this->user_session_wraper]) ) {
				return 1;
			}
			return 0;
		}

		public function get_user_session_data() {
			
			if ( isset($_SESSION[$this->user_session_wraper])  ) {
				
				return $_SESSION[$this->user_session_wraper];
				
			}
			return null;
		}
		public function get_user_id() {
			$rt = null;
			if ( isset($_SESSION[$this->user_session_wraper])  ) {
				$rt = intval($_SESSION[$this->user_session_wraper]["id"]);
			}
			return $rt;
		}
		public function get_user_data_array($user_id = null ) {

			$data = $this->get_user_data($user_id);
			$data = ( isset($data) ) ? $data : [];

			return json_decode( json_encode($data) , 1)['data'];
		}
		public function get_user_data_feild(  $user_id = null , $key , $multiple = false) {
			
			if ( isset($this->user_meta_feilds[$key])) {
				
				if ( $this->user_meta_feilds[$key]["store"] == "meta" ) {

					return get_user_meta( $user_id,  $key, $multiple );

				} else {

					$table = explode(".", $this->user_meta_feilds[$key]["store"])[0];
            		$col = explode(".", $this->user_meta_feilds[$key]["store"])[1];

            		$table_user_key = $this->get_table_user_id_field( $table ) ;

            		$res = $this->wpdb->get_results("SELECT $col FROM `$table` WHERE $table_user_key = $user_id");
            		
            		if ( count($res) ) {
            			if ( $multiple ) {
            				$arr = [];
            				foreach ($res as $oo) {
            					$arr[] = $oo->$col;
            				}
            				return $arr;
            			} else {
            				return $res[0]->$col;
            			}
            		}

				}
			} else {
				return get_user_meta( $user_id,  $key, $multiple );
			}
		}
		public function get_user_data( $user_id = null ) {

			if ( is_null($user_id) && isset($_SESSION[$this->user_session_wraper])  ) {
				
				$user_id = $_SESSION[$this->user_session_wraper]["id"];
			}

			$user = \get_userdata( $user_id );
			if ( !$user || get_class($user) == "WP_ERROR" ) {
				return null;
			}
			$metas = [];
            $tables = [];
            foreach ( $this->user_meta_feilds as $key => $opt) {

            	if ( !isset($opt["store"]) || $opt["store"] == "meta" ) {
            		
            		
            		$user->data->$key = get_user_meta( $user_id, $key, 1 );

            	} else {

            		$table = explode(".", $opt["store"])[0];
            		$col = explode(".", $opt["store"])[1];

            		if ( !isset($tables[ $table ]) ) {
            			$tables[ $table ] = [];
            		}
            		$tables[ $table ][] = $col;
            	}
            }

            foreach ($tables as $table_name => $data) {

            	$table_user_key = $this->get_table_user_id_field( $table_name ) ;

            	$res = $this->wpdb->get_results("SELECT * FROM `$table_name` WHERE $table_user_key = $user_id");
            	if ( count($res) ) {

            		foreach ($res[0] as $key => $value) {
            			$user->data->$key = $value;
            		}
            	}
            }
            
			return $user;
			return null;
		}
		


		




		protected function after_user_insert($id) {}
		private function create($user){

			if ( isset( $user["user_login"]) ) {
				if ( username_exists( $user["user_login"] ) ) return -1;
			} else {

				$first = 0;
				while(1){
					$post_fix = ( !$first ) ? "" : ("_" . rand( 11111,99999));
					$first = 1;

					$user["user_login"]=  sanitize_title($user["first_name"]) . $post_fix;
					if ( !username_exists( $user["user_login"] ) ) {
						break;
					}
				}
			}
			if ( email_exists( $user['user_email'] ) ) return false;


			$user_id = wp_insert_user($user);
			$this->save_meta_attrs( $user_id , $user );
			$this->after_user_insert($user_id);
           
            
            // base meta
            update_user_meta($user_id, "user_class", $this->user_class);

			return $user_id;
			
		}
		protected function save_meta_attrs( $user_id , $data ) {


			$metas = [];
            $tables = [];
            foreach ( $this->user_meta_feilds as $key => $opt) {

            	
            	if ( !isset($opt["store"]) || $opt["store"] == "meta" ) {
            		if ( isset($data[$key])) {
            			update_user_meta($user_id, $key, $data[$key]);		
            		}
            	} else {

            		$table = explode(".", $opt["store"])[0];
            		$col = explode(".", $opt["store"])[1];

            		
            		if ( !isset($tables[ $table ]) ) {
            			$tables[ $table ] = [];
            		}
            		$tables[ $table ][] = $col;
            	}
            }
           	

            foreach ($tables as $table => $data_set_keys ) {
            	$data_set = [];

            	foreach ($data_set_keys as $k) {
            		$data_set[$k] = $data[$k];
            	}

            	$user_id_col = $this->get_table_user_id_field( $table );
            	$check = $this->wpdb->get_results("SELECT `$user_id_col` FROM $table WHERE $user_id_col =  $user_id " );
            	
            	
            	if ( count($check)) {

            		$this->wpdb->update( $table , $data_set , [
	            		$user_id_col => $user_id,
	            	]);

            	} else {

            		$data_set[$user_id_col] = $user_id;
            		
            		$this->wpdb->insert( $table , $data_set);

            	}

            }

		}
		private function update($user_id,$user) {
			$data = $user;
			$data["ID"] = $user_id;
			wp_insert_user($data);

		}



















		// from atters
		public function get_signup_form_attrs() {
			$return = [
				"cx_form_type"=>[
					"type"=>"hidden",
					"value"=>"cx_model_user_". $this->user_session_wraper ."_signup",
				],
			];
			foreach ($this->base_feilds as $key => $attr) {
				if ( $attr["use_in_signup"] == 1 ) {
					$return[$key] =  $attr;
				}
			}
			foreach ($this->user_meta_feilds as $key => $attr) {
				if ( $attr["use_in_signup"] == 1 ) {
					$return[$key] =  $attr;
				}
			}
			return $return;
		}



		public function get_login_form_attrs() {
			return [
					"cx_form_type"=>[
						"type"=>"hidden",
						"value"=>"cx_model_user_". $this->user_session_wraper ."_login",
					],
					"user[email]"=>[
						"label"=>"email",
						"require"=>1,
					],
					"user[password]"=>[
						"label"=>"password",
						"type"=>"password",
						
						"require"=>1,
					]
				];
		}

		public function get_useredit_form_attrs() {
			
			$data = $this->get_user_data();
			

			$fname = $this->base_feilds["first_name"];
			$fname["value"] = $data->display_name;

			$attrs = [
				"cx_form_type"=>["type"=>"hidden","value"=>"cx_model_user_". $this->user_session_wraper ."_editinfo",],
				"first_name" => $fname,
			];

			foreach ($this->user_meta_feilds as $key => $opt) {
				if ( $opt["visiblity"] == "public" ) {
					$opt["value"] = $data->data->$key;
					$attrs[$key] = $opt;	
				}
				
			}
			$attrs["user_pass"] = [
				"type"=>"password",
				"label"=>"new password",
				"placeholder"=> "********",
				"comment"=>"leave empty if dont want to change password"
			];
			$attrs["user_pass_confirm"] = [
				"type"=>"password",
				"label"=>"new password again",
				"placeholder"=> "********",
				"comment"=>"leave empty if dont want to change password"
			];
			$attrs["old_pass"] = [
				"type"=>"password",
				"label"=>"current password",
				"placeholder"=> "********",
				"comment"=>"to edit information provide current password "
			];
			
			return $attrs;
		}

		public function get_forget_password_form_attrs() { 
			return [
					"cx_form_type"=>[
						"type"=>"hidden",
						"value"=>"cx_model_user_". $this->user_session_wraper ."_forgotpwd",
					],
					"user[email]"=>[
						"label"=>"your email",
						"require"=>1,
					]
				];
		}










		// forms 
		public function get_signup_form() {
			return [
				"method"=> "POST",
				"render_groups"=>0,
				"elements"=> $this->get_signup_form_attrs(),
				"submit"=> [
					"value"=> "sign up",
					"attributes"=>[
						"class"=> "button button-submit ",
					],
				],
			];
		}
		public function get_login_form() {
			return [
				"method"=> "POST",
				"render_groups"=>0,
				"elements"=> $this->get_login_form_attrs(),
				"submit"=> [
					"value"=> "log in",
					"attributes"=>[
						"class"=> "button button-submit ",
					],
				],
			];
		}
		public function get_forget_password_form() { 

			return [
				"method"=> "POST",
				"render_groups"=>0,
				"elements"=> $this->get_forget_password_form_attrs(),
				"submit"=> [
					"value"=> "send",
					"attributes"=>[
						"class"=> "button button-submit ",
					],
				],

			];
		}
		public function  get_user_edit_from() {
			if ( $this->is_user_login() ) {
				return [
					"method"=> "POST",
					"render_groups"=>0,
					"elements"=> $this->get_useredit_form_attrs(),
					"submit"=> [
						"value"=> "send",
						"attributes"=>[
							"class"=> "button button-submit ",
						],
					],
				];
			}
			return null;
			
		}









		// post handels
		public function _login() {


			$method = __FUNCTION__;
			$before_method = $method . "_before";
			$after_method = $method . "_after";


			

			if ( method_exists($this, $before_method ) ) $this->$before_method();

			$user = $_POST["user"];
			$user["password"] = isset($user["password"]) ? $user["password"] : "";

			$state = $this->login( $user["email"] , $user["password"] );

			if ( !$state ) {
				cx_set_session_msg("error"," login failed ");
			}

			if ( method_exists($this, $after_method ) ) $this->$after_method($state);
			unset($_POST);
			
			
		}

		public function _signup() {

			
			$method = __FUNCTION__;
			$before_method = $method . "_before";
			$after_method = $method . "_after";


			

			if ( method_exists($this, $before_method ) ) $this->$before_method();
			$id = $this->signup( $_POST );
			
			if ( method_exists($this, $after_method ) ) $this->$after_method($id);


		}
		
		public function _forgotpwd() {

			$method =  __FUNCTION__;
			$before_method = $method . "_before";
			$after_method = $method . "_after";

			
				if ( method_exists($this, $before_method ) ) $this->$before_method();

				$user = $_POST["user"];
				$email = $user["email"];	
				$this->reset_password( $email );
				
				
				if ( method_exists($this, $after_method ) ) $this->$after_method();

			
			
		}

		public function _editinfo() {

			if ( $this->is_user_login() ) {

				$method = $this->user_class . __FUNCTION__;
				$before_method = $method . "_before";
				$after_method = $method . "_after";


				if ( method_exists($this, $before_method ) ) $this->$before_method();

				$_user = $this->get_user_data();

				// logic goes
				$oldpass = $_POST["old_pass"];
				$username = $_user->user_login;
				$user = apply_filters( 'authenticate', null, $username, $oldpass );
				
				if ( get_class($user) == "WP_User" ) { 
					// passowrd is correct 
					if ( method_exists($this, $method ) ) {
						$this->$method();
					} else {

						// chcking new passowrd
						if ( strlen( $_POST["user_pass"] )) {
							if ( $_POST["user_pass"] == $_POST["user_pass_confirm"] ) {
								// update passowrd
								wp_set_password( $_POST["user_pass"] ,$_user->ID);

							} else {
								cx_set_session_msg("error", "password not updated , new password and confrom password does not match ");
							}	
						}
						// updating name
						if ( strlen($_POST["first_name"])) {
							// update
							
							wp_update_user([
								"ID"=> $_user->ID,
								"first_name"=>$_POST["first_name"],
								"display_name"=>$_POST["first_name"],
							]);
							update_user_meta(  $_user->ID, "first_name", $_POST["first_name"] );
						}

						

						// updating meta
						$this->save_meta_attrs( $_user->ID , $_POST );
						// foreach ( array_keys($this->user_meta_feilds) as $k) {
						// 	update_user_meta( $_user->ID, $k, $_POST[$k] );
						// }
						


					}
					if ( method_exists($this, $after_method ) ) $this->$after_method();
				} else {

					cx_set_session_msg("error", "invalid current password");
				
				}
			}
			
		}
		protected function get_signup_email_subject() {
			return "thanks for sign up";
		}
		protected function get_forgotpwd_email_subject() {
			return "we revice your password reset request";
		}

		protected function get_signup_email_template() {
			return file_get_contents( $this->email_template_dir . "/signup.php");
		}
		protected function get_forgotpwd_email_template() {
			return file_get_contents( $this->email_template_dir . "/resend_password.php");
		}

		protected function email_extra_data($template) {
			return [];
		}
		public function send_signup_email( $user_id , $pass ) {
			
			
			$user_info = $this->get_user_data_array( $user_id );
			$user_info = array_merge( $this->email_extra_data("signup") , $user_info);
			$user_info["user_password"] = $pass;
			$user_info["_user_pass"] = $pass;
			

			$msg_string = $this->get_signup_email_template();
			$msg_string = stripcslashes($msg_string);

			$title = $this->get_signup_email_subject();
			
			$this->send_mail_to_customer($user_id , $title , $msg_string , $user_info );

			
		}
		
		public function send_forgotpwd_mail( $user_id , $pass ) {

			$user_info = $this->get_user_data_array( $user_id );
			$user_info["user_password"] = $pass;
			$user_info["user_pass"] = $pass;
			
			$user_info = array_merge( $this->email_extra_data("forgot_password") , $user_info);
            $user_info["user_password"] = $pass;
			$user_info["user_pass"]     = $pass;
			$user_info["_user_pass"]     = $pass;
			
		
			$msg_string = $this->get_forgotpwd_email_template();
			$msg_string = stripcslashes($msg_string);

			
			$title = $this->get_forgotpwd_email_subject();
			
			$this->send_mail_to_customer($user_id , $title , $msg_string , $user_info );

		}
		
		public function send_mail_to_customer($user_id , $title, $template, $data =[],$header_pram = [] ) {
		    

			$user_info = $this->get_user_data_array( $user_id );
			$user_info = is_array($user_info) ? $user_info : [];
			unset($user_info['user_password']);
			
			
			$parse_data = array_merge( $user_info, $data);
            $parse_data["user_password"] = $parse_data["_user_pass"];
            $parse_data["user_pass"] = $parse_data["_user_pass"];
            
            

			$headers = "MIME-Version: 1.0" . "\r\n";
			$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
			$headers .= implode("\r\n", $header_pram);
			$headers = apply_filters('send_mail_to_customer_header', $headers);

			$title = cx_string_parser($title,$parse_data );
			$msg_string = cx_string_parser($template,$parse_data );

			return mail(
				$user_info["user_email"],
				$this->__( $title ) ,
				$msg_string,
				$headers 
			);

		}
		
		// email
		
	}

}