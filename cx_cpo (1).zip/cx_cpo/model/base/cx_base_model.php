<?php 

namespace cx_cpo;


if ( !class_exists("\\cx_cpo\\cx_base_model")) {

	class cx_base_model extends cx_base {
		
		protected $_table_name  	= "";
		protected $_primary_key		= "id";
		protected $_primary_filter	= "intval";
		protected $_schema	= [];
		protected $last_save_query;

		protected $conn;
		function __construct(){
			global $wpdb;
			$this->conn = $wpdb;
			parent::__construct();

		}
		public function get_table() {return $this->_table_name;}
		public function get_primary_key() {return $this->_primary_key;}

		public function get_last_save_query() {return $this->last_save_query;}

		public function query($sql){
			return $this->conn->get_results($sql);
		}
		public function get_feilds_as_options($set , $key_feild = null, $single_parsed_val = 0, $varibale_string = null) {

			if ( !$single_parsed_val) {
				$single_parsed_val = count($set) == 1 ? 1 : 0;
			}
			
			if ( $key_feild == null ) $key_feild = $this->_primary_key;
			if ( !is_array($set)) {
				$set = [$set , $this->_primary_key];	
			} else {
				$set = array_merge([ $this->_primary_key] , $set ) ;
			}
			

			$r_data = [];
			$res = $this->get_selected_feilds($set);

			if ( $varibale_string == null )  { 
				$varibale_string = "{{". implode("}} - {{", $set ) . "}}";
				
			};

			foreach ($res as $value) {

				$value = (array) $value;
				
				$key = $value[$key_feild];
				

				if ( $single_parsed_val ) {

					
					$r_data[ $key ] = cx_string_parser($varibale_string,$value);	

				} else {

					unset($value[$key_feild]);
					if ( count($value) == 1 ) {
						$r_data[ $key ] = array_values($value)[0];	
					} else {
						$r_data[ $key ] = $value;	
					}	
				}
				
				
			}
			return $r_data ;

		}
		public function get_selected_feilds($list=null,$where= null, $postpend = null){
			

			if( !$list) $list = ["*"];
			if( is_string($list) ) $list = explode(",", $list);


			$_table_name = $this->_table_name;
			$_primary_key = $this->_primary_key;

			$listStr = "";
			$listStr = implode(",", $list);
			
			//$listStr = substr($listStr, 0 , strlen($listStr ) - 1);
			$listStr = trim($listStr);
			$listStr = trim($listStr, ",");

			$query = "
				SELECT $listStr
				FROM $_table_name
			";

			if ( $where) {
				if ( is_array($where)) {
					$whrstr = $this->prams_to_sql_str($where);
					$query .= " WHERE $whrstr";
				} else {
					$query .= "WHERE $_primary_key = $where";	
				}
				

			}
			if ( isset($postpend) && strlen($postpend) ) {
				$query .= " $postpend ";
			}
			
			return  $this->query($query);
		}
		public function get($id = NULL){
			return $this->get_selected_feilds(null,$id );
		}
		public function get_by($prams=[],$feilds = [], $joins = [], $post_pend = ''){
			
			if ( count($feilds)) {
				$listStr = implode(",", $feilds);	
			} else {
				$listStr = "*";
			}
			

			$_table_name = $this->_table_name;
			$query = "
				SELECT $listStr
				FROM $_table_name
			";
			if (count($joins) >= 1){ 
				$joins_str = ''; 
				foreach ($joins as $key => $value) {

					$join_type = isset($value[2]) ? $value[2] : '';
					$joins_str .= " 
					$join_type JOIN $key on " . $value[0] . ' = ' . $value[1];
				}
				if ( strlen($joins_str)) {
					$query .= $joins_str;
				}
			}
			if (count($prams) >= 1){
				$whrstr = $this->prams_to_sql_str($prams);
				$query .= " 
				WHERE $whrstr";
			}
			$query .= $post_pend;

			

			return  $this->query($query);

		}
		protected function prams_to_sql_str($prams) {
			$whrstr = " ";

			foreach ($prams as $key => $p) {
				$opp = trim(strtolower($p[1]));
				
				switch (1) {
					case ($opp == 'in'):
						$vals = $p[2];
						$vals = is_array($vals) ? implode(",", $vals) : $vals;

						$whrstr .= "`". $p[0] . "` IN (" .$vals. ") AND ";	
						break;
					case ( strpos($p[2], "(") && strpos($p[2], ")") ):
						$whrstr .= "`".$p[0] . "` " . $p[1] . " " .$p[2]. " AND ";
					break; 
					default:
						$whrstr .= "`".$p[0] . "` " . $p[1] . " '" .$p[2]. "' AND ";	
						break;
				}
				
				
			}
			if (count($prams)){
				$whrstr= substr($whrstr, 0, strlen($whrstr) - 4);
			}
			
			return $whrstr;
		}
		// private function update($pram = []){
		// 	$table = $this->_table_name;
		// 	$sql = "
				
		// 	";
		// 	$res = $this->query($sql);
		// }

		public function filter_before_save($pram) {
			return $pram;
		}

		public function save($pram) {

			if ( !count($pram) ) return null;
			$pram = $this->filter_before_save($pram);
			
			$table = $this->_table_name;
			$col_names = "";
			$col_vals = ""; 
			$col_name_vals= "";
			if ( count($this->_schema) ) {

				foreach ($this->_schema as $key => $filters) {
					$key = esc_sql($key);
					if ( !isset($pram[$key] ) ) return null;
					$value = $pram[$key];
					$filters_fun = explode("|", $filters);
					foreach ($filters_fun as $f) {

						if ( is_array($f)) {
							$fun_name=  $f[0];
							$f[0] = $value;
							$value = call_user_func_array($fun_name,$f);
						} else {
							$value = $f($value);
						}
						
					}
					$value = esc_sql($pram[$key]);

					$col_names .=    "`$key` ,";
					$col_vals .=  " '$value' ,";
					$col_name_vals .= " '$key' = '$value',";

				}

			} else {
				
				foreach ($pram as $key => $value) {
					$key = esc_sql($key);
					$value = esc_sql($value);

					$col_names .=   "`$key` ,";
					$col_vals .=  " '$value' ,";
					$col_name_vals .= " `$key` = '$value',";
				}
				

			}
			$col_names = substr($col_names, 0, strlen($col_names) - 1);
			$col_vals = substr($col_vals,  0,strlen($col_vals) - 1);
			$col_name_vals = substr($col_name_vals, 0, strlen($col_name_vals) - 1);

			$sql = "
				INSERT INTO $table 
				($col_names) 
				VALUES($col_vals) 
				ON DUPLICATE KEY UPDATE    
				$col_name_vals
			";
			$this->last_save_query = $sql;
			

			$res = $this->query($sql);

			return $this->conn->insert_id;

			// if ( isset($pram[$this->_primary_key])) {
			// 	return $this->update($pram);
			// } else {
			// 	return $this->insert($pram);
			// }
		}
		public function update($pram, $where = []) {
			if ( !count($pram) ) return null;

			$table = $this->_table_name;

			$col_name_vals= "";
			foreach ($pram as $key => $value) { 
				$col_name_vals .= " `$key` = '$value',";
			}
			$col_name_vals = substr($col_name_vals, 0, strlen($col_name_vals) - 1);
			
			$whrstr = $this->prams_to_sql_str($where);

			$sql = "
				UPDATE `$table` 
				SET $col_name_vals
				WHERE $whrstr
			";
			$res = $this->query($sql);

		}

	}

}