<div class="elem-flx">
	<?php 
	foreach ($indexers as $heading => $opt) {
		?><div>
			<div class="box">
				<h3><?= $heading ?></h3><?php 

				if ( isset($opt['info'])) {
					$render_helper->list($opt['info']);	
				}
				
				$render_helper->form($opt['form']);

			?></div>
			
		</div><?php 
	}
	
?></div>


<style type="text/css">
	
	.elem-flx {display: block;}
	.elem-flx > * {width: 32%;display: inline-block;vertical-align: top;}
	.box {margin-right: 20px;background: white;padding: 20px 10px;border: 1px solid silver;margin-bottom: 10px;margin-top: 10px;}
	.elem-flx {padding-top: 10px;}

	.elem-flx h3 {margin-top: 0px;text-transform: capitalize;}

</style>