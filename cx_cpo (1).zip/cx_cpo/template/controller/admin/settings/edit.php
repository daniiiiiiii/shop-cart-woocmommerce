<div class="custom-form"><?php 

$render_helper->form($form);

?></div>