<div class="table-template-container">

	<div class="table-template-header">
		<input 
		type="number" 
		value="<?= isset($_GET['row_per_page']) ? $_GET['row_per_page'] : 50 ?>" 
		onchange='window.location.href = (new URLSearchParams( window.location.href).get("row_per_page") == null ) ? window.location.href + "&row_per_page=" + this.value : window.location.href.replace("&row_per_page=<?= $_GET['row_per_page'] ?>", ""  ) + "&row_per_page=" + this.value ;'>
	</div>

	<div class="table-container"><?php 

		$table->render();

	?></div>
</div>

<style type="text/css">
	.table-container table{border-collapse: collapse;background: white;width: 95%;margin: 20px 0px; }
	.table-container table thead th {background: #ededed;padding: 10px;border: 1px solid silver;border-collapse: collapse;text-transform: capitalize;font-weight: 500;}

	.table-container table tbody tr {border-bottom: 1px solid silver;}
	.table-container table tbody tr:hover {background: #ededed;}
	.table-container table tbody td {padding: 10px 0;text-align: center;}

	ul.table-pagination li {display: inline-block;margin: 0px;}
	ul.table-pagination li a {display: block;padding: 8px 14px;border: 1px solid silver;text-decoration: none;}
	ul.table-pagination li.current a {background: white;color: black;}

</style><?php 
