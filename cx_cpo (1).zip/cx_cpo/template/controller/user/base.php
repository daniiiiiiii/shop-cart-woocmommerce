<?php 

/*
	do not delete this file
	fallback for any controller if base template is not found
*/


?><div class="template-controller-default user-dashboard-page c-c"><?php 

	if ( isset($page_title) && strlen($page_title)) {
		?><h1><?php echo __($page_title,"xwt") ?></h1><?php 
	}
	

	if ( $flag_page_header ) { 
		
		?><header class="template-default-header s10 t3">

			<nav><?php 
					echo $page_header;
			?></nav>

		</header><?php 
	}

	?><div class="content-body-wraper xwt-controller p s10 t7">
		<div class="session-msg">
			<?php echo $session_msgs; ?>
		</div>
		<div class="content-body xwt-default-page-content"><?php 
				
				cx_load_template($content,0,[],$namespace);
				
		?></div>
	</div>
</div>
<style type="text/css">
	.user-dashboard-page h1,
	.user-dashboard-page h2,
	.user-dashboard-page h3 {text-transform: capitalize;}


	.user-dashboard-page .page-navigation.page-nav-header a {padding: 10px;text-transform: capitalize;border: 1px solid silver;display: block;margin: 0px;min-width: 140px;}
	.user-dashboard-page .page-navigation.page-nav-header li {margin: 0px;}
	.user-dashboard-page .page-navigation.page-nav-header li.active a {color: black;border: 1px solid black;}

	table.order-table-wraper, table.order-table-wraper td, table.order-table-wraper th {border: 1px solid silver;padding: 5px 8px;box-sizing: border-box;}

	table.order-table-wraper a {color: #60ab29;text-transform: capitalize;}

	.order-info-details ul {list-style: none;padding: 0px;margin: 0px;}
	.order-info-details ul {border: 1px solid silver;}
	.order-info-details li {border-bottom: 1px solid silver;margin: 0px;}
	.order-info-details li > * {padding: 5px 10px;}
	.order-info-details li > strong {color: #989898;border-right: 1px solid silver;text-transform: capitalize;}

	.grid-box > * {padding-right: 15px;padding-left: 15px;box-sizing: border-box;}

	.box {margin-bottom: 20px;}
	
</style>
