
<div class="account-wraper txt-center  c-c c-p">
	
		
		<div class="from-wraper login-from-wraper cx-user-page-forms">
			
				<header>
					<h2><?= __("Login","xwt") ?></h2>
					<p><?= __("Save time. Add your favorites tours and ideas in one convenient location, share your list with friends");?></p>
				</header>
				<?php 

					$render_helper->form($login_form);

				?>
				<div class="c-c c-w5 w8 mauto after-login">
					<p class="">
						<input type="checkbox" name="remember" value="1">
						<span><?= __("Remember me","xwt") ?></span>
					</p><?php 
					?><p class="txt-right">
						<span 
							class="hs-toogle-group blue-txt" 
							data-group=".cx-user-page-forms" 
							data-show=".forgot-password-form-wraper" ><?= __("Forgot your password ?") ?></span>
					</p>
				</div>
				<div class="new-here c8 mauto">
					<p class="txt-center"> <?= __("New here ?") ?>
						<span 
						class="hs-toogle-group blue-txt" 
						data-group=".cx-user-page-forms" 
						data-show=".signup-from-wraper"
						><?= __("Create an account") ?></span>
					</p>
				</div>
			
		</div><?php 
		
		?><div class="from-wraper forgot-password-form-wraper hide cx-user-page-forms">

			<header>
				<h2><?= __("Forgot password","xwt") ?></h2>
				<p><?= __("You will receive the email with your new password");?></p>
			</header>
			
			<?php 
				/*<p><?= __("Please provide the email from whcih you created the account and if we have we will resend you your password","xwt") ?>  </p>*/
			?>
			<?php 

				$render_helper->form($forget_password_form);

			?>
			<div class="new-here c8 mauto">
				<p class="txt-center"> 
					<span 
					class="hs-toogle-group blue-txt" 
					data-group=".cx-user-page-forms" 
					data-show=".login-from-wraper"
					><?= __("Login") ?></span> Or 

					<span 
					class="hs-toogle-group blue-txt" 
					data-group=".cx-user-page-forms" 
					data-show=".signup-from-wraper"
					><?= __("Create an account") ?></span>
				</p>	
			</div>
		</div><?php 

		?><div class="from-wraper signup-from-wraper hide cx-user-page-forms">
			<header>
				<h2><?= __("Sign Up","xwt") ?></h2>
				<p><?= __("Signup to see all the booking history");?></p>
			</header>
			<?php 

				$render_helper->form($signup_form);

			?>
			<div class="new-here c8 mauto">
				<p class="txt-center"> 
					<span 
					class="hs-toogle-group blue-txt" 
					data-group=".cx-user-page-forms" 
					data-show=".login-from-wraper"
					><?= __("Login") ?></span> Or 

					<span 
					class="hs-toogle-group blue-txt" 
					data-group=".cx-user-page-forms" 
					data-show=".forgot-password-form-wraper"
					><?= __("Forgot Password") ?></span>
				</p>	
			</div>
		</div>

	<?php 
	
?></div>
<style type="text/css">
	
	.from-wraper {
		margin-bottom: 25px;
	}
	.from-wraper h2,
	.from-wraper label {
		text-transform: capitalize;
	}

	.from-wraper {border: 4px solid #00cd98;border-radius: 6px;text-align: center;width: 80%;padding-bottom: 30px;}
	input.button {width: 80%;border-radius: 20px;text-transform: capitalize;background: #1593ff;padding: 10px;font-size: 1.1em;font-weight: 400;}

	.form-field.hs-form-field label {display: none;}

	input.button {width: 80%;border-radius: 20px;text-transform: capitalize;background: #1593ff;padding: 10px;font-size: 1.1em;font-weight: 400;}

	.form-field.hs-form-field label {display: none;}

	.form-field.hs-form-field input {width: 80%;border: 2px solid #cbcbcb;border-radius: 6px;padding: 10px;
    height: initial;
    margin-bottom: 8px;}

	.form-field label + * {width: 100%;}
	.from-wraper header p {width: 80%;margin: auto;margin-bottom: 25px;}

	.blue-txt {color: #1593ff;}

	.new-here {position: relative;margin-top: 10px;padding-top: 10px;}

	.new-here:after {position: absolute;content: '';width: 50%;height: 3px;background: #d9d9d9;top: 0px;left: 25%;border-radius: 100px;}

	.after-login {margin-top: 20px;}
	.after-login p {margin-bottom: 10px;}

	.session-msg {width: 80%;margin: auto;}
	
</style>