<div class='content-container'>
	<?php 

		$render_helper->form($user_from);
	
	?>	
</div>
