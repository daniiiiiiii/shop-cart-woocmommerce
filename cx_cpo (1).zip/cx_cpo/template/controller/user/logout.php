<h2><?= __("you are loged out","xwt") ?></h2>

<p> <a href="<?= $url ?>" ><?= __("click here","xwt") ?> </a> <?= __("to login or signup","xwt") ?> </p>