<h2><?= $form_titile ?></h2><?php 



$render_helper->form($page_form)

?>