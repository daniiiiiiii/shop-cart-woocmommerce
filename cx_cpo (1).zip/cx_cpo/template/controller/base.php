<?php 

/*
	do not delete this file
	fallback for any controller if base template is not found
*/


?><div class="template-controller-default c-c "><?php 

	if ( isset($page_title) && strlen($page_title)) {
		?><h1 class='s10'><?php echo __($page_title,"xwt") ?></h1><?php 
	}

	if ( $flag_page_header ) { 
		
		?><header class="template-default-header s10 t3 w2 ">

			<nav><?php  echo $page_header; ?></nav>

		</header><?php 
	}

	?><div class="content-body-wraper xwt-controller s10 t7 w8">
		<div class="p"><?php 
		
			?><div class="session-msg"><?php 
				echo $session_msgs; 
			?></div><?php 

			
			?><div class="content-body xwt-default-page-content"><?php 
				cx_load_template($content,0,[],$namespace);			
			?></div>
		</div>	
	</div>
</div>

