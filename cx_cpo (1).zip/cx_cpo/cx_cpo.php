<?php
/*
   Plugin Name: Custom Product Order - cpo
   Description: Custom Product Order by cipherox
   Version: 1.2
   Author: cipherox
   Author URI: https://cipherox.com/
   License: MIT
*/


/*

DELETE THE FTP FILE FIRST

in sublime just search and replace 
  
  - cx_cpo 
  - 

to you custom namespaces

*/





namespace cx_cpo;
use cx_cpo;

//ini_set('display_errors', E_ALL);  // debug mode 
ini_set('display_errors', 1);
//ini_set('display_startup_errors', 1);
error_reporting( E_ALL & ~E_NOTICE & ~E_WARNING & ~E_DEPRECATED  );

if ( !headers_sent() ) {
    if ( defined("PHP_SESSION_NONE")) {
        if (session_status() == PHP_SESSION_NONE) session_start();
    } else {
        if(session_id() == '') session_start();
    }
}


/* seting up setting page */

include(realpath(__DIR__ . "/core/cx_base_plugin.php") ); 

class cx_base extends cx_base_plugin {

    protected $_plugin_file = __FILE__;
    protected $_plugin_path = __DIR__;

    
    protected $_plugin_namespace  = "cx_cpo";
    protected $_plugin_user_roles = [
        'printer'=> [
            'label'     =>'Mag Printer',
            'model'     =>'printer',
            'capabilities'   =>[],
        ],
        'agent'=> [
            'label'     =>'agent',
            'model'     =>'agent',
            'capabilities'   =>[],
        ],
        'consultant'=> [
            'label'     =>'consultant',
            'model'     =>'consultant',
            'capabilities'   =>[],
        ],
        'enduser'=> [
            'label'     =>'enduser',
            'model'     =>'enduser',
            'capabilities'   =>[],
        ],

    ];

    protected $_plugin_db_schemea = [

       
    ];
    public function __construct() {
        parent::__construct();

        $key = $this->plugin_option(['general', 'config', 'google_map_api_key']);
        wp_enqueue_script( "google-map", "https://maps.googleapis.com/maps/api/js?key=".$key."&libraries=places&ver=5.4.2" );

    }
    // enqueue style or script on run time
    protected function enqueue_styles_and_script($base_assets = []) {
        $ns   = $this->_plugin_namespace;
        $uri  = $this->_plugin_uri;

        return array_merge($base_assets,[

            // $ns . "daterangepicker_js" => [
            //     "url"           => $uri . "/assets/third-party/datepicker/daterangepicker.js",
            //     "required"      => ['jquery'],    // optional
            //     "condition"     => is_admin(), // optional
            // ],
            

        ]);
    }
    protected function register_styles_and_script($base_assets = []) {

        $ns   = $this->_plugin_namespace;
        $uri  = $this->_plugin_uri;

        
        return array_merge($base_assets,[

            $ns . "_daterangepicker_js" => [
                "url"           => $uri . "/asset/third-party/datepicker/daterangepicker.js",
                "required"      => ['jquery'],    // optional
            ],
            
            $ns . "_daterangepicker_css" => [
                "url"           => $uri . "/asset/third-party/datepicker/daterangepicker.css",
            ],


        ]);
    }

}

$ins = new cx_base;
$ins->init_plugin();


// $api_key ="f064f75502msh3f53d7a353410d0p199072jsneef473bdddcb";

// $curl = $ins->helper("curl");

// $res = $curl->get("https://api-football-v1.p.rapidapi.com/v2/predictions/157462", [
//     "x-rapidapi-host : api-football-v1.p.rapidapi.com",
//     "x-rapidapi-key :  $api_key",
// ]);


// var_dump( json_decode($res,1) );

// die();
