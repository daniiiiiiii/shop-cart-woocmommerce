<?php 


$contoller_list = [];
foreach(glob(__DIR__ . "/controllers/*.php") as $file){
    
    require $file;
    $class_name = basename($file,".php");

    if (class_exists($class_name) && isset($class_name::$controller_options)) {
    	$contoller_list[$class_name] = $class_name::$controller_options;
    }
   
  
}




add_action( 'admin_menu',function() {

	global $contoller_list;
	

	foreach ($contoller_list as $class_name => $opt) {

		$action = $opt["page_type"];
	
		switch ($action) {
			
			case 'menu_page':
            /*psrent slud*/
			/*$page_title*/
			/*$menu_title*/
			/*$capability */ 
			/*$menu_slug */
			/*$function  */ 
			add_menu_page( 
				$opt["page_title"],
				$opt["menu_title"],
			    'manage_options',
				$opt["slug"], 
				$class_name::controller_instance()
			); 
			break;

			case 'options_page':
				/* page title */
				/* menu title */
				/* capability */
				/* page slug  */
				/* function   */
				add_options_page( 
					$opt["page_title"],
					$opt["menu_title"],
					'manage_options', 
					$opt["slug"],
					$class_name::controller_instance()
				);

			break;

			case 'submenu_page':
				/*psrent slud*/
				/*$page_title*/
				/*$menu_title*/
				/*$capability */
				/*$menu_slug */
				/*$function  */ 
				add_submenu_page( 
					$opt["parent_slug"],
					$opt["page_title"],
					$opt["menu_title"],
					'manage_options', 
					$opt["slug"], 
					$class_name::controller_instance()
				); 

			break;
			

			default:
				# code...
				break;
		}
		
		
	}
});