(function($) {
	$(function() {

		
		var inputs = $("#cx-cpo-order-form input");
		var form = inputs.parents("form")

		inputs.change(function (e) {
			e.preventDefault();
			
			
			var currency = hs.site.get("wc_currency_symbol");

			var form = $(this).parents('form');
			var mpb 	= form.find('.main-price-box');
			// if cup is slected, un select all mixute
			if ( $(this).hasClass('cx-input-size') ) {
				form.find('.cx-input-mixture').prop('checked',0)
			}
			// console.log('step_2: ', $(this).parents('#cx-cpo-order-form').find('.step_2'));
			if ( $(this).hasClass('cx-input-size') && $(this).prop("checked") ) {

				form.addClass("size-selected")
				form.find('.step_1').slideUp();
				form.find('.step_2').slideDown();

				var size_id = $(this).val();

				// setting up prices
				form.find('.mixture-item-container').find('.weightage').html('');
				form.find('.mixture-item-container').find('.additional-price').html('');
				
				form.find('.mixture-item-container input')
					.attr("data-weightage",'')
					.attr("data-price",'');
				


				form.find(".cx-input-mixture").each(function(k,v) {

					var mixture_val = $(v).val();

					price_gram = MIXTURE_PRICES[mixture_val ];

					weightage 	= price_gram['weightage'];
					if ( price_gram['weightage_' + size_id] ) {
						weightage 		= price_gram['weightage_' + size_id];	
					}
					weightage = Number(weightage);
					weightage = isNaN(weightage) ? 0 : weightage;


					price 	= price_gram['price'];
					if ( price_gram['price_' + size_id] ) {
						price 		= price_gram['price_' + size_id];	
					}
					price = Number(price);
					price = isNaN(price) ? 0 : price;
					

					var itm = $(v).parents('.mixture-item-container');
					
					itm.find('.weightage').html(weightage + " grams");
					if ( price ) {
						itm.find('.additional-price').html(currency + " " + price);	
					}
					
					$(v)
						.attr("data-weightage",weightage)
						.attr("data-price",price);



				})
				bg = $(this).next().find('img').attr("src")
				
				mpb.find('.pkg-img').css("background","url('"+bg+"')")

			} 

				

			
			
			

			size = form.find('.cx-input-size:checked');
			size_title = size.parents('.size-item-container').find('.title').text();
			mixtures = form.find('.cx-input-mixture:checked');


			// get cup weight
			var w = size.attr("data-weightage");
			w = Number(w);
			w = isNaN(w) ? 0 : w;

			// calculate currnt weitage
			var c_w = 0;
			var c_p = 0;
			mixtures.each(function (k,v) {
				c_w += Number( $(v).attr("data-weightage") );
				c_p += Number( $(v).attr("data-price") );
			});

			// if clicked is mixture and  weitage is fill alert a msg
			if ( c_w > w ) {
				$(this).prop("checked", 0);
				hs.utilities.lightBox({
				   heading : "Cannot select more then the selected Size : " + w,
				})
			}
			form.find('.cx-input-mixture').parents('.mixture-wraper').removeClass("mixture-active");
			mixtures = form.find('.cx-input-mixture:checked');
			mixtures.parents('.mixture-wraper').addClass("mixture-active");
			// recalculating weight and price

			total_price = size.attr("data-price");
			total_price = Number(total_price);

			var c_w = 0;
			var c_p = 0;
			mixtures.each(function (k,v) {
				c_w += Number( $(v).attr("data-weightage") );
				c_p += Number( $(v).attr("data-price") );
			});
			total_price += c_p;
			total_price = isNaN(total_price) ? 0 : total_price;

			c_w = isNaN(c_w) ? 0 : c_w;

			// update sidebar cart
			var cart 	= form.find('.cx-cpo-sidebar-cart');
			var inb  	= cart.find('.include-box');
			var mpb 	= cart.find('.main-price-box');

			mpb.find('.total-price').html(`
				${currency} ${total_price}
			`);

			if ( w ) {
				mpb.find('.size-info').html(`
					${w} grams | ${size_title} <span class='edit-link'>(edit)</span>
				`);
					
			} else {
				mpb.find('.size-info').html(``);
			}

			
			inb.html("");

			if ( !mixtures.length ) {

				inb.append(`
					<div class='no-ingredients txt-center'>
						<p>Add Package for your meal</p>
						<svg width="48" height="77" viewBox="0 0 48 77" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M3.86906 59.8819C4.15108 59.9034 4.44386 59.784 4.72589 59.8055C5.28993 59.8485 5.86474 59.7506 6.42878 59.7936C6.99283 59.8367 7.49175 59.8038 7.99067 59.771C8.77161 59.7597 9.47667 59.8135 10.1925 59.7263C10.8324 59.7042 11.4072 59.6062 12.0472 59.5841C12.1882 59.5949 12.2641 59.5298 12.4051 59.5405C12.481 59.4754 12.6327 59.3452 12.7737 59.3559C13.0773 59.0954 13.446 58.9108 13.8146 58.7262C14.1074 58.6067 14.3351 58.4113 14.6279 58.2919C15.0724 58.0421 15.5713 58.0093 16.0595 58.1175C16.4066 58.2149 16.7538 58.3123 17.0143 58.6158C17.2097 58.8435 17.405 59.0711 17.5245 59.3639C17.644 59.6567 17.6876 60.0146 17.5902 60.3618C17.5794 60.5028 17.4928 60.7089 17.482 60.8499C17.3195 61.1212 17.0811 61.4576 16.8534 61.6529C16.3222 62.1088 15.6608 62.4129 15.1403 62.7278C14.7716 62.9124 14.4681 63.1729 14.0994 63.3575C14.0235 63.4226 13.8066 63.477 13.7307 63.5421C13.3621 63.7267 13.0693 63.8462 12.7006 64.0308C12.332 64.2154 11.8223 64.3893 11.4536 64.5739C11.1608 64.6934 10.8029 64.737 10.5101 64.8565C11.2044 65.0513 11.9746 65.181 12.7555 65.1697C13.9595 65.1907 15.1743 65.0706 16.389 64.9506C17.4627 64.8198 18.3954 64.6782 19.404 64.4715C20.1957 64.3192 20.9223 64.091 21.6489 63.8628C22.3755 63.6345 23.0369 63.3304 23.7743 62.9612C26.5826 61.4736 28.8808 59.2378 31.244 57.0779C32.5448 55.8298 33.7805 54.5058 34.9511 53.1059C36.0458 51.7711 36.9995 50.4255 37.964 48.939C38.6141 47.8539 39.2642 46.7689 39.8492 45.608C40.0118 45.3367 40.1851 44.9244 40.3476 44.6532L41.1926 42.8738C41.3551 42.6026 41.4525 42.2554 41.6151 41.9842C41.9724 41.0186 42.4708 40.0638 42.8281 39.0983C43.0014 38.686 43.1747 38.2737 43.2721 37.9266C43.4454 37.5143 43.5536 37.0261 43.7269 36.6139C43.9868 35.9955 44.1817 35.3012 44.3765 34.6069C45.4157 31.2113 46.0427 27.6424 46.2466 24.0412C46.2568 22.9783 46.267 21.9153 46.2013 20.9175C46.0705 19.8437 45.9397 18.77 45.6679 17.6855C45.4068 16.46 45.0048 15.2238 44.6027 13.9875C44.1355 12.6753 43.5924 11.4283 42.9735 10.2464C41.855 8.1754 40.5956 6.09363 39.0977 4.34824C38.186 3.28582 37.1876 2.42955 36.1241 1.49739C35.9287 1.26973 35.8092 0.976948 36.0369 0.781571C36.2645 0.586195 36.5573 0.466709 36.7527 0.694368C37.2844 1.16045 37.8813 1.70241 38.3372 2.23362C38.9341 2.77559 39.5202 3.45857 40.0412 4.06566C41.0832 5.27984 42.0386 6.70016 42.8529 8.10972C43.6672 9.51929 44.4164 10.853 45.1549 12.3276C45.8282 13.7264 46.3498 15.2555 46.8713 16.7845C47.3929 18.3136 47.6975 19.897 47.7853 21.5348C47.9489 23.1074 47.8957 24.7344 47.8424 26.3614C47.7892 27.9884 47.519 29.6698 47.2596 31.2102C46.9895 32.8915 46.5891 34.4211 46.1128 36.0159C45.8205 37.0573 45.4524 38.1639 45.1602 39.2053C44.8895 39.9647 44.6295 40.5831 44.3588 41.3426C44.1748 41.8959 43.9148 42.5143 43.7308 43.0675C43.5575 43.4798 43.4601 43.827 43.2216 44.1633C42.8858 44.8469 42.6151 45.6063 42.2034 46.355C41.7809 47.2446 41.3584 48.1343 40.9467 48.883C39.4409 51.8883 37.5227 54.7204 35.2682 57.3141C34.6396 58.1171 33.87 58.9094 33.1762 59.6365C32.6343 60.2334 32.0272 60.7544 31.4852 61.3513C30.8781 61.8723 30.0326 62.7297 29.1978 63.446C28.5907 63.967 28.0595 64.4229 27.3873 64.868C26.7151 65.3131 26.0429 65.7583 25.3055 66.1275C24.5682 66.4967 23.755 66.9311 22.9525 67.2244C22.15 67.5177 21.2824 67.7352 20.5559 67.9634C19.4714 68.2352 18.3218 68.4311 17.248 68.5619C16.8901 68.6055 16.5322 68.6491 16.1743 68.6927C15.5995 68.7907 14.9596 68.8128 14.3196 68.8349C13.4628 68.9113 12.6167 68.8467 11.7707 68.7822C11.2825 68.674 10.8595 68.6417 10.3713 68.5335C10.3606 68.6745 10.4908 68.8263 10.4801 68.9673C10.8278 69.9867 11.0996 71.0712 11.3606 72.2967C11.3391 72.5787 11.3935 72.7956 11.4478 73.0125C11.5022 73.2294 11.5565 73.4463 11.535 73.7283C11.5894 73.9452 11.492 74.2924 11.4705 74.5744C11.3623 75.0625 11.2541 75.5507 10.9398 75.9522C10.788 76.0825 10.7121 76.1476 10.5604 76.2778C10.3327 76.4732 10.0399 76.5927 9.7579 76.5712C9.11797 76.5933 8.49956 76.3333 8.24983 75.8888C8.1847 75.8129 8.11958 75.737 8.04369 75.8021C7.71807 75.4227 7.52269 75.195 7.26219 74.8915C7.06682 74.6638 6.88221 74.2951 6.68683 74.0675C6.4371 73.6229 6.18736 73.1784 5.93762 72.7338C5.44891 71.7037 4.9602 70.6736 4.54737 69.5783C4.24327 68.9168 3.7874 68.3856 3.4833 67.7242C3.23356 67.2796 2.99458 66.6941 2.66896 66.3146C2.41922 65.8701 2.0936 65.4906 1.76797 65.1112C1.37723 64.6559 1.06236 64.1354 0.964401 63.5606C0.757711 62.552 0.984816 61.4347 1.75444 60.6424C2.36153 60.1214 3.15324 59.9691 3.86906 59.8819Z" fill="#4EBAA9"/>
</svg>

					</div>
				`)
			} else {

				mixtures.each(function(k,v) {
					
					checkbox = $(v);
					var cb_id = checkbox.attr("id");
					var label = checkbox.parents('.mixture-item-container').find('label[for="'+cb_id+'"]')
					
					var w = checkbox.attr("data-weightage");
					var p = checkbox.attr("data-price");
					p = Number(p);

					inb.append(`
						<div class='item c-c c-s10'>
						<label class='cx-btn-delete' for='${checkbox.attr("id")}'>
			<svg width="12" height="12" viewBox="0 0 12 12" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M12 1.21286L10.7871 0L6 4.78714L1.21286 0L0 1.21286L4.78714 6L0 10.7871L1.21286 12L6 7.21286L10.7871 12L12 10.7871L7.21286 6L12 1.21286Z" fill="#E04448"/>
</svg>

						</label>
							<strong class='title'>${ label.find('.title').text() }</strong>
							<span  class='weightage' >${w} grams</span>`
							+ (
								p ? `<span class='additional-price'>${currency} ${p} grams</span>` : ''
							) +
							
							`
						</div>
					`)
				});
				inb.append(`
					<div class='consumed-weight c-c c-s10'>
						<strong class='title'>Total Weight : ${ c_w } grams</strong>
						
					</div>
				`)			
			}
			

		});
		form.on("click","span.size-info",function() {
			
			var form = $(this).parents("form");
			form.find('.cx-input-size').prop('checked',0);
			form.find(".cx-input-mixture").prop("checked",0);	

			var mpb = form.find(".main-price-box")
			mpb.find('.pkg-img').css("background","none")

			form.find('.step_1').slideDown();
			form.find('.step_2').slideUp();

			form.removeClass("size-selected")

			inputs.first().trigger("change");
		})

		inputs.first().trigger("change");

		form.find('.cx-cpo-from-submit').click(function(e) {
			e.preventDefault();
			if (  !$(this).parents('form').find('.cx-input-size:checked').length ) {

				hs.utilities.lightBox({heading: "Plase Select any One of the Sizes "})
			} else {

				$(this).parents('form').submit();
			}
		})

		/*form.find(".mobile-cart").click(function() {
			
			if ( $(this).hasClass("cart-expanded-view") ) {

				$(this).removeClass("cart-expanded-view")
				$(this).addClass("cart-collapsed-view")

			} else {

				$(this).addClass("cart-expanded-view")
				$(this).removeClass("cart-collapsed-view")	

			}
		})*/

		
	})
})(jQuery)