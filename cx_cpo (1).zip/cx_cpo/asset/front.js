(function($){

	window.hs = (typeof window.hs == "undefined") ? {} : window.hs;
	
	window.hs.api_url = (typeof window.hs.api_url == "undefined") ? {} : window.hs.api_url;
	window.hs.api_url.media = (typeof window.hs.api_url.media == "undefined") ? {} : window.hs.api_url.media;

	var base_url = window.hs.site.get("url");

	window.hs.api_url.media.uploader 	= base_url + "/wp-json/cx_rest_mediauploader/v1/upload";
	window.hs.api_url.media.delete 		= base_url + "/wp-json/cx_rest_mediauploader/v1/delete";
	window.hs.api_url.media.get 		= base_url + "/wp-json/cx_rest_mediauploader/v1/get";
	window.hs.api_url.media.get_where 	= base_url + "/wp-json/cx_rest_mediauploader/v1/get_where";
	window.hs.api_url.media.crop 		= base_url + "/wp-json/cx_rest_mediauploader/v1/crop";
	window.hs.api_url.media.compress 	= base_url + "/wp-json/cx_rest_mediauploader/v1/compress";
	window.hs.api_url.media.get_by_urls = base_url + "/wp-json/cx_rest_mediauploader/v1/get_by_urls";
	window.hs.api_url.media.get_by_ids 	= base_url + "/wp-json/cx_rest_mediauploader/v1/get_by_ids";



	window.hs.hs_uploader = (function(){
		var public_funcs ={
			getType : function() {
			    return this.file.type;
			},
			getSize : function() {
			    return this.file.size;
			},
			getName : function() {
			    return this.file.name;
			},
			doUpload : function() {
			    var that = this;
			    var formData = new FormData();

			    // add assoc key values, this will be posts values
			    formData.append("file", this.file, this.getName());
			    formData.append("upload_file", true);
			    if( typeof this.opt.from_post !="undefined"){
			    	$.each(this.opt.from_post, function(form_k,from_v){
			    		formData.append(form_k, from_v);
			    	})
			    }

			    $.ajax({
			        type: "POST",
			        url: this.opt.post_url,
			        xhr: function () {
			            var myXhr = $.ajaxSettings.xhr();
			            if (myXhr.upload) {
			                myXhr.upload.addEventListener('progress', that.opt.progress, false);
			            }
			            return myXhr;
			        },
			        success: function (data) {
			        	if ( typeof that.opt.sucess !="undefined") {
			        		that.opt.sucess(data)
			        	}
			            
			        },
			        error: function (error) {
			        	if ( typeof that.opt.error !="undefined") {
			           		that.opt.error(error)
			           	}
			        },
			        async: true,
			        data: formData,
			        cache: false,
			        contentType: false,
			        processData: false,
			        timeout: 60000
			    });
			},
			
		}
		function hs_uploader(file,opt){
			this.file = file;
			this.opt = opt;
			if ( typeof this.opt.progress == "undefined" ){
				this.opt.progress = function(){}
			}
		};
		for (var func in public_funcs) {
			if(!public_funcs.hasOwnProperty(func)) continue;
			hs_uploader.prototype[func] = public_funcs[func]
		}
		return hs_uploader;
	})();




	$.fn.extend({
		hs_media_uploader:function(pram){

			set = this;

			window.hs = (typeof window.hs == "undefined") ? {} : window.hs;
			window.hs.media_uploader = (typeof window.hs.media_uploader == "undefined") ? {} : window.hs.media_uploader;
			window.hs.media_uploader.sync_images = (typeof window.hs.media_uploader.sync_images == "undefined") ? {} : window.hs.sync_images;


			// helper
			var helper = {
				get_file_type: function (url) {
					var item_url = url;
		            $type = item_url.split(".")
		            $type = $type[$type.length - 1];
		            $type = $type.toLowerCase();
		            return $type
				},
				get_file_title : function (url) {
					var item_title = url.split("/");
		            item_title = item_title[item_title.length-1];
		            return item_title
				},
				parse_json_catch: function(data_str) {
					var return_data = [];
					try {
						return_data = JSON.parse(data_str)
					} catch( exp ) {
						return_data = [];
					}
					return return_data;
				}
			}
			
			
			// data
			var model = {
				get_images_obj_from_ids: function($id_array , callback){
					$.ajax({
			        	url : window.hs.api_url.media.get_by_ids,
			        	method:"post",
			        	data: {ids: $id_array} 
			        }).done(function(res) {
			        	if ( typeof callback == "function" ) callback(res);
			        })
				},
				get_images_obj_from_urls: function($urls_array , callback){

					$.ajax({
			        	url : window.hs.api_url.media.get_by_urls,
			        	method:"post",
			        	data: {urls: $urls_array} 
			        }).done(function(res) {
			        	if ( typeof callback == "function" ) callback(res);
			        })
				},
				// download images of this user from the server
				sync_images_from_server : function ( url , callback ) {

					$.ajax({
						url : url + "?" + "key=uploader_id&value=" + pram.uploader_id
					}).done(function(res) {
						window.hs.media_uploader.sync_images = res.data;
						if ( typeof callback == "function" ) callback(res);
					})
				},
				delete_img_from_server: function (media_item_id, callback){

					$.ajax({
						url : pram.api.delete + "?id=" + media_item_id + "&uploader_id=" + pram.uploader_id 
					}).done(function(d) {
						if ( typeof callback == "function" ) callback(d);
					})

				}
 							
			}
			
			// html
			var render = {

				add_thumb_media_box : function (url,id,viewer , delete_btn = 1) {

		            item_title = helper.get_file_title(url);
		            $type =  helper.get_file_type(url);
		            item_url = url;
		            
		            switch($type) {
		            	case 'jpg':
		            	case 'jpeg':
		            	case 'png':
		            	case 'gif':
		            		viewer.append(
		            			"<div class='media-element img-container-icon item-type-"+$type+" ' data-url='"+item_url+"' data-id='"+id+"'>" +
		            				( delete_btn ? "<button class='delete-item' data-url='"+item_url+"' data-id='"+id+"' > x </button>" : "" ) +
		            				"<div class='thumbnail' style='background-image:url(\""+item_url+"\");'></div>\
		            				<label>"+item_title+"</label>\
		            			</div>"
		            		)
		            	break;

		            	default:
		            		viewer.append(
		            			"<div class='media-element a-container-icon item-type-"+$type+" ' data-url='"+item_url+"' data-id='"+id+"'>" +
		            				( delete_btn ? "<button class='delete-item' data-url='"+item_url+"' data-id='"+id+"' > x </button>" : "" ) +
		            				"<div class='thumbnail'></div>\
		            				<label>"+item_title+"</label>\
		            			</div>")

		            }
				},
				// setup images to the media lib
				genrate_images_in_meida_lib : function (){
					
					var box = $(".old_images .gallery");
					box.html("");
					$.each(window.hs.media_uploader.sync_images, function (k,v) {
						render.add_thumb_media_box(v.url,v.id,box)
						
					});
				},
				// genrates all thumbs in viewer
				genrate_all_thumbs : function (val , $elem , type, show_delete_btn = 1) {

					function _add($elem, f_val) {
						$.each(f_val, function(k,v) {
							render.add_thumb_media_box(v.url, v.id , $elem , show_delete_btn );
						})
					}

				    if ( ( typeof val  == "string" && val.length ) ) {

	    				$elem.html("")
	    				
	    				switch(type) {
	    				    case  "json" :
	    				        _add($elem, helper.parse_json_catch(val)  );
	    				    break;
	    				    case  "id" : 
	    				    	model.get_images_obj_from_ids(val.split(","), function(res) {
	    				    		_add($elem, res.data);
	    				    	});
	    				    break;
	    				    case  "url" : 
	    				    	model.get_images_obj_from_urls(val.split(","), function(res) {
	    				    		
	    				        	_add($elem, res.data);
	    				    	});
	    				    break;
	    				    
	    				}   
						
						
					}

				}
			}
			// add images inside media box (thumbs for old and newly upload images)
			
			
			
			

			
			// add item to input feild and genrate the thumbnail in viewer
			function add_mediaitem(input_feild,$cur_opt,viewer) {
				
				if ( typeof $cur_opt == "undefined") return;
				if ( typeof $cur_opt.id == "undefined") return;
				if ( typeof $cur_opt.url == "undefined") return;

				new_val = input_feild.val();


				if ( !new_val.length ) {
					new_val = "[]";
				}

				var should_add = 1;
				switch( input_feild.attr("data-valueFormate") ) {
				    case "json":

				        new_val = input_feild.val();
        				if ( !new_val.length ) new_val = "[]";
        				new_val = helper.parse_json_catch(new_val) ;

						$.each(new_val,function(k,v) {
							if ( (v.id+"") == ($cur_opt.id+"") ) {
								should_add = 0;
							}
						})
						if ( should_add ) { 

							new_val.push({
								id : $cur_opt.id,
								url : $cur_opt.url,
							});

							input_feild.val( JSON.stringify(new_val) )
						}
				    break;
				    
				    case "url":

    				    new_val =input_feild.val().split(",").filter(function(e) { return e.length});
				    	
				    	if ( new_val.indexOf($cur_opt.url) != -1) should_add = 0;
				    	
				    	if ( should_add ) {
				    		new_val.push($cur_opt.url);
							input_feild.val( new_val.join(",") )
				    	}
						
				    break;

				    case "id":
    				    new_val =input_feild.val().split(",").filter(function(e) { return e.length});
				    	
				    	if ( new_val.indexOf($cur_opt.id) != -1) should_add = 0;

				    	if ( should_add ) {
				    		new_val.push($cur_opt.id);
							input_feild.val( new_val.join(",") )
				    	}
						
				    break;
				    
				}
				if ( should_add ){
					render.add_thumb_media_box($cur_opt.url,$cur_opt.id,viewer);	
				}
				
				
				
				
			}
			// ?? remove item in input feild and genrate the thumbnail
			function remove_mediaitem(input_feild,id,viewer) {

				var new_val = input_feild.val();
				
				if ( !new_val.length ) {
					new_val = "[]";
				}
				new_val = helper.parse_json_catch(new_val);
				
				

				var to_remove = [];
				$.each(new_val,function(k,v) {
					if ( (v.id+"") == (id+"") ) {
						to_remove.push(k)
					}
					
				})
				$.each(to_remove, function(k,v) {
					new_val.splice(v,1)
				})
				
				input_feild.val( JSON.stringify(new_val) );
				viewer.find(".media-element[data-id='"+id+"']").remove();
				
				
			}
			// setup coropper
			function setup_croper(img,id,viewer,ths) {
				
				var croper = $("body").find(".hs_media_cropper")
				if ( !croper.length ) {
					$("body").append("<div class='hs_media_cropper'></div>");
					croper = $("body").find(".hs_media_cropper")
				}
				croper.html("<div class='croper-wraper'><img src='"+img+"'/></div>");

				var _croper = new Cropper( croper.find("img")[0], {
				  	aspectRatio: 1,
				  	viewMode: 1,
				})
				croper.append("<div class='hs-croper-btn-wraper'>\
						<button class='crop-btn-elem'>crop</button>\
						<button class='cancel-btn-elem'>cancel</button>\
				</div>")
				croper.find('.crop-btn-elem').click(function() {
					var data = _croper.getData()
					// class loading
					$prams = {
						id : id,
						uploader_id : pram.uploader_id,
						x : Math.ceil( data.x ),
						y : Math.ceil( data.y ),
						width : Math.ceil( data.width ),
						height : Math.ceil( data.height ),

					};
					$pram_str = '';
					$.each($prams, function(k,v) {
						$pram_str += k + "=" + v + "&";
					})
					$.ajax({
						url: pram.api.crop + "?" + $pram_str,
					}).done(function(res) {
						
						
						add_mediaitem(ths,res.data, viewer );
						remove_mediaitem(ths,id, viewer );
						croper.remove();
					})


				})
				croper.find('.cancel-btn-elem').click(function() {
					croper.remove();
				})
				
				
			}
			function remove_item_from_current_value(feild,id,url ) {
				
				var vals = feild.val();
				var type = feild.attr("data-valueFormate")

				switch(type) {
				       case "json": 

				            vals = vals.replace(/\\/g, '');
				            vals = helper.parse_json_catch(vals);
				            
				            var new_set = [];
				            $.each(vals, function(k,v) {
				            	if ( (v.id+"") != (id+"") ) {
				            		new_set.push(v)
				            	}
				            });
				            feild.val( JSON.stringify(new_set) );

				       break;
				       
				       
				       case "id": 
				       		var return_val = [];
					        var new_val  = vals.split(",");

					        $.each(new_val, function(kk,_id) {
					        	if ( (_id+"") != (id+"") ) {
					        		return_val.push(_id)
					        	}
					        });
					        feild.val( return_val.join(",") );

				       break;
				       
				       
				       case "url":
				           var return_val = [];
				           var new_val  = vals.split(",");

				           $.each(new_val, function(kk,_url) {
				           		if ( (_url+"") != (url+"") ) {
				           			return_val.push(_url)
				           		}
				           });
				           feild.val( return_val.join(",") );
				           
				       break;
				       
				}
			}

			return this.each(function(k,v){
			    
			   
				var ths = $(v);
				// checking if already initilize  then return
				if ( ths.hasClass("media-input-initilize") ) return ths;
				

				// setting up return type 
               	var return_type = "json";
               	var return_type_req = ths.attr("data-valueFormate");
               	if ( typeof return_type_req != "undefined" ) {
               	    
               		if ( ["url","id","json"].indexOf(return_type_req) != -1 ) { 
               			return_type = return_type_req
               		}
               	} 
               	ths.attr("data-valueFormate", return_type);
               	var is_miltiple = ( ths.attr("data-multiple") && ( ths.attr("data-multiple").toLowerCase() == "true" || Number(ths.attr("data-multiple")) ) ) 
		        is_miltiple = isNaN(is_miltiple) ? 0 : is_miltiple;

		        ths.attr("data-has_multiple", is_miltiple )
		          


		        // initilizing html and stuff
				ths.css("display","none");
				var container = ths.wrap("<div class='hs_media_uploader_element'>").parent();
				var button_text = "upload";
				if ( ths.attr("data-button_text") ) {
					button_text = ths.attr("data-button_text")
				}
				var extra_class ="";
				if ( ths.attr("data-thumb_wraper_class") ) {
					extra_class = ths.attr("data-thumb_wraper_class")
				}
				var child_class = 'c-s2';
				if ( !is_miltiple ) {
					child_class = 'c-s10 single-item'
				}
				container.append("<div class='hs-main-thumbs "+extra_class+" c-c "+child_class+" s10'></div><button class='hs_media_uploader_sandbox_trigger'> "+button_text+" </button>");
				
			


				// genrating thumbs first hand of previous value
				var type = ths.attr("data-valueFormate");
				render.genrate_all_thumbs( ths.val() , container.find(".hs-main-thumbs") , type , 0 );

				

				// sync images from media gallery on initilizeation
				model.sync_images_from_server( pram.api.get_where , function(){} );


				container.on("click",".hs_media_uploader_sandbox_trigger", function(e){

					e.preventDefault();


					var header_upload = "Upload";
					var header_library = "Media Library";

					var uploader_text = ths.attr("data-header-upload-text");
					var library_text = ths.attr("data-header-library-text");

					

					if ( typeof uploader_text != "undefined") header_upload = uploader_text;
					if ( typeof library_text != "undefined") header_library = library_text;


					$("body").append(
						"<div class='hs_media_uploader_sandbox_container'>\
							<div class='hs_media_uploader_sandbox'>\
								<header class='hs_media_uploader_sandbox_header'>\
									<button class='hs-media-action-btn upload-new active'> "+header_upload+" </button>" + 
									(( pram.media_library ) ? "<button class='hs-media-action-btn library'> "+header_library+" </button>" : '' ) + 
								"</header>\
								<div class='upload_new'><div class='media'></div></div>" +
								(( pram.media_library ) ? "<div class='old_images' style='display:none'><div class='gallery'></div></div>" : '' ) + 
								"<div class='progressbar'><div><span class='persentage'></span><div class='bar'><div></div></div></div></div>\
								<footer>\
									<input type='file' name='hs_media_uploader_sandbox_uploader_feild'/>\
								</footer>\
								<div class='popup-close-container'><button class='popup-close'> done </button></div>\
							</div>\
						</div>"
					);
					var media_box = $(".hs_media_uploader_sandbox_container")
					var input_feild = media_box.find('[name="hs_media_uploader_sandbox_uploader_feild"]')
					var viewer = media_box.find(".media");

					// genarating thumbs of current seleted elements
					var type = ths.attr("data-valueFormate");
					render.genrate_all_thumbs(ths.val(), viewer , type);


					// drag and drop option on upload container
					media_box.find(".media,.gallery").on({
						'dragover dragenter': function(e) {
							
							e.preventDefault();
							e.stopPropagation();
						},
						'drop': function(e) {

							e.preventDefault();
							e.stopPropagation();
							//our code will go here
							
							var dataTransfer =  e.originalEvent.dataTransfer;
							if( dataTransfer && dataTransfer.files.length) {

								var input = media_box.find('[name="hs_media_uploader_sandbox_uploader_feild"]');
								input[0].files = dataTransfer.files;
								input.trigger("change");

							}
					    }
					});

					// managing tabs
					media_box.find(".hs-media-action-btn").click(function() {
						
						media_box.find(".hs-media-action-btn").removeClass("active");
						$(this).addClass("active");
						if ( $(this).hasClass("upload-new") ) {

							media_box.find(".upload_new").css("display","block");
							media_box.find(".old_images").css("display","none");

						} else {
							
							render.genrate_images_in_meida_lib();
							model.sync_images_from_server( pram.api.get_where , render.genrate_images_in_meida_lib )
							media_box.find(".upload_new").css("display","none");
							media_box.find(".old_images").css("display","block");
						}
					});




					// when click the images from old , adding it to main container
					media_box.find(".old_images").on("click",".media-element",function(e){
						if ( $(e.target).hasClass("delete-item") ) {
							return;
						}


						// if only one can be sleected delete the previous one here
						var is_miltiple = ( ths.attr("data-multiple") && ( ths.attr("data-multiple").toLowerCase() == "true" || Number(ths.attr("data-multiple")) ) ) 
		        		is_miltiple = isNaN(is_miltiple) ? 0 : is_miltiple;
						if (!is_miltiple ) {
							ths.val("");
							viewer.html("")
						}
						// setting it up in main box
						add_mediaitem(ths, {
							id : $(this).attr("data-id"),
							url : $(this).attr("data-url"),
						}, viewer );

						media_box.find("button.hs-media-action-btn.upload-new").trigger("click");

					})

					media_box.find(".upload_new").on("click",".media-element",function(){

						if (!( $(this).prop("tagName") == "BUTTON" )) {
							if (pram.crop) {
								setup_croper($(this).attr("data-url"), $(this).attr("data-id") , viewer,ths);		
							}
							
						}
						
					})
					

		


					// removing lighbox and adding thumbs
					var sandbox = $(".hs_media_uploader_sandbox_container");
					sandbox.click(function(e){
						
						if( sandbox.is( e.target ))  {

							sandbox.remove();
							// genrating main thumb
							var type = ths.attr("data-valueFormate");
							render.genrate_all_thumbs( container.find(".wp-media-input").val(), container.find(".hs-main-thumbs"),type , 0)
							
						}
					});
					media_box.find('.popup-close').click(function(e) {
						sandbox.trigger("click");
					})
					
					// managind deleting items
					sandbox.on("click",".delete-item", function() {

						btn = $(this);
						elem = $(this).parent(".media-element");

						var media_item_id =btn.attr("data-id");
						var media_item_url =btn.attr("data-url");


						if ( btn.parents(".old_images" ).length ) {

							model.delete_img_from_server( media_item_id , function(d) {
								
								if ( d.status == 1) {
								
									elem.remove();
									// removing from current selected elemets too 
									remove_item_from_current_value(ths , media_item_id, media_item_url)
									

								} else {
									alert(d.msg)
								}

							});


						} else {

							elem.remove();
							// removing from current selected elemets too 
							
							remove_item_from_current_value(ths , media_item_id, media_item_url)

						}

						
					});



					var progressbar = sandbox.find(".progressbar")
					var feild = $('[name="hs_media_uploader_sandbox_uploader_feild"]');

					feild.on("change",function(e){
						var files = $(this)[0].files;
						$.each(files, function(k,v){

							var uploader = new hs.hs_uploader(v,{
								post_url : pram.api.upload,
								from_post: {
									uploader_id : pram.uploader_id,
								},
								progress: function(event){
									var percent = 0;
								    var position = event.loaded || event.position;
								    var total = event.total;
								   	if (event.lengthComputable) {
								        percent = Math.ceil(position / total * 100);
								    }
								    progressbar.css("display","block");
								    progressbar.find(".bar div").css("width",percent+"%");
								    progressbar.find(".persentage").html(percent+"%");
			    					
			    				},
								sucess: function(d){

									progressbar.css("display","none");
									feild.val("");

									var is_miltiple = ( ths.attr("data-multiple") && ( ths.attr("data-multiple").toLowerCase() == "true" || Number(ths.attr("data-multiple")) ) ) 
					        		is_miltiple = isNaN(is_miltiple) ? 0 : is_miltiple;
									if (!is_miltiple ) {
										ths.val("");
										viewer.html("")
									}

									add_mediaitem(ths, {
										url : d.data.url,
										id : d.data.id,

									},viewer);
									
									model.sync_images_from_server( pram.api.get_where , render.genrate_images_in_meida_lib )

									if ( typeof pram.compress != "undefined" && pram.compress ) {
										$.ajax({
											url : pram.api.compress + "?id=" + d.data.id
										})
									}

								},
								error: function(e){
									progressbar.addClass("failed")
									feild.val("");

									alert("failed");
									progressbar.css("display","none");
									console.log(e)
								},
							});
							uploader.doUpload();
						})
					})
					
				}); // click feild
				
				ths.addClass("media-input-initilize")


			})
		},
		
	});

	$(document).ready(function(){
		

		$(".wp-media-input").hs_media_uploader({
			api : {
				upload : window.hs.api_url.media.uploader,
				delete : window.hs.api_url.media.delete,
				get : window.hs.api_url.media.get,
				get_where : window.hs.api_url.media.get_where,
				crop : window.hs.api_url.media.crop,
				compress: window.hs.api_url.media.compress,
			},
			media_library:0,
			crop:0,
			compress:1,
			uploader_id: hs.site.get('cx_user'),

		});
		if ( typeof $().intlTelInput == "function") {
			//$(".intlTelInput").intlTelInput();
			$(".phone_field").intlTelInput().addClass("phone_field_initilized");
			
		}
		
	});


})(jQuery)