window.hs= (typeof window.hs=="undefined") ? {} : window.hs;
window.hs.$ = window.jQuery
(function($){




	$.fn.extend({

		hs_tabs: function($prams) {
			if ( typeof $prams == "undefined") $prams = {}
			$defaults = {
				firstElementClick : 1,
				checkBeforeChange: function($obj) { return 1 },
				callback : function($obj) {},
				callbackBefore: function($obj) {},
				collapse_all : 0,
				dynamic_tabs : {},
				controller_functions : {},
			}
			$.each($defaults,function(k,v) {
				$prams[k] = ( typeof $prams[k] == "undefined") ? v : $prams[k];
			});

			var set = this
			return set.each(function(k,v){

				var elem = $(v);
				if ( $prams.dynamic_tabs.length ) {
					$.each($prams.dynamic_tabs, function(k,v) {

						if ( !isNaN(Number(k)) ) k = hs.utilities.slugify(v);
						elem.append('<section data-cx_tabs_controller="'+k+'"><header>'+v+'</header><div></div></section>');

					})
				}
				var sections= elem.children("section"); 
				sections.css("display", "none");
				
				var lis= "";
				sections.each(function(k,v){

					if ( typeof $(v).attr("data-cx_tabs_controller") == "undefined" ) {

						text = $(v).children("header").text();
						$(v).attr("data-cx_tabs_controller" , hs.utilities.slugify(text) );
					}
					lis += "<li data-cx_tab_controller='"+$(v).attr("data-cx_tabs_controller")+"'>" + $(v).children("header").children().html() + "</li>";
					$(v).children("header").remove();
				})
				elem.prepend("<div class='hs_tabs_header clearfix'><ul>"+lis+"</ul></div>");
				elem.children(".hs_tabs_header").on("click","li",function(){
					
					if ( !$(this).hasClass("active") ) {

						if ( $prams.checkBeforeChange( $(this).index() ) ) {

							elem.children(".hs_tabs_header").find("li").removeClass("active")
							$(this).addClass("active");
							
							$prams.callbackBefore( $(this) );
							var index = $(this).index();

							var animation_duration = 400;
							sections.slideUp(animation_duration);

							setTimeout(function() {
								
								sections.eq(  index ).slideDown(animation_duration, function () {console.log("slideDown")});
							}, animation_duration + 1)
							
							$prams.callback( $(this).index() );

							$controller = $(this).attr("data-cx_tab_controller") ;
							body = sections.eq(  index ).children().last();
							if ( typeof $prams.controller_functions[$controller] ==  "function") {
								$prams.controller_functions[$controller]( body );
							}
						}
					} else {
						if ( $prams.collapse_all ) {

							sections.eq(  $(this).index() ).slideUp();	

						}
						
					}
					
				});

				
				if ( $prams.firstElementClick ) {
					elem.children(".hs_tabs_header").find("li").first().trigger("click")
				}
				
			})
		},
		multi_select: function($pram) {
            var set = this;
            var funcs = {
                get_elem_vals : function(elem, pram) {
                    $data = {}
                    $.each(pram.elements, function(k,v) {
                        var value = elem.find( v.element ).val()
                        $data["val_" + (k+1) ] = (value) ? value : "";
                    })
                    return $data;
                },
                add_option_to_field: function($elem,data, vals ){

                    $elem.html("");
                    $.each(data, function(k,v){
                        $elem.append("<option value='"+k+"'>"+v+"</option>")
                    });
                    if ( typeof $elem.attr("data-first") == "undefined") {
                    	
                    	$elem.attr("data-first","first");
                    	if ( typeof vals != "undefined") {
                    		$elem.val(vals)	
                    	} else {
                    		$elem.val($elem.attr("data-val"))	
                    	}
                    	
                    	
                    	if ( typeof $elem.attr("data-first") != "undefined" && $elem.attr("data-first").length ) {
                    		
                    	}
                    	
                    }
                    $elem.trigger("loaded");
                    $elem.trigger("change");

                },
                parse_string: function($str , $data ) {
                    
                    $.each($data, function(key,value){
                        $str = $str.replace(new RegExp( "{{" + key + "}}", 'g'), value)
                    });
                    return $str;
                }
            }
            return set.each(function(k,v) {
                var ths = $(v);
                ths.addClass("hs-multi-select")
                function trigger_change_select(e) {
                    // downaloding value
                    var val = $(this).val();
                    var current_elem_index = $(this).attr("data-key");
                    current_elem_index = Number(current_elem_index);

                    var next_elem_index = current_elem_index+1;
                    
                    if ( typeof $pram.elements[next_elem_index] != "undefined" ) {
                        // populating the values to the next feild

                        var next_elem_data = $pram.elements[next_elem_index];
                        var next_elem = ths.find( next_elem_data.element );

                        var $vals = funcs.get_elem_vals(ths, $pram);
                        
                        if ( typeof next_elem_data.select_options != "undefined" ) {

                        	funcs.add_option_to_field(next_elem, next_elem_data.select_options, next_elem_data.value )
                            if ( typeof next_elem_data.after_added_data != "undefined") {
                                next_elem_data.after_added_data()
                            }

                        } else {

                        	var $parsed_url = funcs.parse_string(next_elem_data.data_api,$vals);
	                        window.hs.utilities.ajax_cache($parsed_url, function(d) {

	                        	if ( typeof next_elem_data.adapt_data == "function") d = next_elem_data.adapt_data(d);	
	                        	
	                            funcs.add_option_to_field(next_elem, d , next_elem_data.value)
	                            if ( typeof next_elem_data.after_added_data != "undefined") {
	                                next_elem_data.after_added_data()
	                            }
	                        });
	                        
                        }



                    } else {
                       

                        if ( typeof $pram.after_all_loaded != "undefined") {
                            $pram.after_all_loaded();    
                        }
                        
                    }
                    
                }
                $.each( $pram.elements, function (k,data) {
                    var elem = ths.find(data.element)
                    elem.attr("data-key" , k);
                    elem.on("change", trigger_change_select);
                    $.each(data.events, function(event,callback) {
                        elem.on(event,callback);
                    })

                });
                var $fisrt_data =  $pram.elements[0];
                var $first_elem = ths.find( $pram.elements[0].element );

                if ( typeof $fisrt_data.select_options != "undefined" ) {

                	funcs.add_option_to_field($first_elem, $fisrt_data.select_options , $fisrt_data.value);
                    
                } else {

	                window.hs.utilities.ajax_cache( $fisrt_data.data_api, function(d) {
	                    if ( typeof $fisrt_data.adapt_data == "function") d = $fisrt_data.adapt_data(d);	
	                    
	                    funcs.add_option_to_field($first_elem, d , $fisrt_data.value)
	                    
	                })
	            }
                // pop
            });
        }, 
		hs_rowCopy: function(setup_html_callback,initial_data = []){
			
			if ( typeof setup_html_callback == "undefined") {
				var setup_html_callback = function(elem, val) {
					$.each(val, function(kk,v) {
						elem.find("[data-" + kk + "]").val(val);
					})
				}
			}
			var ths = this;
			function updateName(e){

                e.find(".hs-elem-row").each(function(k,v){
                	var attr_list = ["class", "id", "data-name"];

                    $(v).find("[data-name]").each(function(kk,vv){
                    	var val = $(vv).attr("data-name");
                    	val= val.replace("$_i",k);
                        $(vv).attr("name" ,  val );
                    });

                    
                    //$(v).html( $(v).html().split("{$_i}").join(k) ) 

                })
			}
			ths.each(function(k,v) {

				var e = $(v)
				e.addClass("array-val");

				e.html( "<div class='hs-elem-row'>" + e.html() +"</div>");

				var feild_html_str = e.html();
				e.append("<div class='btns'><button class='add'>+</button><button class='sub'>-</button></div>");
				e.find(".btns button").click(function(_e){
                    _e.preventDefault();
                    var arrayContainer = $(this).parents(".array-val");

                    if ( $(this).hasClass("add") ) {
                        $e = arrayContainer.find(".hs-elem-row").last();
                        $(feild_html_str).insertAfter($e);
                        var newlyadded = arrayContainer.find(".hs-elem-row").last();
                        newlyadded.find("input").val("");
                        newlyadded.find("textarea").val("");
                        newlyadded.attr("data-rowIndex" , arrayContainer.find(".hs-elem-row").length)

                    } else {

                        if ( arrayContainer.find(".hs-elem-row").length >= 2 ) {
                            arrayContainer.find(".hs-elem-row").last().remove();
                        } else if ( arrayContainer.find(".hs-elem-row").length == 1 ) {
                        	arrayContainer.find('[name]').val("");
                        }
                        
                    }
                    arrayContainer.find('[name]').trigger("change");
                    updateName( arrayContainer );
                    if ( initial_data && initial_data.length ) {
                    	elemValue = initial_data[ arrayContainer.find(".hs-elem-row").length-1 ];
                    } else{
                    	elemValue = "";
                    }
                    setup_html_callback(arrayContainer.find(".hs-elem-row").last(),elemValue, e );
                });
                updateName(e);
                // putting the default value
                if ( initial_data && initial_data.length ) {
                	elemValue = initial_data[0];
	                setup_html_callback(e.find(".hs-elem-row").last(),elemValue, e );
	                $.each(initial_data, function(k,v){
	                	if(k) e.find(".btns button.add").trigger("click");
	                })
                } else {
                	setup_html_callback(e.find(".hs-elem-row").last(),[], e );
                }
                
			});
		},
		hs_scrollToElems: function($pram) {
			var f = {
				scroll: function (top) {
					$([document.documentElement, document.body]).animate({
				        scrollTop: top
				    }, 1000);
				}
			}
			var set = this;
			$(document).on("click",".hs-slideto-elemet a", function() {
				
				var elem_id =  $(this).attr("data-scroll-to-element");
				var elem = $( "[data-scroll-element-url='" + elem_id + "']" );
				

				if ( typeof elem_id != "undefined" && elem.length ) {
					$(".hs-slideto-elemet").removeClass("active");
					$(this).addClass("active");

					var _top = elem.offset().top;
				
					f.scroll(_top - 100);
					

				}
				
			});
			if ( window.location.hash.length ) {

				hash = window.location.hash;
				hash = hash.replace("#","");
				var elem = $( "[data-scroll-element-url='" + hash + "']" );
				
				if ( elem.length ) {
					$("[data-scroll-to-element='"+hash+"']").addClass("active");
					var _top = elem.offset().top;
					f.scroll(_top  - 100);

				}
				

				
			}
			return set.each(function(k,v){

				var elem = $(v);
				$rand_id = Math.ceil( Math.random()*100000 );

				elem.attr("data-content-container", "$rand_id");
				$pram.scrollToContainer.append("<ul class='scroll-to-links hs-scroll-to ' data-content-source='$rand_id'></ul>");

				$ul = $pram.scrollToContainer.children(".scroll-to-links[data-content-source='$rand_id']")
				elem.children().each(function() {
				
					if ( typeof $(this).attr("data-link-title")  != "undefined") {
						
						$title = $(this).attr("data-link-title");
						$title_url = $title.replace(/[^a-zA-Z0-9- ]/g, '');
						$title_url = $title_url.replace(/[ ]/g, '-');
						$title_url = $title_url.replace(/[--]/g, '-');
						$title_url = $title_url.toLowerCase();

						$ul.append("<li class='hs-slideto-elemet'><a href='#"+$title_url+"' data-scroll-to-element='"+$title_url+"'>" + $title +"</a></li>");
						$(this).attr( "data-scroll-element-url",  $title_url );

					}
				});
			})
		},
		hs_filterElems : function($pram) {
			var set = this;
			return set.each(function(k,v) {
				var ths = $(v);
				ths.find( $pram.filter_selector ).click(function(e) {

					selector = $(this);
					ths.find( $pram.filter_selector ).removeClass("active");
					selector.addClass("active");

					$count = 0;

					$total = 99999;
					if ( typeof selector.attr("data-filter-result-count") != "undefined" ) {
						$total = Number ( selector.attr("data-filter-result-count") );
					}
					$prefix = ( typeof $pram.prefix == "undefined" ) ? "" : $pram.prefix;

					var slug = selector.attr("data-filter-name");

					
					ths.find( $pram.filter_element ).each(function(k,vv) {
						if ( $count >= $total ) return false;

						if (  !$(vv)[0].hasAttribute( "data-" + $prefix + "-"+ slug )  ) {
							$(vv).css("display", "none")
						} else {
							$(vv).css("display", "inherit");
							$count++;
						}

					})
				})
				ths.find( $pram.filter_selector ).first().trigger("click");
			})
		},
		setup_content: function(pram) {
			var set = this;
			return this.each(function(k,v){
				var ths = $(v);
				var parent = ths.parents(".form-field");
				
				parent.children().css("display","none");
				parent.append("<div class='dynamic-content-container'></div>");

				var container = parent.find(".dynamic-content-container");
				pram.content(container);
				container.hs_rowCopy(
					pram.callback,
					pram.data,
				);
				$.each(pram.events, function(name,obj) {
					container.on(name,obj.selector, obj.callback)
				})

			})
		},
		json_rowCopy_adaptor : function(pram) {
			var set = this;

			
			return this.each(function(k,v){ 

				var elem = $(v);
				var feild_value = elem.val();
				feild_value = ( feild_value == "" ) ? "[]" : feild_value;
				feild_value =  JSON.parse(feild_value);
				elem.setup_content({
					content: function(row) {
						row.append(pram.content)
					},
					callback: function(row , data , e ) {
						// populating value
						if ( data ) {
							$.each(data, function(k,v) {
								//v = atob(v); // decoding
								
								try {
    								v = decodeURIComponent(escape(atob(v)));
								} catch(e) {
								    v = atob(v);
								}
								row.find('[data-key="'+k+'"]').val(v).trigger("change")
							})
						}

						// if any media item, then reinitilizing
						var media_container = row.find(".media-container-wraper");
						if ( media_container.length ) {
							var input = media_container.find("input");
							row.prepend(input);
							media_container.remove();

						}
						if ( typeof jQuery.fn.initlize_wp_media_input != "undefined") {
							row.find("input.wp-media-input").initlize_wp_media_input();	
						}
						
					},
					data : feild_value,
					events: {
						change: {
							selector : "input,textarea,select",
							callback: function() {
								
								$data = [];
								_elem = $(this).parents(".form-field");
								_elem.find(".hs-elem-row").each(function(k,v){
									var ee = $(v);
									$elem = {};
									var condition_value = 0;
									ee.find("[data-key]").each(function(kk,vv){
										
										$key = $(vv).attr("data-key");
										$val = $(vv).val();
										if ( $val && $val.length ) {
											condition_value = 1;
										} 
										

										$elem[ $key ] =  btoa(unescape(encodeURIComponent($val))); // encoding
									})
									if ( condition_value ) {
										$data.push($elem);	
									}
									
								});
								elem.val( JSON.stringify($data) );
							}
						}
					}
				});
				elem.parents('.form-field').prepend(pram.header)
			})
		},
		number_feild: function() {
			var set = this;
			return set.each(function(k,v) {
				var elm = $(v);
				elm.attr("type","number");
				elm.wrap('<div class="number-selector">');
				elm.parent().prepend('<button type="button" onclick="this.nextElementSibling.stepDown();jQuery(this.nextElementSibling).trigger(\'change\');">-</button>');
				elm.parent().append('<button type="button" onclick="this.previousElementSibling.stepUp();jQuery(this.previousElementSibling).trigger(\'change\');">+</button>');
				

			})
		},
		click_toogle : function () {
			
			return this.each(function(k,v) {
				
				if ( !$(v).hasClass('hs-toogle-trigger-listning') ) {
					$(v).click(function() {
						var selector = $(this).attr("data-target");
						var state = $(this).attr("data-targetState");
						
						state = ( typeof state != "undefined" ) ? state : "hidden";
						if ( state == "hidden") {
							$(selector).slideDown();
							$(this).attr("data-targetState","visible");
						} else {
							$(selector).slideUp();
							$(this).attr("data-targetState","hidden");
						}
					})
					$(v).addClass('hs-toogle-trigger-listning')
				}
				
				
			});

		},
		value_toogle : function () {

			return this.each(function(k,v) {

				$(v).change(function() {

					var selector = $(this).attr("data-target_group");
					$(selector).slideUp();
					
					if ( $(this).attr("type") == "radio" || $(this).attr("type") == "checkbox") {
						if ( $(this).prop("checked") ) {
							
							$(selector).filter("[data-target_value='"+$(this).val()+"']").slideDown() ;	
						}

					} else {
						
						$(selector).filter("[data-target_value='"+$(this).val()+"']").slideDown() ;	
					}
					
				});
				$(v).trigger('change')
			});
		}	
	});

	

	

	
	var search_box = (function(param) {

		var search_box = function(param) {

			var ths = this;

			ths.place_changed = function() {
				
				var places = ths.autocomplete.getPlace();
				
				if ( typeof ths.prams.place_changed != "undefined" ) {
					ths.prams.place_changed.apply(this, [
						places,
						ths.prams
					]);
				}
			};

			ths.directionsService = new google.maps.DirectionsService;
			ths.search_feild = document.getElementById(param.elem_id);
			ths.autocomplete = new google.maps.places.Autocomplete(ths.search_feild, param.opt);
			ths.autocomplete.addListener('place_changed', ths.place_changed);
			ths.prams = param;


		}
		
		return search_box;

		
	})();

	window.hs.utilities = (typeof window.hs.utilities=="undefined") ? {} : window.hs.utilities;

	window.hs.utilities.slugify = function (text) {
	  return text.toString().toLowerCase()
	    .replace(/\s+/g, '-')           
	    .replace(/[^\w\-]+/g, '')       
	    .replace(/\-\-+/g, '-')         
	    .replace(/^-+/, '')             
	    .replace(/-+$/, '')
	    .replace(/[^a-z0-9]/gi, '-');            
	}	

	
	window.hs.utilities.google_auto_complete = function(elem_id, opt ) {
		return new search_box({

			elem_id : elem_id,
			// any pram you want , that can be accessable in placed_change
			lat_feild : opt.lat_feild,
			lon_feild : opt.lon_feild,

			opt : opt.autocomplete_options,

			place_changed : function(place,prams) {
				if ( prams.lat_feild && prams.lat_feild.length ) {
					prams.lat_feild.val( place.geometry.location.lat().toFixed(7) ).trigger("change")  	
				}
				if ( prams.lon_feild &&  prams.lon_feild.length ) {
					prams.lon_feild.val( place.geometry.location.lng().toFixed(7) ).trigger("change")  
				}
				if ( typeof opt.place_changed == "function" ) opt.place_changed(place);
				
			},
		});

	}
	window.hs.utilities.ajax_cache = function ( $url , _function )  {
        if ( typeof window.hs.ajax_cache_data == "undefined" ) window.hs.ajax_cache_data = {};
        if ( typeof window.hs.ajax_cache_data[$url]  == "undefined" ) {
            
            $("body").addClass("hs-ajax-cache-requesting")

            $.ajax({
                url : $url,
            }).done(function(d) {
                window.hs.ajax_cache_data[$url] = d;
                _function(d);
                $("body").removeClass("hs-ajax-cache-requesting")
                
            })

        } else {
            _function(window.hs.ajax_cache_data[$url]);
        }
    }

	window.hs.utilities.addslashes = function(string) {
	    return string.replace(/\\/g, '\\\\').
	        replace(/\u0008/g, '\\b').
	        replace(/\t/g, '\\t').
	        replace(/\n/g, '\\n').
	        replace(/\f/g, '\\f').
	        replace(/\r/g, '\\r').
	        replace(/'/g, '\\\'').
	        replace(/"/g, '\\"');
	}
	window.hs.utilities.lightBox = function (p) {

	    var typesDefault = {"name" : "popup",}
	    var p            = (!p)             ? {} : p;
	    p.heading    = (!p.heading)     ? "" : p.heading;
	    p.subHeading = (!p.subHeading)  ? "" : p.subHeading;
	    p.body       = (!p.body)        ? "" : p.body;
	    p.lock       = (!p.lock)        ? 0  : p.lock;
	    p.scroll     = (!p.scroll)      ? 0  : p.scroll;
	    p.new_popup  = (!p.new_popup)   ? 0  : p.new_popup;

	    p.type       = (!p.type)        ? typesDefault  : p.type;
	    p.size		 = (!p.size)        ? 'medium'  : p.size;  // small | medium | full | fullscreen


	    if ( p.new_popup ) {
	    	var id = Math.round(Math.random()*10000);

	    	var $e = $("<div id='hs-pop-up-"+id+"' class='hs-pop-up'><div class='popup-inner-container'></div></div>").insertBefore( $("body").children().first() ).children();
	    	var popup = $("#hs-pop-up-"+ id);	

	    } else {
	    	var  $e = $("#hs-pop-up").length ?  $("#hs-pop-up").html("<div class='popup-inner-container'></div>").children() : $("<div id='hs-pop-up' class='hs-pop-up'><div class='popup-inner-container'></div></div>").insertBefore( $("body").children().first() ).children();
	    	var popup = $("#hs-pop-up");	
	    }
	   	


	   	var content_class= '';
	   	content_class += (p.heading.length)		?  'has-heading ' : 'no-heading';
	   	content_class += (p.subHeading.length)	?  'has-subHeading ' : 'no-subHeading '
	   	content_class += (p.body.length)		?  'has-body ' : 'no-body ';
	   	content_class += (p.lock)				?  'is-lock ' : 'not-lock ';
	   	content_class += (p.scroll)				?  'is-scroll ' : ' ';

	   	content_class += 'size-' + p.size + " ";
	   	content_class += 'type-' + p.type.name + " ";

	   	content_class += ( p.lock && p.type.name == "confirm" || !p.lock ) ? "has-close-btn " : "no-close-btn ";


	   	popup.addClass( content_class )


	    $e.append("\
    		<header class='hs-pop-up-header'>" +
    			'<div class="header-content-container">' +
    				(( p.heading.length ) ? "<h3 class='light-box-heading'>"+ p.heading +"</h3>" : "") +
    				(( p.subHeading.length ) ? "<p class='popup-sub-heading'>"+ p.subHeading +"</p>" : "") +
    			'</div>' +
    			(
    				( p.lock && p.type.name == "confirm" || !p.lock ) ? 
		    			'<div class="header-close-btn-container">' +
		    				'<button class="type-confirm hs-false pop-up-close-btn ">&times;</button>' +
		    			'</div>' : 
		    			""
		    	) +

    		"</header>"+ 
    		(( p.body.length ) ? "<div class='light-box-body'>"+ p.body +"</div>" : "") 
    	)

	    if (p.type.name == "confirm") {

	    	p.type.succeed = ( typeof p.type.succeed == "undefined" ) ? function() {} :  p.type.succeed;
	    	p.type.failed = ( typeof p.type.failed == "undefined" ) ? function() {} :  p.type.failed;
	    	p.type.buttonText = ( typeof p.type.buttonText == "undefined" ) ? ["confirm","cancel"] : p.type.buttonText;

	        $e.append("\
	        	<footer class='pop-up-footer-fixed'>\
	        		<div class=''>\
	        			<button class='type-confirm hs-true'> "+p.type.buttonText[0]+" </button>\
	        			<button class='type-confirm hs-false btn-hollow'> "+p.type.buttonText[1]+" </button>\
	        		</div>\
	        	</footer>"
	        )

	        $e.find(".type-confirm").click(function(){
	            if ( $(this).hasClass("hs-true") ) {
	                var return_status = p.type.succeed( p.type.succeedPrams );
	                if ( !return_status ) return;
	            } else {
	                var return_status = p.type.failed();
	                if ( !return_status ) return;
	            }
	            
	            popup.remove()

	        })
	    } else {

	    	popup.find(".pop-up-close-btn").click(function() {
	    		popup.remove()
	    	})
	    }

	    if ( !p.lock ) {
	    	popup.click(function(e) { if ( $(e.target).is( $(this) )  ) $(this).remove();});
	    }

	    
	    

	    return $e;
	}

	hs.utilities.sumObjects = function(src , defaults ) {
	    
	   	jQuery.each(defaults , function(key,value){
	    	

	    	if ( typeof src[key] == "undefined") {
	    		src[key] = value;
	    	} else {
	    		if ( Array.isArray(value) || Array.isArray(src[key]) ) {

					if ( Array.isArray(value) && !Array.isArray(src[key])) {
						src[key] = [src[key]];
					}

					if ( !Array.isArray(value) && Array.isArray(src[key])) {
						value = [value];
					}
					src[key] = value.concat(src[key]);
				}
	    	}
	    });
	    return src;
	}
	hs.utilities.copyStringToClipboard = function  (str) {
	   // Create new element
	   var el = document.createElement('textarea');
	   // Set value (string to be copied)
	   el.value = str;
	   // Set non-editable to avoid focus and move outside of view
	   el.setAttribute('readonly', '');
	   el.style = {position: 'absolute', left: '-9999px'};
	   document.body.appendChild(el);
	   // Select text inside element
	   el.select();
	   // Copy text to clipboard
	   document.execCommand('copy');
	   // Remove temporary element
	   document.body.removeChild(el);
	}
	hs.utilities.replaceAll = function (find, replace, sub) {
	    return sub.replace(new RegExp(find.replace(/([.*+?^=!:${}()|\[\]\/\\])/g, "\\$1"), 'g'), replace);
	};

	// render helper
	window.hs.render = (typeof window.hs.render=="undefined") ? {} : window.hs.render;



	window.hs.render.html_attribute_string = function(list) {
		var str = "";
		$.each(list,function(key,value) {
			
			if ( !isNaN( Number(key) ) ) {
				if ( value.length ) str +=  hs.utilities.addslashes(value) + " ";
				return true; 
			}

			if ( !Array.isArray(value) && value && !value.length && isNaN(Number(key))  ) {
				if ( key.length ) str +=  hs.utilities.addslashes(key) + " ";
				return true; 
			}


			if ( Array.isArray(value) ) {

				val_str = "";
				$.each(value, function(k,v){
					val_str +=  hs.utilities.addslashes(v) + " ";
				})

			} else {
				val_str =  hs.utilities.addslashes(value);
			}
			str += ( key + '="' + val_str  + '" ' );
			
		});

		return str;
	}

	window.hs.render.form_field = function (name,value = null,options = {}) {
		var defaults = {
			"type"					: "text",
			"placeholder"			: "",
			"required"				: 0,
			"default"				: "",
			"show_label_as_option" 	: 0,
			"options_assoc" 		: 0,
			"show_label" 			: 1,
			"attributes" 			: {},
			"wraper_attributes"		: {},
			
		};
		options = hs.utilities.sumObjects(options, defaults);
		
		
		options.label = (typeof options.label != "undefined" ) ? options.label : name;
		options.value = ( value ) ? value : defaults.default;

		var wraper_attributes_default = {
			"class": [
				"form-field", 
				"hs-form-field", 
				hs.utilities.slugify( options.label ) + "-wraper",
			],

		};

		var attributes_default = {
			"class": [
				options.type + "-form-field",
				"hs-form-field-element",
			],
		};

		options.wraper_attributes = hs.utilities.sumObjects(options.wraper_attributes , wraper_attributes_default);
		options.attributes = hs.utilities.sumObjects(options.attributes , attributes_default);
		

		if ( options.required ) {
			options.attributes.class.push("required");
			options.attributes.required = "";
		}

		name = ( typeof options.attributes.multiple != "undefined" )  ? name + "[]" : name;
		options.attributes.name = name;
		options.attributes.placeholder = options.placeholder;
		options.attributes.value = options.value;
		

		var wraper_attributes_string = window.hs.render.html_attribute_string( options.wraper_attributes );

	

		var return_str = "";

		return_str += '<div ' + wraper_attributes_string + ' >'; 

		if (  options.type != "hidden" ) {

			if ( options.show_label ) {
				return_str += '<label >' + options.label + ( (options.required) ? '<span class="red"> *</span>' : '' ) + '</label >';
			}
		}
		return_str += '<div class="field-wraper">';

		switch (options.type) {
			case 'custom_html': 
				return_str += options.html;
			break;

			case 'textarea': 
				delete options.attributes.value;
				var attributes_string = window.hs.render.html_attribute_string( options.attributes );
				
				if ( typeof options.feildBeforeHtml != "undefined") return_str +=options.feildBeforeHtml;
				return_str += '<textarea '+attributes_string+'>'+options.value+'</textarea>';;
				if ( typeof options.feildAfterHtml != "undefined") return_str +=options.feildAfterHtml;

			break;
			
			case 'select':
				
				delete options.attributes.value;

				var attributes_string = window.hs.render.html_attribute_string( options.attributes );


				if ( typeof options.feildBeforeHtml != "undefined") return_str +=options.feildBeforeHtml;
				return_str += '<select '+attributes_string+'>';
					if ( options.show_label_as_option) {
						return_str += '<option> select ' + options.label + '</option>';
					}
					var assoc = ( Array.isArray(options.options) ) ? 0 : 1;
					$.each(options.options, function(k,v) {
						if (  Array.isArray(v) ) {
							return_str += '<optgroup label="'+k+'">';
							$.each(options.options, function(actual_key,actual_value) {
								var s = "";
								var a_val = ( assoc ) ? actual_key : actual_value;
								
								if (typeof options.value != "undefined") {
									if ( Array.isArray( options.value ) ) {
										for (var i = 0; i < options.value.length; i++) {
											var vvv = options.value
											if ( (vvv == a_val ) ) {
												s = "selected";	continue;
											}
										}
										
									} else {

										s = (options.value == a_val)  ? "selected" : "";
										
									}
									return_str += '<option value="'+a_val +'" '+s+' >'+ actual_value+ '</option>';
								}
							})
							return_str += '</optgroup>';
						} else {
							s = "";
							a_val = ( assoc ) ? k : v;

							if ( typeof options.value != "undefined" ) {

								if ( Array.isArray( options.value ) ) {

									for (var i = 0; i < options.value.length; i++) {
										var vvv = options.value
										if ( (vvv == a_val ) ) {
											s = "selected";	continue;
										}
									}
								} else {
									s = ( options.value == a_val )  ? "selected" : "";
								}
							}
							
							return_str +='<option value="'+ a_val +'" '+ s +' > '+v + '</option>';

						}
					})
				return_str += '</select>';
				if ( typeof options.feildAfterHtml != "undefined") return_str +=options.feildAfterHtml;

			break;
			case 'radio':
				return_str += '<ul class="radio-container">';

					var value_set = options.attributes.value;
					if ( !( typeof options.attributes.value == "object" && typeof options.attributes.value.length != "undefined" ) ) {
						value_set = [];
					}
					// console.log(options.options);
					$.each(options.options , function(key, val) {
						var value = "";
						var label = "";
						var checked = "";
						if ( options.options_assoc ) {
							value = key;
							
						} else {
							value = val;

						}

						if ( value_set.indexOf(value) != -1 ) {
							checked = "checked";
						} 

						label = val;
						options.attributes.value = val;
						options.attributes.type = "radio";
						options.attributes.checked = checked;

						options.attributes.id = hs.utilities.slugify("form-elem-" + options.attributes.name + options.attributes.value );
						var attributes_string = window.hs.render.html_attribute_string( options.attributes );
						return_str += '<li>';
							return_str += '<input '+attributes_string+' >';
							return_str += '<label for="'+options.attributes.id+'">'+label+'</label>';
						return_str += '</li>';

					})
					
						
				return_str += '</ul>';
			break;
			case 'checkbox':
				return_str += '<ul class="radio-container">';

					var value_set = options.attributes.value;
					if ( !( typeof options.attributes.value == "object" && typeof options.attributes.value.length != "undefined" ) ) {
						value_set = [];
					}
					console.log(options.options);
					$.each(options.options , function(key, val) {
						var value = "";
						var label = "";
						var checked = "";
						if ( options.options_assoc ) {
							value = key;
							
						} else {
							value = val;

						}
						delete options.attributes.checked
						if ( value_set.indexOf(value) != -1 ) {
							options.attributes.checked  = "checked";
						} 

						label = val;
						options.attributes.value = val;
						options.attributes.type = "checkbox";
						

						options.attributes.id = hs.utilities.slugify("form-elem-" + options.attributes.name + options.attributes.value );
						var attributes_string = window.hs.render.html_attribute_string( options.attributes );
						return_str += '<li>';
							return_str += '<input '+attributes_string+' >';
							return_str += '<label  for="'+options.attributes.id+'">'+label+'</label>';
						return_str += '</li>';

					})
					
						
				return_str += '</ul>';
			break;

			default:

				options.attributes.value = options.value;
				options.attributes.type = options.type;

				

				var attributes_string = window.hs.render.html_attribute_string( options.attributes );

				if ( typeof options.feildBeforeHtml != "undefined") return_str +=options.feildBeforeHtml;

				return_str += '<input '+ attributes_string +' />'
				
				if ( typeof options.feildAfterHtml != "undefined") return_str +=options.feildAfterHtml;
				
			break;


		}
		if ( typeof options.comment != "undefined" ) {
			return_str += '<span class="comment"><i class="icon-info info"></i><span>'+options.comment+'</span></span>';
		}
		if ( typeof options.after != "undefined" ) {
			return_str += options.after;
		}
		return_str += '</div>';

		
		return_str += "</div>";
		return return_str;

				
	}
	window.hs.render.table = function () {
		
	}
	window.hs.render.form = function () {
		
	}
	window.hs.render.list = function () {
		
	}
	window.hs.render.tr_list = function () {
		
	}


	window.hs.popup = (typeof window.hs.popup=="undefined") ? {} : window.hs.popup;

	// return the current active from elem
	hs.popup.get = function($arg) {

	}
	hs.popup.form = function ($data) {
		$defaults = {
			conform: function() {},
			cancel: function() {},
			validate: function() {},
			fields: [],

		}
	}

	$(document).ready(function() {
		$(".hs_tabs_init").hs_tabs();

		$(".hs_rowCopy_init").each(function(ll,vv){
			var data = {};
			if ( typeof $(vv).attr("data-scope") != "undefined" ) {
				var scope = $(vv).attr("data-scope");
				if ( typeof window[scope] == "undefined" ) {
					data = window[scope]
				}
			}
			$(vv).hs_rowCopy( undefined , data );	
		});

		$("body").on("click", ".hs-toogle-trigger", function(e) {
			var elem = $(e.target);
			if ( !elem.hasClass("hs-toogle-trigger-listning") ) {

				var selector = elem.attr("data-target");
				var state = elem.attr("data-targetState");
				
				state = ( typeof state != "undefined" ) ? state : "hidden";
				if ( state == "hidden") {
					$(selector).slideDown();
					elem.attr("data-targetState","visible");
				} else {
					$(selector).slideUp();
					elem.attr("data-targetState","hidden");
				}
			}
				
		});
		$(".hs-toogle-group").click(function() {

			var selector = $(this).attr("data-group");
			var state = $(this).attr("data-show");

			console.log(selector);
			console.log(state);
			
			$(selector).filter(state).slideDown();
			$(selector +":not(" + state + ")").slideUp();
	
		});
		$(".hs-toogle-trigger").click_toogle();
		$(".hs-toogle-by-value-trigger").value_toogle();
		$(".number_feild_init").number_feild();
		$(".datetimepicker_init").each(function(k,v){

			if ( typeof $(v).datetimepicker == "function" ) {
				$(v).datetimepicker();
			}
		});
		if ( typeof jQuery.fn.lazyload != 'undefined') $('img.lazyload').lazyload()	
		if ( typeof jQuery.fn.select2 != 'undefined') $('.select2_init').select2()	
		
		
		
	})
	

}(window.jQuery))
