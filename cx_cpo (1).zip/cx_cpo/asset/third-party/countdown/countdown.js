
/*Downloaded from https://www.codeseek.co/doriancami/draft-countdown-jEJvaV */
(function($) {

    $.fn.extend({
        countdown : function() {
            var Countdown = {

                animateFigure: function($el, value) {
                
                    var that         = this;
                    var $top         = $el.find('.top');
                    var $bottom      = $el.find('.bottom');
                    var $back_top    = $el.find('.top-back');
                    var $back_bottom = $el.find('.bottom-back');

                    $el.attr("data-time-value" , value)

                    // Before we begin, change the back value
                    $back_top.find('span').html(value);

                    // Also change the back bottom value
                    $back_bottom.find('span').html(value);

                    // Then animate
                    TweenMax.to($top, 0.8, {
                        rotationX           : '-180deg',
                        transformPerspective: 300,
                        ease                : Quart.easeOut,
                        onComplete          : function() {

                            $top.html(value);

                            $bottom.html(value);

                            TweenMax.set($top, { rotationX: 0 });
                        }
                    });

                    TweenMax.to($back_top, 0.8, { 
                        rotationX           : 0,
                        transformPerspective: 300,
                        ease                : Quart.easeOut, 
                        clearProps          : 'all' 
                    });    
                },
              
                checkHour: function(value, $el_1, $el_2, $el_3 = null) {
                
                    var val_1       = value.toString().charAt(0),
                        val_2       = value.toString().charAt(1),
                        fig_1_value = $el_1.find('.top').html(),
                        fig_2_value = $el_2.find('.top').html();

                    if ( $el_3 ) {

                        val_3 = value.toString().charAt(2);

                        fig_3_value = $el_3.find('.top').html();

                    }

                    if ( !$el_3  ) {

                        if(value >= 10) {

                            // Animate only if the figure has changed
                            if(fig_1_value !== val_1) this.animateFigure($el_1, val_1);
                            if(fig_2_value !== val_2) this.animateFigure($el_2, val_2);

                        } else {

                            // If we are under 10, replace first figure with 0
                            if(fig_1_value !== '0') this.animateFigure($el_1, 0);
                            if(fig_2_value !== val_1) this.animateFigure($el_2, val_1);
                        }  
                    } else {

                        if(value >= 100) {

                            // Animate only if the figure has changed
                            if(fig_1_value !== val_1) this.animateFigure($el_1, val_1);
                            if(fig_2_value !== val_2) this.animateFigure($el_2, val_2);
                            if(fig_3_value !== val_3) this.animateFigure($el_3, val_3);

                        } else if(value >= 10) {

                            // If we are under 10, replace first figure with 0
                            if(fig_1_value !== '0') this.animateFigure($el_1, 0);
                            if(fig_2_value !== val_1) this.animateFigure($el_2, val_1);
                            if(fig_3_value !== val_2) this.animateFigure($el_3, val_2);

                        } else {

                            // If we are under 10, replace first figure with 0
                            if(fig_1_value !== '0') this.animateFigure($el_1, 0);
                            if(fig_2_value !== '0') this.animateFigure($el_2, 0);
                            if(fig_3_value !== val_1) this.animateFigure($el_3, val_1);
                        }
                    } 
                      
                }
            };
            return this.each(function(k,v) {

                var elem = $(v);
                if ( elem.hasClass("countdown_initilized")) return 1;
                elem.addClass("countdown_initilized");
                
                var time = $(v).attr("data-time");
                time = Number(time);

                var count_down_time = time - new Date().getTime();
                elem.attr("data-countdown-left", count_down_time);

                html = `
                    <div class="countdown"><!--

                        --><div class="bloc-time days" >
                          <span class="count-title">Days</span>

                          <div class="figure days days-1" data-time-value=0>
                            <span class="top">0</span>
                            <span class="top-back">
                              <span>0</span>
                            </span>
                            <span class="bottom">0</span>
                            <span class="bottom-back">
                              <span>0</span>
                            </span>
                          </div>

                          <div class="figure days days-2" data-time-value=0>
                            <span class="top">0</span>
                            <span class="top-back">
                              <span>0</span>
                            </span>
                            <span class="bottom">0</span>
                            <span class="bottom-back">
                              <span>0</span>
                            </span>
                          </div>

                          <div class="figure days days-3" data-time-value=0>
                            <span class="top">0</span>
                            <span class="top-back">
                              <span>0</span>
                            </span>
                            <span class="bottom">0</span>
                            <span class="bottom-back">
                              <span>0</span>
                            </span>
                          </div>

                        </div><!--

                        --><div class="bloc-time hours" >
                          <span class="count-title">Hours</span>

                          <div class="figure hours hours-1">
                            <span class="top">0</span>
                            <span class="top-back">
                              <span>0</span>
                            </span>
                            <span class="bottom">0</span>
                            <span class="bottom-back">
                              <span>0</span>
                            </span>
                          </div>

                          <div class="figure hours hours-2">
                            <span class="top">0</span>
                            <span class="top-back">
                              <span>0</span>
                            </span>
                            <span class="bottom">0</span>
                            <span class="bottom-back">
                              <span>0</span>
                            </span>
                          </div>
                        </div><!--

                        --><div class="bloc-time min" >
                          <span class="count-title">Minutes</span>

                          <div class="figure min min-1">
                            <span class="top">0</span>
                            <span class="top-back">
                              <span>0</span>
                            </span>
                            <span class="bottom">0</span>
                            <span class="bottom-back">
                              <span>0</span>
                            </span>        
                          </div>

                          <div class="figure min min-2">
                           <span class="top">0</span>
                            <span class="top-back">
                              <span>0</span>
                            </span>
                            <span class="bottom">0</span>
                            <span class="bottom-back">
                              <span>0</span>
                            </span>
                          </div>
                        </div><!--

                        --><div class="bloc-time sec" >
                          <span class="count-title">Seconds</span>

                            <div class="figure sec sec-1">
                            <span class="top">0</span>
                            <span class="top-back">
                              <span>0</span>
                            </span>
                            <span class="bottom">0</span>
                            <span class="bottom-back">
                              <span>0</span>
                            </span>          
                          </div>

                          <div class="figure sec sec-2">
                            <span class="top">0</span>
                            <span class="top-back">
                              <span>0</span>
                            </span>
                            <span class="bottom">0</span>
                            <span class="bottom-back">
                              <span>0</span>
                            </span>
                          </div>
                        </div>
                      </div>
                    </div>
                    `;
                elem.html(html);

                var days   = elem.find('.bloc-time.days .figure')
                var hours   = elem.find('.bloc-time.hours .figure')
                var minutes = elem.find('.bloc-time.min .figure')
                var seconds = elem.find('.bloc-time.sec .figure')

                var $day_1 = days.eq(0),
                    
                    $day_2 = days.eq(1),
                    $day_3 = days.eq(2),

                    $hour_1 = hours.eq(0),
                    $hour_2 = hours.eq(1),
                    $min_1  = minutes.eq(0),
                    $min_2  = minutes.eq(1),
                    $sec_1  = seconds.eq(0),
                    $sec_2  = seconds.eq(1);

                var values_days         =  Math.floor( count_down_time / (24*60*60*1000) );
                var values_hours        =  Math.floor( (count_down_time - (values_days*(24*60*60*1000))) / (60*60*1000));
                var values_minutes      =  Math.floor( (count_down_time -  (values_days*(24*60*60*1000)) - (values_hours*(60*60*1000)) )/(1000*60) )
                var values_seconds      =  Math.floor(  (count_down_time - (values_days*(24*60*60*1000)) -(values_hours*(60*60*1000)) - (values_minutes*(60*1000))  )/(1000) )
                var total_seconds       = count_down_time/1000;

                elem
                    .addClass("initial-days-digit-" + values_days.toString().length )
                    .addClass("initial-hours-digit-" + values_hours.toString().length )
                    .addClass("initial-minutes-digit-" + values_minutes.toString().length )
                    .addClass("initial-seconds-digit-" + values_seconds.toString().length )



                var countdown_interval = setInterval(function() {

                    if(total_seconds > 0) {

                        --values_seconds;              

                        if(values_minutes >= 0 && values_seconds < 0) {

                            values_seconds = 59;
                            --values_minutes;
                        }

                        if(values_hours >= 0 && values_minutes < 0) {

                            values_minutes = 59;
                            --values_hours;
                        }
                        if(values_days >= 0 && values_hours < 0) {

                            values_hours = 23;
                            --values_days;
                        }

                        // Update DOM values_
                        // Hours

                        Countdown.checkHour(values_days, $day_1, $day_2,$day_3);

                        Countdown.checkHour(values_hours, $hour_1, $hour_2);

                        // Minutes
                        Countdown.checkHour(values_minutes, $min_1, $min_2);

                        // Seconds
                        Countdown.checkHour(values_seconds, $sec_1, $sec_2);

                        --total_seconds;
                        elem.addClass("counter-shown");

                    } else {
                        clearInterval(countdown_interval);
                    }
                }, 1000);
                
            })
        }
    });

    $(function() {
        $(".countdown_init").countdown();
    })
})(jQuery)






