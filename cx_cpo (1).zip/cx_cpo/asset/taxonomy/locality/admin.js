(function($) {
	$(function() {

		if ( $("body").hasClass("taxonomy-cx_cpo_locality") ) {

			window.hs.utilities.google_auto_complete('tag-name', {

				lat_feild : $("#cx_cpo_taxonomy_locality_lat"),
				lon_feild : $("#cx_cpo_taxonomy_locality_lon"),
				
				place_changed: function (d) {
					console.log(d)
				}
			});	

		}
		
	})
})(jQuery)