(function($) {
    $(function() {

        if ( $("body").hasClass("post-type-cx_cpo_property") ) {

            window.hs.utilities.google_auto_complete('cx_cpo_property_address', {

                lat_feild : $("#cx_cpo_property_lat"),
                lon_feild : $("#cx_cpo_property_lon"),
                
                place_changed: function (d) {
                    console.log(d)
                }
            }); 

            $('#cx_cpo_property_video_gallery').json_rowCopy_adaptor({
            
                content : `
                    <div class='c-c s10 data-row'><!--
                      

                        --><div class='s5'>
                            <input class='s9' data-name='cx[$_i][title]'  data-key='title'/>
                        </div><!-- 

                        --><div class='s5'>
                            <input class='s9' data-name='cx[$_i][url]'  data-key='url'/>
                        </div><!-- 

                       

                    --></div>
                    <hr/>
                `,
                header : ` <div class='c-c s10 attr-header'><!--
                        --><div class='s5'>video title</div><!-- 
                        --><div class='s5'>video url</div><!-- 
                       
                    </div>
                `
            });

        }

    })
})(jQuery)
		