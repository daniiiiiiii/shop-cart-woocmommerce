(function($) {
    $(function() {

        if ( $("body").hasClass("post-type-cx_cpo_agency") ) {

            window.hs.utilities.google_auto_complete('cx_cpo_agency_public_address', {

                lat_feild : $("#cx_cpo_agency_address_lat"),
                lon_feild : $("#cx_cpo_agency_address_lon"),
                
                place_changed: function (d) {
                    console.log(d)
                }
            }); 

            $('#cx_cpo_agency_directors').json_rowCopy_adaptor({
            
                content : `
                    <div class='c-c s10 data-row'><!--
                      

                        --><div class='s5'>
                            <input class='s9' data-name='cx[$_i][name]'  data-key='name'/>
                        </div><!-- 

                        --><div class='s5'>
                            <input class='s9 wp-media-input' data-valueFormate='id' data-name='cx[$_i][img]'  data-key='img'/>
                        </div><!-- 

                       

                    --></div>
                    <hr/>
                `,
                header : ` <div class='c-c s10 attr-header'><!--
                        --><div class='s5'>director name</div><!-- 
                        --><div class='s5'>img</div><!-- 
                       
                    </div>
                `
            });

            $('#cx_cpo_agency_employee').json_rowCopy_adaptor({
            
                content : `
                    <div class='c-c s10 data-row'><!--
                      

                        --><div class='s25'>
                            `+
                                hs.render.form_field('cx[$_i][agent]', null, {
                                    type : "select",
                                    show_label : 0,
                                    options : hs.site.get("agent_list"),
                                    attributes : {
                                        "data-name" : "cx[$_i][agent]",
                                        "data-key" : "cx[$_i][agent]",
                                    },
                                })
                            +`
                        </div><!--

                        --><div class='s25'>
                            `+
                                hs.render.form_field('cx[$_i][role]', null, {
                                    type : "select",
                                    show_label : 0,
                                    options : {
                                        1 : 'PARTNER',
                                        2 : 'PRINCIPAL',
                                        3 : 'SALES CONSULTANT',
                                    },
                                    attributes : {
                                        "data-name" : "cx[$_i][role]",
                                        "data-key" : "cx[$_i][role]",
                                    },
                                })
                            +`
                        </div><!-- 

                        --><div class='s25'>
                            `+
                                hs.render.form_field('cx[$_i][permissions]', null, {
                                    type : "select",
                                    show_label : 0,
                                    options : {
                                        1 : 'PARTNER',
                                        2 : 'PRINCIPAL',
                                        3 : 'SALES CONSULTANT',
                                    },
                                    attributes : {
                                        "data-name" : "cx[$_i][permissions]",
                                        "data-key" : "cx[$_i][permissions]",
                                    },
                                })
                            +`
                        </div><!-- 

                        --><div class='s25'>
                            `+
                                hs.render.form_field('cx[$_i][role]', null, {
                                    type : "select",
                                    show_label : 0,
                                    options : {
                                        1 : 'PARTNER',
                                        2 : 'PRINCIPAL',
                                        3 : 'SALES CONSULTANT',
                                    },
                                    attributes : {
                                        "data-name" : "cx[$_i][role]",
                                        "data-key" : "cx[$_i][role]",
                                    },
                                })
                            +`
                        </div><!-- 

                       

                    --></div>
                    <hr/>
                `,
                header : ` <div class='c-c s10 attr-header'><!--
                        --><div class='s25'>agent </div><!-- 
                        --><div class='s25'>role</div><!-- 
                        --><div class='s25'>permissions</div><!-- 
                        --><div class='s25'>actions</div><!-- 
                       
                    </div>
                `
            });

        }

    })
})(jQuery)
        