(function ($) {
	// base elem
	$.fn.extend({
		initlize_wp_media_input : function(prams){
			
			
			var set = this;
			
			var render = {
				append_thumbs :  function($set , viewer ) {
					$.each($set,function(k,v){
					
						var item_url = v.url;
			            var item_title = item_url.split("/");
			            item_title = item_title[item_title.length-1];
						
			            $type = item_url.split(".")
			            $type = $type[$type.length - 1];

			            $type = $type.toLowerCase();
			            render.append_thumb(viewer,$type,v.id,item_url,item_title );
					})
				},
				append_thumb: function(viewer, type , id ,item_url , item_title ) {
					switch(type) {
		            	case 'jpg':
		            	case 'png':
		            	case 'gif':
		            		viewer.append("<div><a data-id='"+id+"' href='"+item_url+"' download ><img style='width: 70px;' src='"+item_url+"' /></a></div>")
		            	break;

		            	default:
		            		viewer.append("<div><a data-id='"+id+"' href='"+item_url+"' download >"+item_title+"</a></div>")

		            }
				}
			}
			
			return this.each(function() {


				var ths = $(this);

				if ( ths.hasClass("media-input-initilize") ) return ths;
				ths.addClass("media-input-initilize");
				
				
				if ( !ths.attr("data-valueFormate") ) {
					ths.attr("data-valueFormate", "json")
				}

				var container = ths.wrap("<div class='media-container-wraper'>").parent();
				container.append("<button class='uploader-button button' data-inputfeild='"+ths.attr("name")+"'> upload </button>");
				container.append("<div class='media-item-container' ></div>");

				var viewer = container.find(".media-item-container");
				viewer.html("");
				if ( ths.val() ) {
					var valueFormate = ths.attr("data-valueformate");
					switch( valueFormate ) {
	                	
	                	case "id" : 
	                		$.ajax({
	                			url : "/wp-json/cx_rest_mediauploader/v1/get?ids=" + ths.val(),
	                		}).done(function($res) {
	                			var set = [];
	                			$.each($res, function(k,v) {
	                				set.push({url : v.url, id : v.ID});
	                			});
	                			render.append_thumbs(set  , viewer );
	                		});
	                	break;
	                	case "url" : 
	                		var set = [];
                			$.each(  ths.val().split(",") , function(k,v) {
                				set.push({url : v, id : 0});
                			});
                			render.append_thumbs(set  , viewer );
	                	break;
	                	default : 
	                		var $set = JSON.parse(ths.val());
							render.append_thumbs($set  , viewer );
	                	break;

	                 

	                } 
					
				}

				ths.css("display","none");
				
				container.on("click","button.uploader-button",function(e) {
					
					e.preventDefault();

					var actualInputName = $(this).attr("data-inputfeild");
					var actualInput = $("[name='" + actualInputName +"']");

					var multiple = false;
					
					if ( actualInput.attr("data-multiple") ) {
						multiple = true;
					}
					
					var image = wp.media({ 
		                title: 'Upload Image',
		                multiple: multiple
		            })
		            .open()
		            .on('select', function(e){
		                // This will return the selected image from the Media Uploader, the result is an object
		                var length = image.state().get('selection').length;
		                var models = image.state().get('selection').models;
		                var $_val = [];

		                var viewer = actualInput.parent().find(".media-item-container");
		                viewer.html("");
		                for(var iii = 0; iii < length; iii++) {
		                	
				            var item_url = models[iii].changed.url;
				            var item_title = models[iii].changed.title;

				            var id = models[iii].attributes.id;
				            $_val.push( {url : item_url, id : id}  );

				            $type = item_url.split(".")
				            $type = $type[$type.length - 1];

				            $type = $type.toLowerCase();

				            render.append_thumb(viewer, $type , id ,item_url , item_title ) 
				           
				            
				        }
		                // We convert uploaded_image to a JSON object to make accessing it easier
		                // Output to the console uploaded_image
		               
		               	var valueFormate = actualInput.attr("data-valueFormate");
		               	console.log(valueFormate)
		                var item_url_str = "";
		                switch( valueFormate ) {
		                	case "id" : 
		                		$.each($_val, function(k,v) {
		                			item_url_str += (v.id + ",");
		                		})
		                		item_url_str = item_url_str.substr(0, item_url_str.length - 1);
		                	break;
		                	case "url" : 
		                		$.each($_val, function(k,v) {
		                			item_url_str += (v.url + ",");
		                		})
		                		item_url_str = item_url_str.substr(0, item_url_str.length - 1);
		                	break;
		                	default : 
		                		item_url_str = JSON.stringify( $_val );
		                	break;

		                } 
		                actualInput.val(item_url_str).trigger("change");
		              

		            });
				})
				
			})
		}
	});


	
	$(document).ready(function(){

		
		$("input.wp-media-input").initlize_wp_media_input();

		$(".json-to-table").each(function(k,v){

            $(v).css("display","none");
            var value = $(v).val();
            value = (!value.length ) ? "[]" : value;
            value = JSON.parse(value);

            var p = $(v).parent()
            p.append('<div class="json-table-container"><table><tbody></tbody></table></div>');
            
            function add_trs( $tbody, data){
            	console.log(data);
            	$.each(data, function(kk,vv) {
            	 	if ( typeof vv != "undefined" ) {
            	 		
            	 		if ( ( Array.isArray(vv) && vv.length  )  || typeof vv == "object") {
            	 			$tbody.append(
			                    '<tr><td><span>'+kk+'</span></td><td><table><tbody></tbody></table></td></tr>'
			                );
			                $inner_tbody = $tbody.find("tr").last().find("td table tbody");
			                add_trs($inner_tbody , vv);
            	 		} else {
            	 			$tbody.append(
			                    '<tr><td><span>'+kk+'</span></td><td><span>'+vv+'</span></td></tr>'
			                )
            	 		}
            	 		

            	 	}
	                
	            })
            }
            var tbody = p.find(".json-table-container table tbody")
            add_trs(tbody , value);
            
            
        })
		
        

	})

})(jQuery)