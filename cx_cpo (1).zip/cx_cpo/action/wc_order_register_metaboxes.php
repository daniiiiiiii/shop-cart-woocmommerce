<?php 

namespace cx_cpo\action;

include_once(realpath(__DIR__ . "/base/cx_base_action.php") ); 

if ( !class_exists("\\cx_cpo\\action\\wc_order_register_metaboxes")) {

	class wc_order_register_metaboxes extends \cx_cpo\cx_base_action {

		protected $hook = "admin_init";

		public function run() {


			global $post;



			add_meta_box( 
				'cx-cpo-order-options' ,
		        "Custom order options",
		        [$this,'order_metabox'],
		        "shop_order", 
		        'normal', 'high'
		    );	
		
			
		}
		public function order_metabox($p,$args) {
			
			$order = new \WC_Order( $p->ID );
			$items = $order->get_items();
			foreach ( $items as $item_id =>  $item ) { 

				if ( !isset($item['cx_cpo_options']) ) continue;
					$data = $item['cx_cpo_options'];
					$item_title = $item['name'];

					\cx_cpo_item_price_info($item_title, $data );
			}
		}
	}
}

