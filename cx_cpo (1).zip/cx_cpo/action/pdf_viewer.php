<?php 

namespace cx_cpo\action;

include_once(realpath(__DIR__ . "/base/cx_base_action.php") ); 

if ( !class_exists("\\cx_cpo\\action\\pdf_viewer")) {

	class pdf_viewer extends \cx_cpo\cx_base_action {

		protected $hook = "wp";

		public function run() {

			


			if ( !is_admin() && is_singular("cx_certificate")) {
				
				global $post;
				$pid = $post->ID;

				$attr = \cx_cpo\posttype\certificate::get_attributes_value($pid);
				
				include_once($this->get_plugin_path()  . "/lib/vendor/autoload.php");

				$user_id = get_current_user_id();
				$loged_user = get_user_by('id',$user_id);

				$html = '';

				$attributes = json_decode($attr['attributes'],1);

				foreach ($attributes as $a) {

					$a = array_map("base64_decode", $a);


					$type = $a['type'];
					$val = '';
					$left = $a['left'];
					$top = $a['top'];
					$pram = $a['pram'];
					$styles = $a['styles'];

					switch($type) {
						case  "current_date" : 
							
							$formate = $a['pram'];
							$formate = (!( $formate && strlen($formate)) ) ? "Y-m-d" : $formate;
							$val = date($formate);	

						break;
						case  "current_year" : 
							$val = date("Y");	
						break;
						case  "user_full_name" : 
							if ( $loged_user ) {
								$val = $loged_user->first_name . " " . $loged_user->last_name;  ;		
							}
							
						break;
						case  "user_first_name" : 
							if ( $loged_user ) {
								$val = $loged_user->first_name ;		
							}
						break;
						case  "user_registered" : 
							if ( $loged_user ) {
								$val = $loged_user->user_registered ;		
							}
						break;
						case  "user_id" : 
							if ( $loged_user ) {
								$val = $loged_user->ID ;		
							}
						break;
						case  "user_email" : 
							if ( $loged_user ) {
								$val = $loged_user->user_email ;		
							}
						break;
						case  "user_login" : 
							if ( $loged_user ) {
								$val = $loged_user->user_login ;		
							}
						break;
						case  "site_name" : 
							$val = get_bloginfo('name'); ;
						break;
						case  "site_url" : 
							$val = get_bloginfo('site_url'); ;
						break;
						case  "admin_email" : 
							$val = get_bloginfo('admin_email'); ;
						break;
						case  "_plain_text" : 
							$val = $pram ;
						break;
						
						case  "_user" : 
							$val = $loged_user->$pram;
						break;
						case  "_user_meta" : 
							$val = get_user_meta( $user_id, $pram, 1 );;
						break;
					} 
					$html .= '<div 
						style="'.$styles.';position:absolute;left:'.$left.'%;top:'.$top.'%;" 
						class="dynamic-attr attr-'.$type.' " >'.$val.'</div>'	;				
				}

				

				$dompdf = new \Dompdf\Dompdf();

				$dompdf->setPaper($attr['page_size'], $attr['page_orientation']);
				$dompdf->set_option('dpi' , $attr['page_dpi']);
                $dompdf->loadHtml($html, 'UTF-8');

				

				$dompdf->render();

				$dompdf->stream();

				die();

			}
			

		}
	}
}

