<?php 

namespace cx_cpo\action;

include_once(realpath(__DIR__ . "/base/cx_base_action.php") ); 

if ( !class_exists("\\cx_cpo\\action\\checkout_page_show_dynamic_products_info")) {

	class checkout_page_show_dynamic_products_info extends \cx_cpo\cx_base_action {

		protected $hook = "woocommerce_after_order_notes";

		public function run() {
			
			global $woocommerce, $wp_session;
        	$items = $woocommerce->cart->get_cart();

			?><div class="checkout-custom-item-info-container"><?php 

				foreach($items as $item_id => $item ) {

					if ( !isset($item['cx_cpo_options']) ) continue;
					$data = $item['cx_cpo_options'];
					$item_title = $item['data']->get_name();

					\cx_cpo_item_price_info($item_title, $data );

					
					

				}	

			?></div><?php 
			
		}
	}
}

