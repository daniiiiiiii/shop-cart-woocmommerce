<?php 

namespace cx_cpo\action;

include_once(realpath(__DIR__ . "/base/cx_base_action.php") ); 

if ( !class_exists("\\cx_cpo\\action\\rest_api_data_setup")) {

	class rest_api_data_setup extends \cx_cpo\cx_base_action {

		protected $hook = "init";
		
		public function run() {

			$_SESSION['current_user_id'] = get_current_user_id();
		}
	}
}

