<?php 

namespace cx_cpo\action;

include_once(realpath(__DIR__ . "/base/cx_base_action.php") ); 

if ( !class_exists("\\cx_cpo\\action\\product_redirect")) {

	class product_redirect extends \cx_cpo\cx_base_action {

		protected $hook = "template_redirect";

		public function run() {

			if ( \is_product() ) {
				global $post; 
				$pages = $this->plugin_option(['general','page']);

				if ($post->ID == $pages['order_product'] ) {
					wp_safe_redirect(
						get_permalink($pages['order_page'])
					);	
				}
			}
		}
	}
}

