<?php 

namespace cx_cpo\action;

include_once(realpath(__DIR__ . "/base/cx_base_action.php") ); 

if ( !class_exists("\\cx_cpo\\action\\add_cart_item_meta_to_order_item_meta")) {

	class add_cart_item_meta_to_order_item_meta extends \cx_cpo\cx_base_action {

		protected $hook = "woocommerce_add_order_item_meta";

		protected $accepted_args = 2;

		public function run($item_id, $item_data) {

			global $woocommerce,$wpdb;
			if ( isset($item_data['cx_dconveyor_options']) ) {

				$meta = $item_data['cx_dconveyor_options'];
				wc_add_order_item_meta($item_id,'cx_dconveyor_options',$meta);	
			}
			
		}
	}
}

