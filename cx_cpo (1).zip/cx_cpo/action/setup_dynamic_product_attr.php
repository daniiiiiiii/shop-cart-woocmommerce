<?php 

namespace cx_cpo\action;

include_once(realpath(__DIR__ . "/base/cx_base_action.php") ); 

if ( !class_exists("\\cx_cpo\\action\\setup_dynamic_product_attr")) {

	class setup_dynamic_product_attr extends \cx_cpo\cx_base_action {

		protected $hook = "woocommerce_before_calculate_totals";

		public function run($cart_object) {



			$cart_items = $cart_object->cart_contents;
			if ( ! empty( $cart_items ) ) {

	    		$product_id = $this->plugin_option(['general','page','order_product']);
	    		
			    foreach ( $cart_items as $key => $pro ) {

			    	
			    	$p_id = $pro['data']->get_id();
			    	

			    	if ( $product_id == $p_id && isset($pro['cx_cpo_options']) ) {

			    		$opts = $pro['cx_cpo_options'];
			    		$price_info =  \cx_cpo_calculate_item_price_info( $opts['size'] , $opts['mixture']);

			    		
			    		$title = get_post_field( 'post_title', $opts['size'] );

			    		$pro['data']->set_name($pro['data']->get_name() . " - Size " . $title );
			    		$pro['data']->set_price( $price_info['final_price'] );

			    	}
			
		        }
	  		}
		}
	}
}

