<?php 

namespace cx_cpo;

if ( !class_exists("\\cx_cpo\\cx_base_action")) {

	class cx_base_action extends cx_base {

		protected $hook = "";
		protected $priority = 10;
		protected $accepted_args = 1;

		public function __construct() {
			parent::__construct();
		}
		
		public function register() {
			$hooks = $this->hook;
			if ( !is_array($this->hook)) {
				$hooks = [$hooks];
			} 
			foreach ($hooks as $h) {
				add_action( $h ,  [$this,"run"] ,  $this->priority ,  $this->accepted_args );
			}
			
		}
		
	}
}