<?php 

namespace cx_cpo\action;

include_once(realpath(__DIR__ . "/base/cx_base_action.php") ); 

if ( !class_exists("\\cx_cpo\\action\\order_email_template_data")) {

	class order_email_template_data extends \cx_cpo\cx_base_action {

		protected $hook = "woocommerce_email_order_meta";

		protected $accepted_args = 4;

		public function run($order, $sent_to_admin, $plain_text, $email) {

			?><table cellspacing="0" cellpadding="6" border="1" style="color:#636363;border:1px solid #e5e5e5;vertical-align:middle;width:100%;font-family:'Helvetica Neue',Helvetica,Roboto,Arial,sans-serif"><?php 

				$items = $order->get_items();

				foreach ( $items as $item ) { 
					
					
					if ( !isset($item['cx_cpo_options']) ) continue;
					$data = $item['cx_cpo_options'];
					$item_title = $item['name'];

					?><tr>
						<td><?php 

							\cx_cpo_item_price_info($item_title, $data );

						?></td>

					</tr><?php 
				}

			?></table><?php 
		}
	}
}

