<?php 

namespace cx_cpo\action;

include_once(realpath(__DIR__ . "/base/cx_base_action.php") ); 

if ( !class_exists("\\cx_cpo\\action\\post_handler")) {

	class post_handler extends \cx_cpo\cx_base_action {

		protected $hook = "wp_loaded";

		public function run() {
		
			if ( count($_POST) ){

	            $from_handles = $this->get_posthandels();
	            
	            
	            foreach ($from_handles as $handle_key => $handlers_list) {

	                if ( isset($_POST[$handle_key])) {

	                    $post_handler_name =$_POST[$handle_key];

	                    foreach ($handlers_list as $handler_name => $handler_options ) {

	                    
	                        if ( $handler_name == $post_handler_name ) {

	                            $path = $handler_options[0];
	                            $class = $handler_options[1];
	                            $func = $handler_options[2];


	                            $class_name = $class;
	                            $exp = explode("::", $class);
	                            if ( count($exp) > 1 ) {
	                                $class_name = $exp[0];
	                            }
	                           

	                            if ( !class_exists( $class_name )) {
	                                include_once($path);
	                            }
	                            
	                            // if class
	                            if (class_exists($class_name)) {

	                                if ( count($exp) > 1) {

	                                    $instance_function = $exp[1];
	                                    $obj = $class_name::{$instance_function}();

	                                } else {
	                                	
	                                    $obj = new $class;
	                                }
	                               
	                                // if object
	                                if ( $obj ) { 
	                                    
	                                    $exp = explode("::", $func);

	                                    if ( count($exp) > 1 ) {
	                                        $static_function = $exp[1];

	                                        // if has function
	                                        if ( method_exists($obj, $static_function) ) $obj::{$static_function}($_POST);

	                                    } else {

	                                        // if has function
	                                        if ( method_exists($obj, $func) ) $obj->{$func}($_POST);
	                                    }
	                                }
	                                
	                                unset($_POST);
	                               	
	                            }

	                        }
                    	}
                      
                	}
            	}
       		} 
		}
	}
}

