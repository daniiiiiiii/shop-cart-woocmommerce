<?php 

namespace cx_cpo\action;

include_once(realpath(__DIR__ . "/base/cx_base_action.php") ); 

if ( !class_exists("\\cx_cpo\\action\\add_js_global_data")) {

	class add_js_global_data extends \cx_cpo\cx_base_action {

		protected $hook = ["admin_head","wp_head"];
		protected $priority = -1000;
		
		public function run() {

			
			$ptv_data_str = "";
			$blog_info_keys = [
				"name","wpurl","url","admin_email","charset","version","html_type","text_direction","language",
				"stylesheet_url","stylesheet_directory","template_url",
				"pingback_url","atom_url","rdf_url","rss_url","rss2_url","comments_atom_url","comments_rss2_url",
				"siteurl","home",
			];
			foreach ($blog_info_keys as $key) { 
				$ptv_data_str .= ('private_data["' . $key . '"] =  "'. get_bloginfo($key) .'";'); 
			} 
			$funs_data = [
				"wc_currency_symbol" => "get_woocommerce_currency_symbol",
				"wc_currency" => "get_woocommerce_currency",
				"wc_currencies" => "get_woocommerce_currencies",
				"wc_cart_url" => "wc_get_cart_url",
				"wc_checkout_url" => "wc_get_checkout_url",
				
			];
			foreach ($funs_data as $key => $value) {
				if ( function_exists($value)) {
					$_v = $value();

					
                    if ( isJson($_v) ) {
                        $ptv_data_str .= ('private_data["'.$key.'"] =  '. $_v .';
                        '); 
                    } else if ( is_array($_v)) {
						$ptv_data_str .= ('private_data["'.$key.'"] =  '. json_encode($_v) .';
						'); 
					} else {
						$ptv_data_str .= ('private_data["'.$key.'"] =  "'. $value().'";
						'); 
					}
					
				}
			}
			global $post;
			$obj = get_queried_object();
			$obj_id = get_queried_object_id();


			if ( $obj ) {
				$ptv_data_str .= 'private_data["queried_object_type"] =  "'. \get_class($obj) . '";';
				$ptv_data_str .= 'private_data["queried_object_id"] =  '. $obj_id . ';';

			}
			
			$list = apply_filters( "cx_base_js_public_data", [] );
			foreach ($list as $key => $value) {
				$ptv_data_str .= 'private_data["'.$key.'"] =  '. json_encode($value) . ';';
			}

			// PWA assets cache list
			$assets = apply_filters( "cx_base_pwa_cache_asset_list", [] );
			$ptv_data_str .= 'private_data["pwa_assets_cache_list"] =  '. json_encode($assets) . ';';

			$assets = apply_filters( "cx_base_pwa_cache_ignore_asset_list", [] );
			$ptv_data_str .= 'private_data["pwa_ignore_assets_cache_list"] =  '. json_encode($assets) . ';';

			// adding users
			foreach(glob( realpath(__DIR__ . "/../models/") . "/*.php") as $file){
				
				require_once $file;
			    $class_name = basename($file,".php");
			 	if ( class_exists($class_name)) {
			 		$obj = new $class_name;

				    if ( method_exists($obj, "get_user_session_data") ) { 

				    	$data = $obj->get_user_session_data();
				    	$id = (isset($data["id"])) ? $data["id"] : 0;
				    	$user_class = $obj->get_user_class();
				    	$ptv_data_str .= ('private_data["cx_'.$user_class.'"] =  "'. $id  .'";'); 
				    }
			 	}
			    
			}

			$site_url = site_url();
			$site_url = explode("?", $site_url)[0];
			
			// rest api
			$api_data = [];
			foreach(glob( realpath(__DIR__ . "/../rest/") . "/*.php") as $file){
				
			    $class_name =  basename($file,".php") ;	
			    $obj = $this->rest($class_name);

			    $list = $obj->get_public_methods();
			    $namespace = $obj->get_api_namespace();
				$version = $obj->get_api_version();

				$urls = [];
				foreach ($list as $key => $value) {
					$url = $value;
					if ( is_array($value)) {
						$url = $url[0];
					}
					$urls[$key] = $site_url . "/wp-json/".$namespace."/v".$version."/".$url ;
				}
			    

			    $api_data[$class_name] = $urls;
			}


			// function will on wp_head
			?><script type="text/javascript" id='cx_base'>
				
				window.hs = ( typeof window.hs == "undefined" ) ? {} : window.hs;	
				window.hs._site = (function(){
					var private_data = {};	
					private_data.base_url =  "<?php echo site_url() ?>";
					private_data.current_user_id =  "<?php echo get_current_user_id() ?>";
					private_data.api = <?= json_encode($api_data) ?>;
					<?php echo $ptv_data_str; ?>

					var methods = {get: function($pram) {return private_data[$pram];}};

					function site() {}
					for (var func in methods) {
						if(!methods.hasOwnProperty(func)) continue;
						site.prototype[func] = methods[func];
					}
					return site;
				})();
				window.hs.site = new window.hs._site();
				
			</script><?php
		
		
		}
		
		
	}
}
