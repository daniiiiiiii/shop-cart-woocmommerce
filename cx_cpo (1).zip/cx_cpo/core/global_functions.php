<?php
 
/* basic function can be used by other plugins */


if ( !function_exists("isJson") ) { 
    function isJson($string) {
        return ((is_string($string) &&
                (is_object(json_decode($string)) ||
                is_array(json_decode($string))))) ? true : false;
    }
}


if ( !function_exists("get_posts_as_options")) {
	function get_posts_as_options( $post_type = "post", $label = "post_title" , $key = "ID", $arg = []) {

		if ( !is_array($arg)) $arg = [];

		$arg["post_type"] = $post_type;
		if ( !isset($arg["numberposts"]) ) $arg["numberposts"] = -1;

		$collection = get_posts($arg);

		$return_data = [];
		foreach ($collection as  $elem) {
			$return_data[ $elem->$key ] = $elem->$label;
		}
		return $return_data;
	}
}


if ( !function_exists("get_users_as_options")) {
	function get_users_as_options( $role = "subscriber", $label = "display_name" , $key = "ID", $arg = []) {

		if ( !is_array($arg)) $arg = [];

		$arg["role"] = $role;

		$collection = get_users($arg);

		$return_data = [];
		foreach ($collection as  $elem) {
			$return_data[ $elem->$key ] = $elem->$label;
		}
		return $return_data;
	}
}

if ( !function_exists("get_pages_as_options")) {
	function get_pages_as_options() {
		return get_posts_as_options("page");
		
	}
}

if ( !function_exists("get_terms_as_options")) {
	function get_terms_as_options($tax) {
		
		$return_arr = [];
		$terms = get_terms([
			"taxonomy"=>$tax,
			"hide_empty"=>false
		]);
		foreach ($terms as $t) {
			$return_arr[$t->term_id] = $t->name;
		}
		return $return_arr;
	}
}
if ( !function_exists("get_menus_as_options")) {
	function get_menus_as_options() {
		
		$return_arr = [];
		$terms = wp_get_nav_menus();
		
		foreach ($terms as $t) {
			$return_arr[$t->term_id] = $t->name;
		}
		return $return_arr;
	}
}


 // global functions goes here
if ( !function_exists("cx_plugin_path") ) {

	function cx_plugin_path($path = "",$namespace) {

		return constant(strtoupper($namespace) . "_PATH") . $path;
	}
}



if ( !function_exists("cx_plugin_uri") ) {

	function cx_plugin_uri($path = "",$namespace) {
		
		return constant(strtoupper($namespace) . "_URI") . $path; 
		
	}
}
// load template with data
if ( !function_exists("cx_load_template") ) {

	function cx_load_template($filename,$require_once= 1,$data = [],$namespace){

		foreach ($data as $key => $value) {
			set_query_var($key,  $value);
		}
		if ( !file_exists($filename)) {

			$file_path =cx_plugin_path("template/".$filename,$namespace);
		
		} else {
			
			$file_path =$filename;

		}
		
	
		if ( file_exists( $file_path  ) ){

			load_template( $file_path ,$require_once );

		}
	}

}

if ( !function_exists("cx_load_template_admin") ) {

	function cx_load_template_admin($filename,$require_once= 1,$data = [],$namespace){

		cx_load_template("admin/" . $filename,$require_once= 1,$data = [],$namespace);

	}

}

if ( !function_exists("cx_load_template_posttype") ) {

	function cx_load_template_posttype($filename,$require_once= 1,$data = [],$namespace){

		cx_load_template("posttype/" . $filename,$require_once= 1,$data = [],$namespace);
		
	}

}

if ( !function_exists("cx_load_template_shortcode") ) {

	function cx_load_template_shortcode($filename,$require_once= 1,$data = [],$namespace){

		cx_load_template("shortcode/" . $filename,$require_once= 1,$data = [],$namespace);
		
	}

}
// get plugin config, setup in config.php
if ( !function_exists("cx_get_config") ) {

	function cx_get_config($name,$namespace) {
		
		global $_cx_config;

		if ( !$_cx_config ) {
			
		}
		if ( isset($_cx_config[$namespace][$name] )  ){
			return $_cx_config[$namespace][$name];
		} else {
			return null;
		}
	}
}



/*
	check if post exist by slug
*/
if ( !function_exists("post_exists_by_slug") ) {

	function post_exists_by_slug( $post_slug , $type) {
		$args_posts = array(
			'post_type'      => $type,
			'post_status'    => 'any',
			'name'           => $post_slug,
			'posts_per_page' => 1,
		);
		$loop_posts = new WP_Query( $args_posts );
		if ( ! $loop_posts->have_posts() ) {
			return false;
		} else {
			$loop_posts->the_post();
			return $loop_posts->post->ID;
		}
	}

}

// /* need refactoring */
// if ( !function_exists("get_plugin_admin_page_url") ) {

// 	function cx_get_plugin_admin_page_url( $page , $namespace) {

// 		return get_admin_url() ."options-general.php?page=". cx_get_config("plugin_admin_page");

// 	}
// }


// private function not intended to be used directly , load class file and return object
if ( !function_exists("cx_inc") ) { 
	function cx_inc($name,$dir,$namespace = null) {

		//base file
		$filename_base = "cx_".$dir."_".$name;
		$filename = $namespace."_".$dir."_".$name;



		if ( file_exists( cx_plugin_path($dir."s/$filename.php",$namespace) ) ) {
			

			if ( !class_exists($filename)) {
				include_once(cx_plugin_path($dir."s/$filename.php",$namespace));
				return $filename;
			} else {
				return $filename;
			}
		}
		if ( file_exists( cx_plugin_path($dir."s/$filename_base.php",$namespace) ) ) {
			if ( !class_exists($filename_base)) {
				include_once(cx_plugin_path($dir."s/$filename_base.php",$namespace));
				return $filename_base;
			} else {
				return $filename_base;
			}
		}

		return null;	
		
	}
}
if ( !function_exists("_cx_get") ) { 
	function _cx_get($name,$dir,$namespace = null) {

		//base file
		$filename_base = "cx_".$dir."_".$name;
		$filename = $namespace."_".$dir."_".$name;

		$folder_prefix = ["s", ""];
		foreach ($folder_prefix as  $prifix) {

			

			if ( file_exists( cx_plugin_path($dir. $prifix ."/$filename.php",$namespace) ) ) {

				if ( !class_exists($filename)) {
					include_once(cx_plugin_path($dir. $prifix ."/$filename.php",$namespace));
				}
				if ( class_exists($filename)) {
					return new $filename ;
				}
			}
			
			

			// if not check if base exist
			if ( file_exists( cx_plugin_path($dir. $prifix ."/$filename_base.php",$namespace) ) ) {
				if ( !class_exists($filename_base)) {
					include_once(cx_plugin_path($dir. $prifix ."/$filename_base.php",$namespace));
				}
				
				if ( class_exists($filename_base)) {
					return new $filename_base ;
				}
			}
		}
		

		return null;
	}
}
// getters, get model

if ( !function_exists("cx_get_rest") ) { 
	function cx_get_rest($name,$namespace) {
		return _cx_get($name,"rest",$namespace);
	}
}



if ( !function_exists("cx_get_controller") ) { 
	function cx_get_controller($name,$namespace) {
		return _cx_get($name,"controller",$namespace);
	}
}


if ( !function_exists("cx_get_helper") ) { 
	function cx_get_helper($name,$namespace) {
		return _cx_get($name,"helper",$namespace);
	}
}

if ( !function_exists("cx_get_table") ) { 
	function cx_get_table($name,$namespace) {
		return _cx_get($name,"table",$namespace);
	}
}


// get plugin option, save in db table wp_options , return json_decode(data) 
if ( !function_exists("cx_get_option") ) { 
	function cx_get_option($key,$name) {
		$opt = get_option($key);
		if ( !$opt ) return null;

		$data = json_decode( $opt , 1 );
		if ( !isset($data[$name] ) ) {
			return null;
		}
		return $data[$name];
		

	}
}
// save option in db table wp_options
if ( !function_exists("cx_set_option") ) { 

	function cx_set_option($key,$name,$val) {
		
		$opt = get_option($key);
		if ( !$opt ) {
			$opt = "[]";
		}

		$data = json_decode( $opt , 1 );

		$data[$name] = $val;

		$data = json_encode( $data );
		update_option($key , $data );		

	}
}
// save data in nested form
if ( !function_exists("cx_set_array_value") ) { 
	function cx_set_array_value($data,$name_list,$val) {
		$temp = &$data;
		foreach ($name_list as $key => $name) {

			if ( count($name_list)-1 == $key ) {
				
				$temp[$name] = $val;

			} else {

				if ( !isset($temp[$name])) {
					$temp[$name] = [];
				}
			}
			$temp = &$temp[$name];

		}
		return $data;
	}
}

if ( !function_exists("cx_set_option_value") ) { 

	function cx_set_option_value($key,$name_list = [],$val) {
		
		$opt = get_option($key);
		if ( !$opt ) {
			$opt = "[]";
		}
		$data = json_decode( $opt , 1 );
		$data = cx_set_array_value($data,$name_list,$val);
		$data = json_encode( $data );

		update_option($key , $data );
	}

}
if ( !function_exists("cx_get_option_value") ) { 
	function cx_get_option_value($key,$namelist = []) {
		$opt = get_option($key);
		
		if ( !$opt ) return null;

		$data = json_decode( $opt , TRUE );
		$returndata=$data;
		foreach ($namelist as  $name) {
			if ( !isset($returndata[$name] ) ) {
				return null;
			} else {
				$returndata = $returndata[$name];
			}
		}
		return $returndata;
		

	}
}

// parse sting and populate data {{key}}
if ( !function_exists("cx_string_parser") ) { 
	function cx_string_parser($str , $data , $pre_reg = '\{\{' , $post_reg = '\}\}'){


		foreach ($data as $key => $value) {
			
			$p_val =  ( is_string($value)) ? $value : json_encode($value);

			$pat = "/" . $pre_reg .$key . $post_reg ."/";
			
			$str = preg_replace($pat, __($p_val,"xwt"), $str);
		}
		return $str;
	}
}

// global post handle setup, save handle in db and on every post request redirect data to the configured class
if ( !function_exists("cx_add_global_posthandels") ) { 

	/*
		$handels = [
			"cx_form_type" =>[
				"cx_add_something" => [ path,class,function ]
			]
		]
	*/
	function cx_add_global_posthandels($handels = null){
		
		if ( !$handels ) return null;

		$opt = get_option("cx_post_handels");
		if ( !$opt ) $opt = "[]";
		
		$opt = json_decode($opt,1);

		foreach ($handels as $form_type_key => $function_list) {

			if ( !isset($opt[$form_type_key]) ) $opt[$form_type_key] = [];

			foreach ($function_list as $function_key => $data) {

				$opt[$form_type_key][$function_key] = $data;

			}

		}
		$opt = json_encode($opt);
		update_option("cx_post_handels",$opt);
		

	}
}

// set global session msg
if ( !function_exists("cx_set_session_msg") ) { 
	function cx_set_session_msg($class ="log",$msg) {
		$key = "cx_session_msg";

		if ( !isset($_SESSION[$key])) {
			$_SESSION[$key] = [];
		}
		$_SESSION[$key][] = [
			"class"=>$class,
			"msg"=>$msg,

		];
	}
}

// set global session msg html
if ( !function_exists("cx_get_session_msg_html") ) { 
	function cx_get_session_msg_html($delete_msg_from_session= 1){
		$key = "cx_session_msg";
		$html = "";
		if ( isset($_SESSION[$key])) {
			$data = $_SESSION[$key];
			foreach ($data as $k => $msg) {
				$html .= "<div class='msg-box msg-session ".$msg["class"]." '><p>". __($msg["msg"],"xwt")."</p></div>";
			}
		}
		if ( $delete_msg_from_session) {
			$_SESSION[$key] = [];
			
		}
		return $html;
	}
}
// check if cateogry exist by meta
if ( !function_exists("cx_check_categroy_exist_by_meta")) {

	function cx_check_categroy_exist_by_meta($meta_name,$meta_value,$first_id_only = 1,$cat_type = 'product_cat'){

		$args = array(
		    'taxonomy'   => $cat_type,
		    'hide_empty' => false,
		    'meta_query' => array(
		         array(
		            'key'       => $meta_name,
		            'value'     => $meta_value,
		            'compare'   => "="
		         )
		    )
		);
		$terms = get_terms( $args );
		//wp_reset_query();

		if ( !count($terms)) return 0;

		if ( $first_id_only ) {
			return $terms[0]->term_id;
		} else {
			return $terms;
		}
		

	}
}


// check if data array has all the reuqird attribute, return status + missing
if ( !function_exists("cx_array_check_req") ) { 

	function cx_array_check_req($data , $required_list) {
		$return_statue = 1;
		$missing = [];
		foreach ($required_list as $key => $value) {
			if ( is_array($value) ) {
				if ( isset($data[$key] ) ) {
					$res = cx_array_check_req($data[$key] , $value);
					if ( $res["status"] == 0 ) {
						$return_statue = 0;
						$missing[$key] = [];
						foreach ($res["missing"] as $_key => $_value) {
							$missing[$key][$_key] = $_value;
						}
					}
				} else {
					$missing[$key] = $value;
				}
				
			} else  {
				if ( !isset($data[$value] ) ) {
					$return_statue = 0;
					$missing[] = $value;
				}
			}
		}
		return [
			"missing" => $missing,
			"status" => $return_statue,

		];

	}
}




// insert product cateogry
if ( !function_exists("cx_insert_category")) {

	function cx_insert_product_category($attr){

		$id = wp_insert_term( $attr["name"], 'product_cat', [
		    'description'=> isset($attr["description"]) ? $attr["description"] : "",
		    'slug' => isset($attr["slug"]) ? $attr["slug"] : sanitize_title_with_dashes($attr["name"]),
		    'parent' => isset($attr["parent"]) ? $attr["parent"] : 0,
		  ]
		);

		if ( isset($attr["term_meta"])) {
			foreach ($attr["term_meta"] as $key => $value) {
				$meta_id= add_term_meta( $id["term_id"], $key, $value );
			}
		}
		return $id["term_id"];

	}
}

// dwonload images from other server and add in product
if ( !function_exists("cx_dwonload_insert_product_images") ) { 
	function cx_dwonload_insert_product_images($images,$post_id,$attr){
		$wp_upload_dir = wp_upload_dir();
		
		// images import dir
		$_ext_path = explode("/", $wp_upload_dir['path']);
		array_splice($_ext_path,-2);
		
		$_ext_url = explode("/", $wp_upload_dir['url']);
		array_splice($_ext_url,-2);

		$import_dir = implode("/",  $_ext_path);
		$import_dir_url = implode("/",  $_ext_url);

		
		$image_id_list = [];
		// inserting images
		foreach($images as $k => $download_url) {
		    //if (!file_exists($download_url)) continue;
		    // copy the img
			$upload_dir = $import_dir . "/" ;
			$upload_url = $import_dir_url . "/";

			/*
			$upload_dir = $import_dir . $attr["sku"] . "/";
			$upload_url = $import_dir_url . $attr["sku"] . "/";
			*/


			if ( !file_exists($upload_dir) ) mkdir($upload_dir);

		    $name 	=  	basename( $download_url );

		    $upload_dir .= $attr["sku"]."-".$name;
			$upload_url .= $attr["sku"]."-".$name;

		    copy($download_url, $upload_dir);


		    $attachment = array(

		        'guid'=> $upload_url, 
		        'post_mime_type' => 'image/jpg',
		        'post_title'=>$name ,
		        'post_parent' => $post_id,
		        'post_author'    => 1,
		    );

		    

		    // Make sure that this file is included, as wp_generate_attachment_metadata() depends on it.
		    require_once( ABSPATH . 'wp-admin/includes/image.php' );
		 	
		 	$image_id = wp_insert_attachment($attachment, $upload_dir, $post_id); 	
		    // Generate the metadata for the attachment, and update the database record.
		    $attach_data = wp_generate_attachment_metadata( $image_id, $upload_dir );
		    
		    wp_update_attachment_metadata( $image_id, $attach_data );
		    
		    add_post_meta($image_id, '_wp_attachment_image_alt', $post_id);
		    
		    
		    array_push($image_id_list, $image_id);
		    // setting up fetured images
		    if ( !$k ) {
		    	set_post_thumbnail( $post_id, $image_id );
		    }
		    
		}
		update_post_meta($post_id, '_product_image_gallery',implode(",", $image_id_list) );
	}
}


if ( !function_exists("cx_update_product_meta") ) { 
	function cx_update_product_meta($post_id,$attr){ 

		// deleting things from terms
		global $wpdb;
		$wpdb->delete(  $wpdb->prefix . 'term_relationships' , [
			"object_id" => $post_id,
		]);

		// keys with defualts
		$meta_keys = [

			"price"			=>"",
			"regular_price"	=>"",
			"sku"			=>$post_id,
			"weight"		=>"1",
			"length"		=>"1",
			"width"			=>"1",
			"height"		=>"1",

			"visibility" 		=> "visible",
			"stock_status"		=> "instock",
			"downloadable"		=> "no",
			"virtual"			=> "no",
			"featured"			=> "no",
			"manage_stock"		=> "yes",
			"backorders"		=> "no",
			"stock"				=> "0",
			"sale_price"		=> "",
			"purchase_note"		=> "",
			"sold_individually"		=> "",
			"sale_price_dates_from"	=> "",
			"sale_price_dates_to"	=> "",

		];
		foreach ($meta_keys as $meta_key => $default_value) {
			$value = $attr[$meta_key];
			$value = ($value) ? $value : $default_value;
			update_post_meta( $post_id,  "_". $meta_key , $value );
		}
		// regular price 
		update_post_meta( $post_id,  "_regular_price" ,$attr["price"] );


		// if ( isset($attr["product_cat"]) ) {
		// 	wp_set_object_terms($post_id, $attr["product_cat"],'product_cat', TRUE);
		// }
		if ( is_array($attr["product_cat"])) {

			$attr["product_cat"] = array_map("intval", $attr["product_cat"]);
			$attr["product_cat"] = array_unique( $attr["product_cat"]);
			wp_set_object_terms( $post_id, $attr["product_cat"], 'product_cat' , 0);

		} else {

			$attr["product_cat"] =  intval($attr["product_cat"]) ;
			wp_set_object_terms( $post_id, $attr["product_cat"], 'product_cat' , 0);

		}
		



		


		if ( isset($attr["meta_input"])) {
			foreach ($attr["meta_input"] as $key => $value) {
				update_post_meta( $post_id, $key, $value );
			}
		}
		
		
		if ( isset($attr["download_images"])) {
			cx_dwonload_insert_product_images($attr["download_images"],$post_id,$attr);
		}
		
		if ( isset($attr["images"])) {
			$imgs = json_decode( stripcslashes( $attr["images"] ) ,1);
			
			$image_id_list = [];
			if ( isset($imgs) && count($imgs) ) {

				foreach ($imgs as $key => $img) {
					$image_id_list[] = $img["id"];
					if ( !$key ) {
						set_post_thumbnail( $post_id, $img["id"] );
					}
				}
				update_post_meta($post_id, '_product_image_gallery', implode(",", $image_id_list) );
			}
			
		}
		

		$p_attrs = $attr["product_attributes"];
		

		if ( isset($p_attrs)  && count($p_attrs)) {
			$product = wc_get_product( intval($post_id) );

		
			$meta_opt = [];

			foreach ($p_attrs as $aid => $val_id) {
				
				$data = array(
				    'object_id' => $post_id,
				    'term_taxonomy_id' => $val_id,
				    'term_order' => '0',
				);
				$attribute = wc_get_attribute($aid);

				$wpdb->insert(    $wpdb->prefix . 'term_relationships', $data );
				$meta_opt[] = [
					"name"=>  $attribute->slug ,
					"value"=> "",
					"position"=> "1",
					"is_visible"=> "1",
					"is_variation"=> "0",
					"is_taxonomy"=> "1",
				];

			}
			update_post_meta( $post_id, "_product_attributes", $meta_opt );
			
			$product->save();
		}
		

		

	}
}
if ( !function_exists("cx_update_product") ) { 

	function cx_update_product($attr){ 

		wp_update_post( array(
			"ID"=> $attr["ID"],
			'post_title' => $attr["post_title"],
			'post_content' => $attr["post_content"],
		));
		cx_update_product_meta($attr["ID"],$attr);
	}

}
if ( !function_exists("cx_insert_product") ) { 

	function cx_insert_product($attr){

		$post_id = wp_insert_post( array(
			'post_title' => $attr["post_title"],
			'post_content' => $attr["post_content"],
			'post_status' => ( isset($attr["status"]) ) ? $attr["status"] : 'publish',
			'post_type' => "product",
		) );

		// defaults
		wp_set_object_terms( $post_id, 'simple', 'product_type' );
		update_post_meta( $post_id, 'total_sales', '0' );

		cx_update_product_meta($post_id,$attr);
		
		return $post_id;
	}
}


/*

	cx_create_product_variation
	// The variation data
	$variation_data =  array(
	    'attributes' => array(
	        'size'  => 'M',
	        'color' => 'Green',
	    ),
	    'sku'           => '',
	    'regular_price' => '22.00',
	    'sale_price'    => '',
	    'stock_qty'     => 10,
	);

	// The function to be run
	create_product_variation( $parent_id, $variation_data );
*/
if ( !function_exists("cx_create_product_variation") ) { 

	/**
	 * Create a product variation for a defined variable product ID.
	 *
	 * @since 3.0.0
	 * @param int   $product_id | Post ID of the product parent variable product.
	 * @param array $variation_data | The data to insert in the product.
	 */
	function cx_create_product_variation( $product_id, $variation_data,$attributes =[] ){
	    // Get the Variable product object (parent)
	    $product = wc_get_product($product_id);
	    wp_set_object_terms ($product_id, 'variable', 'product_type');

	    // addind attributes
	    if($attributes){
			$productAttributes=array();
			foreach($attributes as $attribute){
				$attr = wc_sanitize_taxonomy_name(stripslashes($attribute["name"])); // remove any unwanted chars and return the valid string for taxonomy name
				$attr = 'pa_'.$attr; // woocommerce prepend pa_ to each attribute name
				if($attribute["options"]){
					foreach($attribute["options"] as $option){
						wp_set_object_terms($product_id,$option,$attr,TRUE); // save the possible option value for the attribute which will be used for variation later
					}
				}
				$productAttributes[sanitize_title($attr)] = array(
					'name' => sanitize_title($attr),
					'value' => $attribute["options"],
					'position' => $attribute["position"],
					'is_visible' => $attribute["visible"],
					'is_variation' => $attribute["variation"],
					'is_taxonomy' => '1'
				);
			}
			update_post_meta($product_id,'_product_attributes',$productAttributes); // save the meta entry for product attributes
		}
	    $variation_post = array(
	        'post_title'  => $product->get_title(),
	        'post_name'   => 'product-'.$product_id.'-variation',
	        'post_status' => 'publish',
	        'post_parent' => $product_id,
	        'post_type'   => 'product_variation',
	        'guid'        => $product->get_permalink()
	    );

	    // Creating the product variation
	    $variation_id = wp_insert_post( $variation_post );

	    // Get an instance of the WC_Product_Variation object
	    $variation = new WC_Product_Variation( $variation_id );
	    
	    $variation->set_parent_id($product_id);

	    // Iterating through the variations attributes
	    foreach ($attributes as $kk => $attribute ) {
	        $taxonomy = 'pa_'.$attribute["name"]; // The attribute taxonomy

	        // If taxonomy doesn't exists we create it (Thanks to Carl F. Corneil)
	        if( ! taxonomy_exists( $taxonomy ) ){
	            register_taxonomy(
	                $taxonomy,
	               'product_variation',
	                array(
	                    'hierarchical' => FALSE,
	                    'label' => ucfirst( $taxonomy ),
	                    'query_var' => TRUE,
	                    'rewrite' => array( 'slug' => '$taxonomy'), // The base slug
	                )
	            );
	        }

	        // Check if the Term name exist and if not we create it.
	        foreach ($attribute["options"] as $key => $term_name) {
	        	if( ! term_exists( $term_name, $taxonomy ) )
	            	wp_insert_term( $term_name, $taxonomy ); // Create the term

	             	$term_slug = get_term_by('name', $term_name, $taxonomy )->slug; // Get the term slug

			        // Get the post Terms names from the parent variable product.
			        $post_term_names =  wp_get_post_terms( $product_id, $taxonomy, array('fields' => 'names') );

			        // Check if the post term exist and if not we set it in the parent variable product.
			        if( ! in_array( $term_name, $post_term_names ) )
			            wp_set_post_terms( $product_id, $term_name, $taxonomy, TRUE );

			        // Set/save the attribute data in the product variation
			        update_post_meta( $variation_id, 'attribute_'.$taxonomy, $term_slug );
	        }
	        

	       
	    }

	    ## Set/save all other data

	    // SKU
	    if( ! empty( $variation_data['sku'] ) )
	        $variation->set_sku( $variation_data['sku'] );

	    // Prices
	    if( empty( $variation_data['sale_price'] ) ){
	        $variation->set_price( $variation_data['regular_price'] );
	    } else {
	        $variation->set_price( $variation_data['sale_price'] );
	        $variation->set_sale_price( $variation_data['sale_price'] );
	    }
	    $variation->set_regular_price( $variation_data['regular_price'] );

	    // Stock
	    if( !empty($variation_data['stock_qty']) && $variation_data['stock_qty'] ){
	        $variation->set_stock_quantity( $variation_data['stock_qty'] );
	        $variation->set_manage_stock(TRUE);
	        $variation->set_stock_status('');
	    } else {
	        $variation->set_manage_stock(TRUE);
	        $variation->set_stock_quantity( 0 );
	    }

	    $var_attributes = array();
		foreach($variation_data['attributes'] as $vattribute => $attr_val ){
			$taxonomy = "pa_".wc_sanitize_taxonomy_name(stripslashes($vattribute)); // name of variant attribute should be same as the name used for creating product attributes
			$attr_val_slug =  wc_sanitize_taxonomy_name(stripslashes($attr_val));
			$var_attributes[$taxonomy]=$attr_val_slug;
		}
		$variation->set_attributes($var_attributes);

	    $variation->set_weight(''); // weight (reseting)

	    $variation->save(); // Save the data
	    return $variation_id;

	}
}

function wc_get_product_id_by_variation_sku($sku) {
    $args = array(
        'post_type'  => 'product_variation',
        'meta_query' => array(
            [
                'key'   => '_sku',
                'value' => $sku,
                'compare'   => "="
            ]
        )
    );
    // Get the posts for the sku
    $posts = get_posts( $args);
    if ($posts) {
        return $posts[0]->post_parent;
    } else {
        return false;
    }
}


