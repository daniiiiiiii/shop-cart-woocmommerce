<?php  

// popular third part


$include_lib = [

    //"cropper",
    "select2",
    //"phone-country-code-flag"
    //"owl-carousel"
    //"angular"
    //"jquery-ui"
    "daterange-picker"
    

];






if ( in_array("select2", $include_lib) ) {
    wp_enqueue_style( "select2",  "https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/css/select2.min.css");
    wp_enqueue_script( "select2",  "https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/js/select2.min.js", ["jquery"]);
}
        
// adding croper js for media 
if ( in_array("cropper", $include_lib) ) {

    wp_enqueue_style( 
        "cropperjs", 
        $_plugin_uri . '/asset/third-party/cropper.js/cropper.min.css'
    ); 
    wp_enqueue_script( 
        "cropperjs", 
        $_plugin_uri . '/asset/third-party/cropper.js/cropper.min.js'
    );  
}

if ( in_array("phone-country-code-flag", $include_lib) ) {

    wp_enqueue_style( 
        "jQuery-phone-country-code-flag", 
        "https://www.jqueryscript.net/demo/jQuery-International-Telephone-Input-With-Flags-Dial-Codes/build/css/intlTelInput.css"
    ); 
    wp_enqueue_script( 
        "jQuery-phone-country-code-flag", 
        "https://www.jqueryscript.net/demo/jQuery-International-Telephone-Input-With-Flags-Dial-Codes/build/js/intlTelInput.min.js"
    );  

}


