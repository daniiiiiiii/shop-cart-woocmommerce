<?php 

namespace cx_cpo;

if ( !class_exists("cx_base_plugin") ) {

	class cx_base_plugin {

		protected $_plugin_file;
	    protected $_plugin_path;
	    protected $_plugin_namespace;
	    protected $_plugin_data;
	    protected $_plugin_uri;
	    protected $_plugin_post_handels;

	    // lagecy
	    protected $_plugin_options;
	    protected $_plugin_dir;


	    protected $_plugin_user_roles = [];

	    protected $_plugin_register_styles_and_script = [];
	    protected $_plugin_enqueue_styles_and_script = [];




	    protected static $plugin_initilized = 0;

	    protected $wpdb;
	    protected $db_prefix;
	    protected $table_prefix;


	    protected $supported_styles = ["css","scss"];
	    protected $supported_scripts = ["js"];

	    protected static $instances = [];
	    protected static $instance = null;
	    public static function get_instance() {
	        return static::$instance;
	    }

	    static $static__plugin_file 		= null;
		static $static__plugin_path 		= null;
		static $static__plugin_namespace 	= null;
		static $static__plugin_user_roles 	= null;

		static $static_initilized_dirs = [];

		// private $_DIR_ASSETS 		= 'assets';
		// private $_DIR_ACTION 		= 'action';
		// private $_DIR_CONTROLLER 	= 'controller';
		// private $_DIR_ASSETS		= 'assets';
		// private $_DIR_ASSETS 		= 'assets';
		// private $_DIR_ASSETS 		= 'assets';
		// get plugin asset url
		// get plguin asset path
	    public function __construct() {
        	
        	$save_to_statics_as_well = [
        		'_plugin_file',
				'_plugin_path',
				'_plugin_namespace',
				'_plugin_user_roles',
        	];
        	
        	foreach ($save_to_statics_as_well as $k ) {
        		
        		$static_var = 'static_' . $k;

        		if ( $this->$k ) {

        			self::${$static_var} = $this->$k;	

        		} else {

        			if ( isset(self::$static_var) ) {

        				$this->$k = self::${$static_var};

        			}
        			
        		}
        	}
        	
        	


	        global $wpdb;
	        $this->wpdb = $wpdb;
	        $this->db_prefix = $wpdb->prefix;
	        $this->table_prefix = $this->db_prefix . $this->_plugin_namespace . "_";

	        

	        $this->_plugin_data         	= $this->_plugin_namespace . "_data";
	        $this->_plugin_post_handels     = $this->_plugin_namespace . "_post_handels";
	        $this->_plugin_path          	= plugin_dir_path( $this->_plugin_file );
	        $this->_plugin_uri          	= plugins_url("",$this->_plugin_file);

	        // lagecy
	        $this->_plugin_options         	= $this->_plugin_data ;
	        $this->_plugin_dir         		= $this->_plugin_path;
	       
	        static::$instance = $this;

	        include_once( $this->_plugin_path . "core/global_functions.php");
			include_once( $this->_plugin_path . "functions.php");


	    }
	    public function get_plugin_namespace() {return $this->_plugin_namespace;}
	    public function get_plugin_data_key() {return $this->_plugin_data;}
	    public function get_plugin_post_handels_key() {return $this->_plugin_post_handels;}
	    public function get_plugin_options_key() {return $this->_plugin_options;}
	    public function get_plugin_path() {return $this->_plugin_path;}
	    public function get_plugin_uri() {return $this->_plugin_uri;}
	    
	    public function get_plugin_table_prefix() { return $this->table_prefix; }

	    public function get_plugin_dir() {return $this->_plugin_dir;}



	    public function set_session_msg($class ="log",$msg, $msgkey = null) {
			$key = "cx_session_msg";
			if ( !isset($_SESSION[$key])) $_SESSION[$key] = [];
			$msgkey = (is_null($msgkey)) ? wp_generate_password(12,0,0) : $msgkey;
			$_SESSION[$key][$msgkey] = [
				"class"=>$class,
				"msg"=>$msg,

			];
		}

    	public function init_plugin() {

	        if ( self::$plugin_initilized == 1 ) return 0;
	        
	        
	        $caps_plugin_namespace = strtoupper($this->_plugin_namespace);

	        

	        define( $caps_plugin_namespace  .'_FILE',  $this->_plugin_file );
	        define( $caps_plugin_namespace  .'_PATH',  $this->_plugin_path );
	        define( $caps_plugin_namespace  .'_URI',   $this->_plugin_uri );
	        define( $caps_plugin_namespace  .'_DATA',  $this->_plugin_data );
	        define( $caps_plugin_namespace  .'_ROLES', $this->_plugin_user_roles );
	        define( $caps_plugin_namespace  .'_POST_HANDELS', $this->_plugin_post_handels );


	        define( $caps_plugin_namespace          ,  $this->_plugin_namespace );


	        include_once( $this->_plugin_path . "configs.php");
			
			include_once( $this->_plugin_path . "core/global_css_js.php");

			



	        // setting up consts and vars 
	        register_activation_hook( $this->_plugin_file, [ $this , "plugin_intall" ]);
	        register_uninstall_hook( $this->_plugin_file , [ $this , "plugin_unintall" ]);


	        
			
			$this->_plugin_register_styles_and_script = $this->register_styles_and_script(
				$this->register_base_styles_and_script()
			);
			$this->_plugin_enqueue_styles_and_script = $this->enqueue_styles_and_script(
				$this->enqueue_base_styles_and_script()
			);

			

			$this->initilize_style_and_scripts( $this->_plugin_register_styles_and_script , false );
			$this->initilize_style_and_scripts( $this->_plugin_enqueue_styles_and_script );

			

			$this->init_posttypes();
			$this->init_taxonomies();
			$this->init_shortcodes();
			$this->init_actions();
			$this->init_filters();
			
			$this->init_posthandler();
			$this->init_rest_api();

			add_action( 'init', [$this, "init_controllers"], 10 );
			//$this->init_controllers();


	        self::$plugin_initilized = 1 ;
	        do_action("cx_plugin_". $this->_plugin_namespace . "_init");
	        return 1;


    	}

    	public function get_called_class_key() {
    		$called_class = \get_called_class();
    		$called_class = explode("\\", $called_class);
    		return implode("_", $called_class);
    	}
    	public function __($str, $namespace = null) {
    		return __($str, ( !$namespace ) ?  $this->_plugin_namespace : $namespace);
    	}

    	public function plugin_intall(){

    		
	        $path_db_init = $this->_plugin_path . "install_uninstall_setup/db_install.php";
	        $path_php_init = $this->_plugin_path . "install_uninstall_setup/install.php";


	        // reg roles
	        foreach ($this->_plugin_user_roles as $role => $info) {
				add_role( 
					$role,  
					isset($info['label']) ? $this->__($info['label']) :  $this->__($role), 
					isset($info['capabilities']) ? $info['capabilities'] : []  
				);
			}


	        if ( file_exists($path_db_init) ) include( $path_db_init );
	        if ( file_exists($path_php_init) ) include( $path_php_init );

    	}

    	public function plugin_unintall(){

	        $path_db_uninit =  $this->_plugin_path  . "install_uninstall_setup/db_uninstall.php";
	        $path_php_uninit =  $this->_plugin_path  . "install_uninstall_setup/uninstall.php";

	        if ( file_exists($path_db_uninit) ) include( $path_db_uninit );
	        if ( file_exists($path_php_uninit) ) include( $path_php_uninit );


    	}

    	protected function factory($dir,$name) {

    		$class_name = $this->_plugin_namespace . "\\". $dir . "\\" . $name;
    		
    		if ( !isset(self::$instances[$dir])) self::$instances[$dir] = [];



    		if ( !isset(self::$instances[$dir][ $class_name ] ) ) {

    			include_once( $this->_plugin_path . "/". $dir ."/". $name .  ".php" );
    			if ( class_exists($class_name)) {
    				self::$instances[$dir][ $class_name ] = new $class_name;	
    			} 
    		}

  
    		return self::$instances[$dir][ $class_name ];

    		
    	}

    	public function action($str) {
    		return $this->factory( "action", $str );
    	}
    	public function controller($str) {
    		return $this->factory( "controller", $str );
    	}
    	public function filter($str) {
    		return $this->factory( "filter", $str );
    	}
    	public function helper($str) {
    		return $this->factory( "helper", $str );
    	}
    	
    	public function model($str) {
    		return $this->factory( "model", $str );
    	}
    	public function posttype($str) {
    		return $this->factory( "posttype", $str );
    	}
    	public function rest($str) {
    		return $this->factory( "rest", $str );
    	}
    	public function shortcode($str) {
    		return $this->factory( "shortcode", $str );
    	}
    	public function table($str) {
    		return $this->factory( "table", $str );
    	}
    	public function taxonomy($str) {
    		return $this->factory( "taxonomy", $str );
    	}
    	
    	public function plugin_option( $namelist = [] ) {

    		if ( !is_array($namelist) && is_string($namelist)) $namelist = [$namelist];
    		$data = get_option( $this->_plugin_options );

    		if ( !$data ) return null;

			if ( !is_array($data) && is_string($data) && isJson($data) ) {
				
				$data = json_decode( $data , TRUE );	
			} 

			$returndata = $data;
			

			foreach ($namelist as  $name) {
				if ( !isset($returndata[$name] ) ) {
					return null;
				} else {
					$returndata = $returndata[$name];
				}
			}
			return $returndata;
    	}

    	public function update_plugin_option( $name_list = [] , $val ) {

    		$opt = get_option( $this->_plugin_options );
			if ( !$opt ) {$opt = [];}
			if ( !is_array($opt) &&  isJson($opt) ) {
				$opt = json_decode( $opt , 1 );
			}
			
			$opt = cx_set_array_value($opt,$name_list,$val);
			
			update_option( $this->_plugin_options , $opt );

    	}
    	

    	protected function enqueue_styles_and_script($base_assets = []) { return $base_assets; }
    	protected function register_styles_and_script($base_assets = []) { return $base_assets; }
    	
    	

    	private function register_base_styles_and_script() {
    		$ns 	= $this->_plugin_namespace;
	    	$uri 	= $this->_plugin_uri;
    		
	    	return [];

    	}
	    private function enqueue_base_styles_and_script() {
	    	
	    	$ns 	= $this->_plugin_namespace;
	    	$uri 	= $this->_plugin_uri;

	    	return [

	    		"jquery" => ["type"	=>	"js",],


	    		$ns . "_dynamic" => [
	                "url"           => $uri . '/asset/dynamic.css',
	    		],
	    		$ns . "_base_style" => [
	                "url"           => $uri . '/asset/base.css',
	    		],

	    		$ns . "_base_script" => [
	                "url"           => $uri . '/asset/base.js',
	                "required"      => ['jquery'],
	    		],





	    		$ns . "_admin_styles" => [
	                "url"           => $uri . '/asset/admin.css',
	                "condition"     => is_admin(),
	    		],

	    		$ns . "_admin_scripts" => [
	                "url"           => $uri . '/asset/admin.js',
	                "required"      => ['jquery' , $ns . "_base_script"],
	                "condition"     => is_admin(),
	    		],




	    		$ns . "_front_styles" => [
	                "url"           => $uri . '/asset/front.css',
	                "condition"     => !is_admin(),
	    		],

	    		$ns . "_front_scripts" => [
	                "url"           => $uri . '/asset/front.js',
	                "required"      => ['jquery' , $ns . "_base_script"],
	                "condition"     => !is_admin(),
	    		],





	    	];
	    }
	    protected function initilize_style_and_scripts($styles_and_script =[], $enqueue = 1) {
	    	
	    	
	    	foreach ($styles_and_script as $asset_namespace => $data ) {

	    		$condition = 1;
	    		$type = "";
	    		$function_name = null;
	    		$url = null;
	    		$require = [];
	    		$ver = false;
	    		$media = 'all';


	    		if ( isset( $data["version"] ) )  {
	    			$ver = $data["version"];
	    		}
	    		if ( isset( $data["media"] ) )  {
	    			$media = $data["media"];
	    		}


	    		if ( isset( $data["condition"] ) )  {
	    			$condition = $data["condition"];
	    		}

	    		if ( !isset($data["type"]) && !isset($data["url"]) ) {
	    			
	    			$condition = 0;

	    		} else if ( !isset($data["type"]) && isset($data["url"]) ) {
	    			
	    			$ext = explode(".", $data["url"]);
	    			$ext = $ext[ count($ext) -1 ];
	    			$ext = trim($ext);
	    			$ext = explode("?", $ext);
	    			$ext = $ext[0];
	    			$ext = trim($ext);
	    			$ext = strtolower($ext);

	    			$type = $ext;

	    		} else {

	    			$type = $data["type"];

	    		}


	    		if ( isset($data["url"])) {
	    			$url = $data["url"];
	    		}

	    		if ( isset($data["required"])) {
	    			$required = $data["required"];
	    		}

	    		if ( in_array($type, $this->supported_styles )) {

	    			$function_name = ($enqueue) ? 'wp_enqueue_style' : "wp_register_style";

	    		}
	    		if ( in_array($type,$this->supported_scripts )) {

	    			$function_name =  ($enqueue) ? 'wp_enqueue_script': "wp_register_script";

	    		}




    			if ( $condition && $function_name) {
    				$function_name( $asset_namespace , $url , $require , $ver , $media);

    			}

	    		
	    	}

	    }


 		private function init_dir($dir, $function = null) {

	    	// fail save not to reinitilize dirs
	    	if ( in_array($dir, self::$static_initilized_dirs) ) return;

	    	self::$static_initilized_dirs[] = $dir;

	    	$ns = $this->_plugin_namespace;

	    	foreach(glob($this->_plugin_path . "/$dir/*.php") as $file){

	    		
				// require_once $file;
				// if ( $namespace ) {
				// 	$class_name = $namespace . "\\" . basename($file,".php");
				// } else {
				// 	$class_name = $ns . '\\' . basename($file,".php");	
				// }
				
				

				$factory_method = $dir;

				$instance = $this->$factory_method(basename($file,".php"));
				
				if ( $function && method_exists($instance, $function)) $instance->$function();
    
			}
	    }


	    private function init_posttypes() {
	    	$this->init_dir("posttype");
	    }
		private function init_taxonomies() {
			$this->init_dir("taxonomy");
		}
		private function init_rest_api() {
			$this->init_dir("rest");
		}
		private function init_shortcodes() {
			$this->init_dir("shortcode", "register" );
		}
		private function init_actions() {
			$this->init_dir("action",   "register");
		}
		private function init_filters() {
			$this->init_dir("filter",  "register");
		}
		


		public function init_controllers() {
			$this->init_dir("controller","register");
		}
		private function init_posthandler() {
			
		}
		

		public function add_posthandels($handels = null){
			if ( !$handels ) return null;
			

			$opt = get_option( $this->_plugin_post_handels );
			
			
			if ( !$opt ) $opt = "[]";
			$opt = json_decode($opt,1);
			
				
			foreach ($handels as $form_type_key => $function_list) {

				if ( !isset($opt[$form_type_key]) ) {
					$opt[$form_type_key] = [];
				}

				foreach ($function_list as $function_key => $data) {
					
					
					$opt[$form_type_key][$function_key] = $data;
				}
			}

			$opt = json_encode($opt);
			

			update_option($this->_plugin_post_handels ,$opt);
			
		}

		public function get_posthandels() {
			$opt = get_option( $this->_plugin_post_handels );
			if ( !$opt ) $opt = "[]";
			return json_decode($opt,1);
		}
	}
}