<?php 

namespace cx_cpo;

if ( !class_exists("cx_cpo\\cx_base_controller")) {

	abstract class cx_base_controller extends cx_base {

		// xwt plugin namespace and dir
		

		// the pram_name that is reading from the url and hold the name of function of this contoller to be called
		protected $route_name ="";


		// the full path of the main folder where the template files exist
		protected $template_dir ="";

		
		
		/*
		* list of whcih rount will be handeld by which function of current conroller class
			exmaple body {
				return [
					"url_key" => [
						"nav_label" => "",
						"show_in_nav" => "",
						"handler" => "",

					]	
				];
			}
		*/
		protected $page_routes =[];

		// keep the lis
		protected $post_handlers =[];

		// default page
		protected $default_controller = "";


		// only for base controller, the data will pass into pages
		protected $base_data= [];


		// path to base template
		protected $base_template_path ="";
		protected $base_template_dir ="";



		function __construct() {

			parent::__construct();
			
			$this->plugin_option_key = cx_get_config("plugin_option_data",$this->_plugin_namespace);
			$this->base_data["plugin_option_key"] = $this->plugin_option_key;

			$this->base_template_dir = $this->_plugin_path . "/template/";

			$this->session_msg_key = get_called_class();
			$this->base_data["session_msg_key"] = $this->session_msg_key;

			add_action( "wp", [$this, "_setup_page_routes" ], 10, 1 );
			//$this->_setup_page_routes();
			
			$this->posthandler = $this->setup_post_handler();
			$this->add_posthandels($this->posthandler);
			
			add_action("wp_loaded",  function() {
				$this->setup_global_scripts();	
			});
			

			
			
			if ( 
				!$this->base_template_path || 
				!strlen($this->base_template_path) ||
				!file_exists($this->base_template_path)
			) {

				$base_path =  $this->template_dir."/base.php";	
				if ( file_exists($base_path)) {
					$this->base_template_path = $base_path;
				} else {
					$this->base_template_path = $this->_plugin_path. "/template/controller/base.php";
				}
				
			}

			$this->render_helper = $this->helper("render");
			
			$this->base_data["render_helper"] = $this->render_helper;
			$this->base_data["page_title"] = $this->page_title;
			$this->base_data["template_dir"] = $this->template_dir;
			$this->base_data["namespace"] = $this->_plugin_namespace;
			$this->base_data["flag_page_header"] = 1;
			
			$this->base_data["THIS"] = $this;

		}
	
		public function _setup_page_routes() {
			$default_value = [
				"show_in_nav"=>1,
			];

			$routes = $this->setup_page_routes();

			foreach ($routes as $url_key => $value) {

				if ( is_array($value) ) {
					// looping the default attra
					foreach ($default_value as $dd => $vv) {
						if ( !isset($routes[$url_key][$dd]) ) $routes[$url_key][$dd] = $vv;
					}
				
				} else {

					$routes[$url_key ] = $default_value;
					$routes[$url_key ]["nav_label"] = $url_key ;
					$routes[$url_key ]["slug"] = $url_key ;


				}
				// if handler is not set
				if ( !isset($routes[$url_key]["handler"]) ) 
					$routes[$url_key]["handler"] = $url_key;

				// if label is not set
				if ( !isset($routes[$url_key]["nav_label"]) ) 
					$routes[$url_key]["nav_label"] = str_replace("/_/", " ", strtolower($url_key)) ;

			}

			$this->page_routes = $routes;
			$page_routes_key = array_keys($this->page_routes);

			if ( !$this->default_controller || strlen($this->default_controller) == 0 || 
				!in_array($this->default_controller, $page_routes_key )) {
				$this->default_controller = $page_routes_key[0];

			}
		}
		public function get_routes() {

			if ( !count($this->page_routes)) $this->_setup_page_routes();
			return $this->page_routes;
		}
		
		public function render(){
			
			$route = $this->getCurrentRout();
			

			$this->$route();

		}
		
		public function get_session_msg_html($delete_msg = 1){
			return cx_get_session_msg_html($delete_msg);
		}
		protected function getCurrentRoutName() {

			$r = $this->get_routes();
		    $route = (isset($_GET[ $this->route_name ])) ? $_GET[ $this->route_name ] : $this->default_controller;
			$route = strtolower($route);
            if ( isset($r[$route])) {
                return $route;
            } 
            return null;

		}
		protected function getCurrentRout() {

            $route = $this->getCurrentRoutName();
			$route_opt = $this->page_routes[$route];
			if ( $route && isset($route_opt) &&  isset($route_opt["handler"])) {
				return $route_opt["handler"];
			} else {
				return "route_404";
			}
			
		}
		public function get_url($key, $args = []) {
			
			

			if ( !isset($this->page_routes[$key]) ) {
				return null;
			}

			$opt = $this->page_routes[$key];
			$base_url = $this->base_controller_url;
			if ( !strpos($base_url, "?")) {
				$base_url .= "?";
			}
			$query_pram = "";

			if ( !is_array($args)) $args = [];
			if ( !isset($opt["url_parameters"]) ) $opt["url_parameters"] = [];
			

			$query_pram = "&" .  http_build_query(array_merge($opt["url_parameters"], $args));
			return $base_url ."&". $this->route_name . "=".$key . $query_pram;
		}
		protected function header() {

			$route =$this->getCurrentRoutName();
			ob_start();
            
			?><ul><?php 

				$last = end(array_keys($this->page_routes));
				foreach ($this->page_routes as $route_key => $opt) {
					
					if ( !$opt["show_in_nav"] ) continue;
					if ( $route_key == $last ) continue;


					$active = ($route == $route_key ) ? "active" : "";
					$url = ( isset($opt['url']) ) ? $opt['url'] :  $this->get_url($route_key); 
					
					?><li class="<?php echo $active ?> ">
						<a href="<?= $url ?>"><?php 
							echo __($opt["nav_label"],"xwt"); 
						?></a>
					</li><?php 
				}
				

				do_action( $this->get_called_class_key() ."_render_header_before_last_li", [] );


				$route_key 	= $last;
				$opt 		= $this->page_routes[$route_key];
				
				$active = ($route == $route_key ) ? "active" : "";
				$url = ( isset($opt['url']) ) ? $opt['url'] :  $this->get_url($route_key); 
				
				?><li class="<?php echo $active ?> ">
					<a href="<?= $url ?>"><?php 
						echo __($opt["nav_label"],"xwt"); 
					?></a>
				</li><?php 
				 

			?></ul><?php 
			
			$str = ob_get_clean();
			
			return $str;
		}
		protected function load_template($name, $d = []) {

			
			$d["page_header"] = $this->header();
			$d["content"]  = $name . ".php";
			$d["namespace"]  = $this->_plugin_namespace;
			$d["page_nav"] = $this->header(); 
			$d["session_msgs"] = $this->get_session_msg_html();

			

			foreach ($d as $key => $value) {
				set_query_var($key,  $value);
			}


			load_template( $this->base_template_path );
			
			

		}
		abstract protected function setup_post_handler();
		abstract protected function setup_page_routes();
		abstract protected function setup_global_scripts();
		abstract public function route_404();

		public function action_admin_menu() {
			
			$class_name = get_called_class();
			$opt = static::$controller_options; 

			$action = $opt["page_type"];
		
			switch ($action) {
				
				case 'menu_page':
	            /*psrent slud*/
				/*$page_title*/
				/*$menu_title*/
				/*$capability */ 
				/*$menu_slug */
				/*$function  */ 
				add_menu_page( 
					$opt["page_title"],
					$opt["menu_title"],
				    'manage_options',
					$opt["slug"], 
					$class_name::controller_instance()
				); 
				break;

				case 'options_page':
					/* page title */
					/* menu title */
					/* capability */
					/* page slug  */
					/* function   */
					add_options_page( 
						$opt["page_title"],
						$opt["menu_title"],
						'manage_options', 
						$opt["slug"],
						$class_name::controller_instance()
					);

				break;

				case 'submenu_page':
					/*psrent slud*/
					/*$page_title*/
					/*$menu_title*/
					/*$capability */
					/*$menu_slug */
					/*$function  */ 
					add_submenu_page( 
						$opt["parent_slug"],
						$opt["page_title"],
						$opt["menu_title"],
						'manage_options', 
						$opt["slug"], 
						$class_name::controller_instance()
					); 

				break;
				

				default:
					# code...
					break;
			}
					
					
			
		}
		public function register(){

			add_action( 'admin_menu',[$this,"action_admin_menu"]);
		}
	}
}