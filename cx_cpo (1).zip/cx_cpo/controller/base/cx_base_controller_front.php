<?php 

namespace cx_cpo;

include_once(realpath(__DIR__ . "/cx_base_controller.php") ); 

if ( !class_exists("cx_cpo\\cx_base_controller_front")) {

	abstract class cx_base_controller_front extends cx_base_controller {

		
		
		// the pram_name that is reading from the url and hold the name of function to be called
		protected $route_name ="";
		
		

		// the full path of the main folder where the template files exist
		protected $template_dir ="";
		
		
		// page title		
		protected $page_title= "";

		protected $page_id;
		protected $page_base_permalink;

		public static $controller_options =[];

		function __construct(){
			parent::__construct();
		}

		protected function controller_init() {

			add_action( "init", [$this, "controller_rewrite"], 999999, 1 );
			add_action( "wp", [$this, "init_content_filter"], 10, 1 );
			
			

			
		}
		
		public function controller_rewrite() {

			$page_id = $this->page_id;

			$this->page_base_permalink = \get_permalink($this->page_id);
			$this->base_data['base_link'] = $this->page_base_permalink;
			

			$slug = \get_post_field( 'post_name', intval($page_id) );

			$rewrite_tags = $this->setup_rewrite_tags();
			$page_routes = $this->setup_page_routes();


			add_rewrite_tag( '%cx_controller%', '([^/]*)' );

			foreach ($rewrite_tags as $key => $value) {

				add_rewrite_tag( "%" .  $this->_plugin_namespace . "_" . $key . "%", $value );

			}
			$rules = get_option( 'rewrite_rules' );
			
			$flush_rules = 0;

			foreach ($page_routes as $url => $opt) {

				$pram_str = "";
				if ( isset($opt['args'])) {
					$counter = 1;
					foreach ($opt['args'] as $v) {
						$tag = $this->_plugin_namespace . "_" . $v;

						$pram_str .= "&" . $tag . '=$matches['.$counter.']';
						$counter++;
					}
				}
				

				$r = $slug . $url . '/?$';
				$r = implode("/", explode("//", $r));
				
				add_rewrite_rule(
	              	$r,
	                'index.php?pagename='.$slug.'&cx_controller=' . $opt['handler'] . $pram_str ,
	                'top'
	            );
				if ( !isset($rules[$r]) ) { 
					
		            $flush_rules = 1;

		        }
			}

			
			// if ( $flush_rules ) {
			// 	global $wp_rewrite; 
			// 	$wp_rewrite->flush_rules();

			// }
			

		}
		protected function after_controller_rewrite() {}

		public function init_content_filter() {

			

			global $post;
			if ($post->ID == $this->page_id) {
				add_filter("the_content", function ($content) {
					
					$c = implode("-", explode("\\", get_called_class())) ;
					ob_start();
					?><div class="cx cx-page-controller cx-controller-<?= $c ?>"><?php 

						$this->render();
						$content .= ob_get_clean();	

					?></div><?php
					

					return $content;	
				});
			}
		}
		/* implementing abstract from base  */
		protected function setup_post_handler(){
			return [];
		}
		/* implementing abstract from base  */
		protected function setup_page_routes() {
			return [];
		}

		/* implementing abstract from base  */
		protected function setup_global_scripts(){
			
		}
		protected function _setup_page_routes() {}
		protected function getCurrentRout() {

			global $wp_query;
			$prams = $wp_query->query;
			
			
			if ( isset($prams['cx_controller']) && method_exists($this,$prams['cx_controller']) ) {
				return $prams['cx_controller'];
			} else {
				return "route_404";
			}
   			// $route = $this->getCurrentRoutName();
			// $route_opt = $this->page_routes[$route];
			// if ( $route && isset($route_opt) &&  isset($route_opt["handler"])) {
			// 	return $route_opt["handler"];
			// } else {
			// 	return "route_404";
			// }
			
		}
		public function render(){

			global $wp_query;
			$prams = $wp_query->query;
			unset($prams['cx_controller']);
			$new_pram = [];

			
			foreach ($prams as $key => $value) {
				
				$key = str_replace(  $this->_plugin_namespace . "_" , "", $key);
				$new_pram[$key] = $value;
			}
			
			$route = $this->getCurrentRout();
			$this->$route($new_pram);

		}

	}
}
