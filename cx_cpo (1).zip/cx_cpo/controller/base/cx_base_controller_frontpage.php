<?php 

namespace cx_cpo;

include_once(realpath(__DIR__ . "/cx_base_controller.php") ); 

if ( !class_exists("cx_cpo\\cx_base_controller_frontpage")) {

	abstract class cx_base_controller_frontpage extends cx_base_controller {

		
		
		// the pram_name that is reading from the url and hold the name of function to be called
		protected $route_name ="";
		
		

		// the full path of the main folder where the template files exist
		protected $template_dir ="";
		
		
		// page title		
		protected $page_title= "";

		public static $controller_options =[];


		function __construct(){
			
			global $post;

			if ( $post ) {

				$page_id = $post->ID;	
				$this->page_id = $page_id;
				$this->base_data["page_id"] = $this->page_id;
				$this->base_controller_url = get_permalink($page_id);

			} 

			parent::__construct();

		}

		/* implementing abstract from base  */
		protected function setup_post_handler(){
			return [];
		}
		/* implementing abstract from base  */
		protected function setup_page_routes() {
			return [];
		}

		/* implementing abstract from base  */
		protected function setup_global_scripts(){
			
		}


	}
}
