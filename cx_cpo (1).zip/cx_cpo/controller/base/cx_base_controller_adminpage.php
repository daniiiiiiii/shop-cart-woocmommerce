<?php 

namespace cx_cpo;

include_once(realpath(__DIR__ . "/cx_base_controller.php") ); 

if ( !class_exists("cx_cpo\\cx_base_controller_adminpage")) {

	abstract class cx_base_controller_adminpage  extends cx_base_controller  {

		

		// the pram_name that is reading from the url and hold the name of function of this contoller to be called
		protected $route_name ="";
		protected $template_dir ="";

		public static $controller_options =[];
		

		
		// the slug of the page , wordpress read page=$slug in pram and call the controller, will auto added if setup in $controller_options
		protected $page_slug ="";
		protected $base_controller_url = "";



		function __construct(){
			
			

			$called_class =get_called_class();

			$class_actual_name = explode("_", $called_class);
			$class_actual_name = $class_actual_name[ count($class_actual_name )-1];

			$slug = $called_class::$controller_options["slug"];
			
			if ( isset($slug)) { 
				$this->page_slug = $slug ;
			} else {
				$this->page_slug = $class_actual_name;
				$called_class::$controller_options["slug"] = $class_actual_name;
			}

			if ( !strlen($this->route_name) ) {
				// check slugh exist else 
				$this->route_name = $this->page_slug;
			}

			// template folder bydefault will be the late part of contorller
			if ( !strlen($this->template_dir) ) {

				$this->template_dir =$class_actual_name;
			}


			if( !strlen($this->base_controller_url)) {

				if ( $called_class::$controller_options["page_type"] == "options_page" ) {

					$this->base_controller_url = admin_url(). "options-general.php?page=" . $this->page_slug;
				} 

				if ( $called_class::$controller_options["page_type"] == "submenu_page" ) {

					$this->base_controller_url = admin_url(). $called_class::$controller_options["parent_slug"] . 
					"&page=". $this->page_slug;
				}
				
				if ( $called_class::$controller_options["page_type"] == "menu_page" ) {

					$this->base_controller_url = admin_url(). "?page=". $this->page_slug ;

				}
				
				

			}
			

			// setting up page title
			if ( strlen( $this->plugin_page_title ) ) {
				$this->base_data["page_title"] = $this->plugin_page_title;
			} else {
				$this->base_data["page_title"] = $called_class::$controller_options["page_title"];
			}
			$this->page_title = $this->base_data["page_title"];

			parent::__construct();

		}
		public static function controller_instance() {
			
			$class_name =get_called_class();
	        $classinstance = new $class_name();
			return [ &$classinstance, "render"];
			
		}

		

		

	}
}
