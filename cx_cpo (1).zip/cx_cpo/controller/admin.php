<?php

namespace cx_cpo\controller;

include_once(realpath(__DIR__ . "/base/cx_base_controller_adminpage.php") ); 

if ( !class_exists("\\cx_cpo\\controller\\admin")) {


	class admin extends \cx_cpo\cx_base_controller_adminpage {
			
		
	
		// the pram_name that is reading from the url and hold the name of function of this contoller to be called
		protected $route_name ="cx";
		

		protected $template_dir = "" ;
		
		protected $plugin_page_title ="Cx Settings";

		public function __construct() {
	

			
			$this->template_dir 		= $this->_plugin_path . "/template/controller/admin/settings" ;
			$this->plugin_page_title	= "CX Settings";
			$this->route_name 			= "CX";
			parent::__construct();


		}



		public static $controller_options =[
				// plugin 
				"page_type"=>"options_page", /* options_page, submenu_page, menu_page */

				"page_title"=>"Custom Product Order Settings ",
				"menu_title"=>"Custom Product Order Settings ",
				// if slug not proveded it will use the last part of controller name
				"slug"=>"cx_cpo", 
				// only requre if page_type is submenu_page
				//"parent_slug"=>"edit.php??post_type=someposttype",
		];

		/* optional vals override */
		


		
		/*
			post handler
		*/
		/* implementing abstract */
		protected function setup_post_handler(){

			return [
				"cx_form_type"=>[
					"controller_admin_general"=> [
						__FILE__,
						get_called_class(),
						"_setting_save"
					],
					
				],
			];
		}
		/* implementing abstract  */
		protected function setup_page_routes(){
			return [

				"home"=>[
					"nav_label"=>"general settings",
					"handler"=>"general_setting",

				],
				
				
			];
		}
		/* implementing abstract  */
		protected function setup_global_scripts() {
			
			wp_enqueue_script('jquery');
			
			if ( is_admin() ) {
				add_action( "wp", function() {
					wp_enqueue_media();	
				}, 10, 1 );
				
			}

			
    		
		}
		/* implementing abstract  */
		public function route_404() {
			
		}

		
		
		

		public function general_setting(){

			$this->general = $this->plugin_option(["general"]);
			
			$form = [
				"method"=>"post",
				"elements"=> [
					"cx_form_type" => [ "type"=> "hidden", "value"=>"controller_admin_general"],
					"cx_from_wraper" => [ "type"=> "hidden", "value"=>"general"],
	
					
					
					
					"general[page][order_page]" => [
						"label"=> "order page", 
						"value"=> $this->general["page"]["order_page"],
						"type"=>"select",
						"options"=>\get_pages_as_options(),
						"options_assoc"=>1,
					], 
					"general[page][order_product]" => [
						"label"=> "order product", 
						"value"=> $this->general["page"]["order_product"],
						"type"=>"select",
						"options"=>\get_posts_as_options('product'),
						"options_assoc"=>1,
					], 
					
				
					
				],
				"render_groups"=> 0,
				"submit" => [
					"value" => "save",	
				],
			];
			$this->base_data["form_titile"] = "general setting";
			$this->base_data["page_form"] = $form;

			$this->load_template($this->base_template_dir . "/controller/base_form", $this->base_data );
		}
		
		
		/* post function */
		public function _setting_save($p) {

			if ( !is_admin() ) return null;
			// only supprt 2 dimmentail post 
			$opt = get_option($this->_plugin_options );

			if (  !is_array($opt) ) {
				if (is_null($opt) || !strlen($opt) ) $opt = "[]";
				$opt = json_decode($opt,1);
			}

			if ( $opt === NULL ) $opt = [];

			$key = $p["cx_from_wraper"];

			// neeed improvment here
			foreach ($p[$key] as $kk => $vv) {
				$opt[$key][$kk] =  $vv;
			}
			//$opt[$key] =  $p[$key];

			$opt = json_encode($opt);

			update_option($this->_plugin_options ,$opt);
			
		}

		
		
	}

}