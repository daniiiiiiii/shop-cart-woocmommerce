<?php 


// uninstall actions

