<?php
  
// addingg db tables here 

/*
*  remove this exit
*  -----------------------------------
*/

/*
--------------------------
*/



global $wpdb;

$charset_collate = $wpdb->get_charset_collate();


require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );

$px = $wpdb->prefix . "cx_cpo_";






// $tbl_user_ticket = $px . "user_ticket";
// $sql_create_user_ticket = "

// CREATE TABLE IF NOT EXISTS `$tbl_user_ticket` (

//   `user_ticket_id`   int(11) NOT NULL AUTO_INCREMENT,
//   `user_id`          int(11),
//   `event_id`        int(11),
//   `order_id`        int(11),
//   `event_status`     int(11),
  
//   PRIMARY KEY (`user_ticket_id`)
// ) $charset_collate;
// ";
// dbDelta( $sql_create_user_ticket );
















/*


$sql_drop_table = "

  DROP TABLE IF EXISTS `cx_freelancerproject_proposal`;
	
";

// dbDelta( $sql_drop_table );



$sql_create_table = "


CREATE TABLE `cx_freelancerproject_proposal` (
  `pid` int(11) NOT NULL AUTO_INCREMENT,
  `freelancer_id` int(11) NOT NULL,
  `project_id` int(11) NOT NULL,
  
  `price` int(11) NOT NULL,
  `days` int(11) NOT NULL,


  `status` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` TEXT NOT NULL,
  `created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `last_updated` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,

  PRIMARY KEY (`pid`)
) $charset_collate;

";

// dbDelta( $sql_create_table );

// adding sql
foreach(glob(__DIR__ . "/*.sql") as $file){
    $sql_data=file_get_contents($file);
    
 	if ( $sql_data ){
 		// dbDelta( $sql_data );
 	}
     
}

$_plugin_uri = plugin_dir_url( __FILE__ );

$sql_update= "
	
"; 

// dbDelta( $sql_update );
*/

