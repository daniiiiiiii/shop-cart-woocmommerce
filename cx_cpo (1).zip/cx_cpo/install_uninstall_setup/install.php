<?php 


$user_list = ['Order'];

foreach ($user_list as $u) {

	$_page_id = post_exists_by_slug($u, "page");

	if ( !$_page_id  ) {
		
		$_page_id = wp_insert_post([
			"post_title"	=> $u,
			"post_status" 	=> "publish",
			"post_content" 	=> "[cx_cpo_order ]",
			"post_type"	 	=> "page",
		]);

	}


}


// install actions
/*
$namespace = CX_STORATES;
$plugin_path = CX_STORATES_PATH;
$plugin_uri = CX_STORATES_URI;


// not able to retun cx_get_config, may be global variable not in scope
$plugin_option_key = cx_get_config("plugin_option_data",$namespace);
if ( !$plugin_option_key ) {
	$plugin_option_key = $namespace . "_data";
}




cx_set_option_value($plugin_option_key, [
		"general_setting",
		"pages",
		"vendor_dashboard",
	] , $vendor_page_id
);

*/



// if ( !file_exists(ABSPATH . "/api_imgs/country/")) mkdir(ABSPATH . "/api_imgs/country/");
// if ( !file_exists(ABSPATH . "/api_imgs/country/flag/")) mkdir(ABSPATH . "/api_imgs/country/flag/");

// if ( !file_exists(ABSPATH . "/api_imgs/league/")) mkdir(ABSPATH . "/api_imgs/league/");
// if ( !file_exists(ABSPATH . "/api_imgs/league/flag/")) mkdir(ABSPATH . "/api_imgs/league/flag/");
// if ( !file_exists(ABSPATH . "/api_imgs/league/logo/")) mkdir(ABSPATH . "/api_imgs/league/logo/");

// if ( !file_exists(ABSPATH . "/api_imgs/player/")) mkdir(ABSPATH . "/api_imgs/player/");
// if ( !file_exists(ABSPATH . "/api_imgs/player/")) mkdir(ABSPATH . "/api_imgs/player/");
