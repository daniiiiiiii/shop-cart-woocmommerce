<?php 


namespace cx_cpo;

if ( !class_exists("\\cx_cpo\\cx_base_filter")) {

	
	class cx_base_filter extends cx_base {

		protected $hook = "";
		protected $priority = 10;
		protected $accepted_args = 1;

		
		public function register() {
			if ( strlen($this->hook) ) {
				add_filter( $this->hook ,  [$this,"run"] ,  $this->priority ,  $this->accepted_args );	
			}
			
		}
		
	}
}
