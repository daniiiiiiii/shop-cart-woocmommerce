<?php 

namespace cx_cpo\filter;

include_once(realpath(__DIR__ . "/base/cx_base_filter.php") ); 

if ( !class_exists("\\cx_cpo\\filter\\body_classes")) {

	class body_classes extends \cx_cpo\cx_base_filter { 

		protected $hook = "body_class";

		public function run($classes) {

			$classes[] = "cx";
			$classes[] = "cx_hs";
			$classes[] = $this->_plugin_namespace ;
			
			return $classes;
			
		}
	}
}

