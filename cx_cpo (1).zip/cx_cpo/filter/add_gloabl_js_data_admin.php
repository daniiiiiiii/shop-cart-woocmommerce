<?php 

namespace cx_cpo\filter;

include_once(realpath(__DIR__ . "/base/cx_base_filter.php") ); 

if ( !class_exists("\\cx_cpo\\filter\\add_gloabl_js_data_admin")) {

	class add_gloabl_js_data_admin extends \cx_cpo\cx_base_filter { 

		protected $hook = "cx_base_js_public_data";

		public function run($d) {
			if ( is_admin() ) {
				$d["agent_list"] = \get_users_as_options("agent");
			}
			return $d;
			
		}
	}
}

