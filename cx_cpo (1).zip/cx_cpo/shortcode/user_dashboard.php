<?php 

namespace cx_cpo\shortcode;

include(realpath(__DIR__ . "/base/cx_base_shortcode.php") ); 

if( !class_exists("\\cx_cpo\\shortcode\\user_dashboard") ){

	class user_dashboard extends \cx_cpo\cx_base_shortcode {

		protected $attributes = [
			"wraper_class" => "",
			'user'	=> 'user',
		];

		public function render($attrs = []) {

			extract($attrs);
		

			
			?><div class="xwt cx_shortcode <?= $this->get_shortcode_key() ?> <?= $attrs["wraper_class"] ?>"><?php 

			
				$user = $this->controller($attrs["user"]);
				
				if ( $user ) $user->render();	
				
				

			?></div><?php 
		}
	}
}
