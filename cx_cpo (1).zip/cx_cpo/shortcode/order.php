<?php 


namespace cx_cpo\shortcode;

include(realpath(__DIR__ . "/base/cx_base_shortcode.php") ); 

if( !class_exists("\\cx_cpo\\shortcode\\order") ){

	class order extends \cx_cpo\cx_base_shortcode {

		protected $attributes = [
			"wraper_class" => "",
		];


		public function render($attrs = []) {

			

			global $wp,$wp_query;
			extract($attrs);
			
			$this->add_posthandels([
				"cx_form_type"=>[
					"cx_cpo_shortcode_order_submit"=> [
						__FILE__,
						get_called_class(),
						"_add_item_to_cart"
					],
				]
			]);

			$sizes = get_posts([
				'post_type'	=>'cx_cpo_size',
			]);
			
			$category = get_terms('cx_cpo_category');

			$mixtures = get_posts([
				'post_type'	=>'cx_cpo_mixture',
				'fields'		=> 'ids',
			]);

			$data = [];
			foreach ($mixtures as $id) {
				$attrs = \cx_cpo\posttype\mixture::get_attributes_value($id);
				$data[$id] = $attrs;

			}
			?><script>
				const MIXTURE_PRICES = <?= json_encode($data); ?>;
			</script><?php 

			?><form class="step-wraper" method="post" action="#" id="cx-cpo-order-form" >
				
	

				<input type="hidden" name="cx_form_type" value="cx_cpo_shortcode_order_submit" />

				<div class="c-c ">
					<div class="step-from-wraper s10 t7 w75 ">
						<div class="header-text txt-center">
							<h2 ><?= $this->__("Create Your own Muesli Mix") ?></h2>
							<p><?= $this->__("Choose your bag or bucket"); ?></p>
						</div>						
						<div class="p step-from-container">
							<div class="form-setp step_1 txt-center">
							
								<div class="setp-content-container">
									<div class="c-c c-s5 c-t33 c-w25 c-l20"><?php 

										foreach ($sizes as $k =>  $s ) {

											$attrs = \cx_cpo\posttype\size::get_attributes_value($s->ID);

											$thumb = get_the_post_thumbnail_url($s->ID);

											?><div class="size-wraper p">
												<div class="box size-item-container">
													<input 
														id="size-<?= $s->ID ?>"
														type="checkbox"
														name="cx_options[size]"
														value="<?= $s->ID ?>"
														
														data-price='<?= $attrs['price'] ?>'
														data-weightage='<?= floatval($attrs['weightage']) ?>' 
														class="hide cx-input-size" 
													/>
													<div class="checkboxxwt">
<svg width="22" height="22" viewBox="0 0 22 22" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M19.5556 0H2.44444C1.09389 0 0 1.09389 0 2.44444V19.5556C0 20.9061 1.09389 22 2.44444 22H19.5556C20.9061 22 22 20.9061 22 19.5556V2.44444C22 1.09389 20.9061 0 19.5556 0ZM8.55556 17.1111L2.44444 11L4.17389 9.27056L8.55556 13.6522L17.8261 4.38167L19.5556 6.11111L8.55556 17.1111Z" fill="#4EBAA9"/>
</svg>
																	
																	
																</div>						
													<label class="customlabel" for="size-<?= $s->ID ?>"><?php 
														if ( $thumb )  {
															?><img src="<?= $thumb ?>"/><?php 	
														}
														?><span class="title"><?= $s->post_title ?></span>
														<span class="weight"><?= floatval($attrs['weightage']) ?> gram</span><?php
														
													?></label>
													
													
												</div>

											</div><?php
										}
									?></div>
								</div>
								<div class="infoicon">
									<ul>
										<li><span><svg width="23" height="23" viewBox="0 0 23 23" fill="none" xmlns="http://www.w3.org/2000/svg">
										<path d="M23 11.5C23 17.8513 17.8513 23 11.5 23C5.14871 23 0 17.8513 0 11.5C0 5.14871 5.14871 0 11.5 0C17.8513 0 23 5.14871 23 11.5ZM10.1698 17.5892L18.7021 9.0569C18.9918 8.76717 18.9918 8.29739 18.7021 8.00766L17.6528 6.95843C17.3631 6.66866 16.8933 6.66866 16.6035 6.95843L9.64516 13.9168L6.39646 10.6681C6.10673 10.3783 5.63695 10.3783 5.34718 10.6681L4.29794 11.7173C4.00821 12.007 4.00821 12.4768 4.29794 12.7665L9.12052 17.5891C9.41029 17.8789 9.88003 17.8789 10.1698 17.5892Z" fill="#ADADAD"/>
										</svg></span>Duurzaam verpakt</li>
										<li><span><svg width="23" height="23" viewBox="0 0 23 23" fill="none" xmlns="http://www.w3.org/2000/svg">
										<path d="M23 11.5C23 17.8513 17.8513 23 11.5 23C5.14871 23 0 17.8513 0 11.5C0 5.14871 5.14871 0 11.5 0C17.8513 0 23 5.14871 23 11.5ZM10.1698 17.5892L18.7021 9.0569C18.9918 8.76717 18.9918 8.29739 18.7021 8.00766L17.6528 6.95843C17.3631 6.66866 16.8933 6.66866 16.6035 6.95843L9.64516 13.9168L6.39646 10.6681C6.10673 10.3783 5.63695 10.3783 5.34718 10.6681L4.29794 11.7173C4.00821 12.007 4.00821 12.4768 4.29794 12.7665L9.12052 17.5891C9.41029 17.8789 9.88003 17.8789 10.1698 17.5892Z" fill="#ADADAD"/>
										</svg></span>Duurzaam verpakt</li>
									</ul>
								</div>
							</div>

							<div class="form-setp step_2" style="display: none;">
								
								<div class="setp-content-container">

									<div class="cat-filter-container c-c txt-center "><?php 

										?><div class="cat-filter p button hs-toogle-group" data-group='.mixture-cat' data-show='.mixture-cat-all' >
												<span class="c-c c-s10"><?= $this->__('All') ?></span>
										</div><?php

										foreach ($category as $d) {
											?><div class="cat-filter p button hs-toogle-group" data-group='.mixture-cat' data-show='.mixture-cat-<?= $d->term_id ?>' >
												<span class="c-c c-s10"><?= $d->name ?></span>
											</div><?php
										}	
									?></div>
									<div class="mixture-cat-wraper"><?php 
										foreach ($category as $d) {
											?><div class="mixture-cat mixture-cat-all mixture-cat-<?= $d->term_id ?>">
												
												<div class="cat-header">
													<strong><?= $d->name ?></strong>
													<span><?= $d->description;  ?></span>
												</div>
												<div class="c-c c-s10 c-t33 c-w25 c-l20 mixture-container"><?php 

													$mixtures = get_posts([
															'post_type'	=>'cx_cpo_mixture',
															'tax_query'	=> [
																[
																	'taxonomy'=> 'cx_cpo_category',
																	'terms'=> [$d->term_id],
																	'operator' => 'IN',
																],
															],
														]);
													foreach ($mixtures as $s ) {



														$attrs = \cx_cpo\posttype\mixture::get_attributes_value($s->ID);

														$thumb = get_the_post_thumbnail_url($s->ID);

														?><div class="mixture-wraper">
															<div class="mixture-item-container txt-center">
																<input 
																	type="checkbox"
																	name="cx_options[mixture][]"
																	value="<?= $s->ID ?>"
																	id="mixture-<?= $d->term_id ?>-<?= $s->ID ?>" 
																	data-weightage='' 
																	data-price='' 
																	class="hide cx-input-mixture" />
																<div class="checkboxxwt">
<svg width="22" height="22" viewBox="0 0 22 22" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M19.5556 0H2.44444C1.09389 0 0 1.09389 0 2.44444V19.5556C0 20.9061 1.09389 22 2.44444 22H19.5556C20.9061 22 22 20.9061 22 19.5556V2.44444C22 1.09389 20.9061 0 19.5556 0ZM8.55556 17.1111L2.44444 11L4.17389 9.27056L8.55556 13.6522L17.8261 4.38167L19.5556 6.11111L8.55556 17.1111Z" fill="#4EBAA9"/>
</svg>
																	
																	
																</div>	
																<label class="txt-center s10 mixture-label mixture-<?= $s->ID ?>" for="mixture-<?= $d->term_id ?>-<?= $s->ID ?>"><?php 

																	if ( $thumb )  {
																		?><img class="c s10" src="<?= $thumb ?>"/><?php 	
																	}
																	?><span class="title"><?= $s->post_title ?></span><?php 
																	
																	?><span class="weightage"></span><?php 

																	?><span class=" c s10 additional-price"></span><?php 
																?></label>
																
															</div>

														</div><?php
													}
												?></div>
											</div><?php 
										}

									?></div>
									
								</div>
							</div>	
						</div>
						
					</div><?php 

					?><div class="cx-cpo-sidebar-cart s10 t3 w25 xwt-s-hide">

						<div class="cpo-sidebar-inner-container">
							<div class="main-price-box c-c c-s10 txt-center">

								<span class="total-price"></span>
								<span class="default-msg" > <?= $this->__("Choose a package"); ?></span>
								

								<span class="size-info"></span>


								<span class="total-price-txt"><?= $this->__("Total Price") ?></span>

								<span class="pkg-img"></span>
							</div>

							<div class="include-box-msg">Included</div>

							<div class="include-box"></div>
							
						</div>
						

						<div class="btn-container">
						<div class="before-btn-text">Dat ziet er lekker uit!</div>	

							<button type="submit" class="button cx-cpo-from-submit s10">
							<svg width="21" height="18" viewBox="0 0 21 18" fill="none" xmlns="http://www.w3.org/2000/svg">
							<path d="M15.373 6.6196L11.2192 0.403056C11.039 0.128029 10.7355 0 10.432 0C10.1286 0 9.82508 0.132771 9.64489 0.403056L5.49104 6.6196H0.948367C0.426765 6.6196 0 7.04636 0 7.56797C0 7.65806 0.0142255 7.74341 0.0331928 7.82403L2.4373 16.6154C2.66017 17.412 3.39515 18 4.26765 18H16.5964C17.4689 18 18.2039 17.412 18.422 16.6106L20.8261 7.81928C20.8498 7.74341 20.8641 7.65806 20.8641 7.56797C20.8641 7.04636 20.4373 6.6196 19.9157 6.6196H15.373ZM7.58693 6.6196L10.432 2.44679L13.2771 6.6196H7.58693ZM10.432 14.2065C9.38409 14.2065 8.5353 13.3577 8.5353 12.3098C8.5353 11.2619 9.38409 10.4131 10.432 10.4131C11.48 10.4131 12.3288 11.2619 12.3288 12.3098C12.3288 13.3577 11.48 14.2065 10.432 14.2065Z" fill="#F9F9F9"/>
							</svg>
							<span><?= $this->__('In de winkelwagen') ?></span>		
							</button>	
						</div>
						
					</div>



					<div class="cx-cpo-sidebar-cart mobile-cart s10 t3 w25 xwt-l-hide">

						<div class="cpo-sidebar-inner-container">
							<div class="main-price-box c-c c-s10">
								<span class="size-info"></span>
								<div class="btn-container">
									<button type="submit" class="button cx-cpo-from-submit s10">
									<svg width="21" height="18" viewBox="0 0 21 18" fill="none" xmlns="http://www.w3.org/2000/svg">
									<path d="M15.373 6.6196L11.2192 0.403056C11.039 0.128029 10.7355 0 10.432 0C10.1286 0 9.82508 0.132771 9.64489 0.403056L5.49104 6.6196H0.948367C0.426765 6.6196 0 7.04636 0 7.56797C0 7.65806 0.0142255 7.74341 0.0331928 7.82403L2.4373 16.6154C2.66017 17.412 3.39515 18 4.26765 18H16.5964C17.4689 18 18.2039 17.412 18.422 16.6106L20.8261 7.81928C20.8498 7.74341 20.8641 7.65806 20.8641 7.56797C20.8641 7.04636 20.4373 6.6196 19.9157 6.6196H15.373ZM7.58693 6.6196L10.432 2.44679L13.2771 6.6196H7.58693ZM10.432 14.2065C9.38409 14.2065 8.5353 13.3577 8.5353 12.3098C8.5353 11.2619 9.38409 10.4131 10.432 10.4131C11.48 10.4131 12.3288 11.2619 12.3288 12.3098C12.3288 13.3577 11.48 14.2065 10.432 14.2065Z" fill="#F9F9F9"/>
									</svg>
									<span class="total-price"></span>	
									</button>	
								</div>

								<span class="total-price"></span>
								<span class="default-msg" > <?= $this->__("Choose a package"); ?></span>
								

								


								<span class="total-price-txt"><?= $this->__("Total Price") ?></span>

								<span class="pkg-img"></span>
							</div>

							<div class="include-box-msg">Included</div>

							<div class="include-box"></div>
							
						</div>

						
						
						
					</div>


				</div>
				
			</div><?php

			
		}
		public function _add_item_to_cart($p) {

			

			global $woocommerce, $wp_session;

			$product_id = $this->plugin_option(['general','page','order_product']);
			$woocommerce->cart->add_to_cart( $product_id , 1 , 0, [], [
				"cx_cpo_options" => $p['cx_options'] 
			]);

			wp_redirect( wc_get_cart_url() );
			exit();
		}
	}
}
