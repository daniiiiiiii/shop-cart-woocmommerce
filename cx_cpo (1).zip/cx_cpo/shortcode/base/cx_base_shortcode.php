<?php 

namespace cx_cpo;

if ( !class_exists("\\cx_cpo\\cx_base_shortcode")) {
	
	class cx_base_shortcode extends cx_base {

		protected $default_attributes = [];
		protected $current_attrs = [];
		protected $attribute = [];

		protected $shortcode;

		public function __construct() {

			$sc = get_called_class();
			$sc = implode("_", explode("\\", $sc));
			$sc =  str_replace("_shortcode", "", $sc );
			$this->shortcode = $sc;
			parent::__construct();
		}

		public function do_shortcode($attrs = []) {

			if ( !is_array($attrs)) $attrs = [];
			$this->current_attrs  = $attrs;
			foreach ($this->default_attributes as $key => $value) {
				$attrs[$key] = ( !isset($attrs[$key]) ) ? $value : $default_attributes[$key];
			}
			$this->attribute = $attrs;

			
			$_shortcode_key = $this->get_shortcode_key();
			$_shortcode_key = explode("_", $_shortcode_key);
			$_shortcode_key = array_splice($_shortcode_key, 2);
			$_shortcode_key = implode("_", $_shortcode_key);

			$js_file = "/asset/shortcode/".$_shortcode_key."/index.js";
		    $css_file = "/asset/shortcode/".$_shortcode_key."/index.css";

		    
		    if ( file_exists($this->get_plugin_path() . $js_file )) {
		    	wp_enqueue_script($_shortcode_key , $this->get_plugin_uri() . $js_file );	
		    }
		    if ( file_exists($this->get_plugin_path() . $css_file )) {
		    	wp_enqueue_style($_shortcode_key , $this->get_plugin_uri() . $css_file );	
		    }


			ob_start();

			do_action(get_called_class(). "_before" , $attrs);
			$this->render($attrs);
			do_action(get_called_class(). "_after" , $attrs);

			return ob_get_clean();

		}

		public function register() {

			add_shortcode( $this->shortcode , [$this,"do_shortcode"] );
		}

		public function get_shortcode_key() {

			$_shortcode_key         =  explode("\\", get_called_class() );
        	$_shortcode_key         =  $_shortcode_key[0] . "_" . implode("_", array_splice( $_shortcode_key , 2) );
        	return $_shortcode_key;	
		}
	}


}
