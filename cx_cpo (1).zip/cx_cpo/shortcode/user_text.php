<?php 

namespace cx_cpo\shortcode;

include(realpath(__DIR__ . "/base/cx_base_shortcode.php") ); 

if( !class_exists("\\cx_cpo\\shortcode\\user_text") ){

	class user_text extends \cx_cpo\cx_base_shortcode {
		
		protected $attributes = [
			"wraper_class" 		=> "",
			"not_login_text"	=>"Login",
			"login_text"		=>"Welcome {{display_name}} ",
			"user"				=>"user",
		];

		public function render($attrs = []) {

			extract($attrs);
			
			?><div class="xwt cx_shortcode <?= $this->get_shortcode_key() ?> <?= $wraper_class ?>"><?php 

				$user_m = $this->model( $user );

				if ( $user_m && $user_m->is_user_login() ) {

					$user_info = $user_m->get_user_session_data();
					$id = $user_info["id"];
					
					$data = get_user_by( "id", $id );
					$data = json_decode(json_encode($data),1);
					$data = $data["data"];

					echo cx_string_parser($login_text , $data);

				} else {

					echo $not_login_text;				
					
				}

			?></div><?php 
		}
	}
}
