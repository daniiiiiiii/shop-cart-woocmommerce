<?php 

namespace cx_cpo\shortcode;

include(realpath(__DIR__ . "/base/cx_base_shortcode.php") ); 

if( !class_exists("\\cx_cpo\\shortcode\\user_btn") ){

	
	class user_btn extends \cx_cpo\cx_base_shortcode {
		
		protected $attributes = [
			"wraper_class" => "",
			"not_login_text"=>"Login",
			"show_login_btn"=>"true",
			"user"=>"user",
			"login_page_key"=>"general.subscriber.dashboard",
			"submenu"	=>"true",
		];

		public function render($attrs = []) {

			// default prams
			extract($attrs);

			?><div class="xwt cx_shortcode <?= $this->get_shortcode_key() ?> <?= $wraper_class ?>"><?php 

				$user_m = $this->model( $user );
				
				$page_link = $this->plugin_option(explode(".", $login_page_key) );
				$page_link = get_permalink( $page_link );

			

				if ( $user_m && $user_m->is_user_login() ) {

					$user_info = $user_m->get_user_session_data();
					$user_contaoller = $this->controller($user);
					$r = $user_contaoller->get_routes();


					?><ul class="user-login xwt-user-login-menu" data-user_type="<?= $user ?>" data-user="<?= $user_info["id"] ?>">
						<li class="main-li">
							<a href="<?= $page_link ?>" class='user-dashboard-link'><?= $user_info["name"] ?></a><?php 

							if ( $submenu == "true") {
								?><div class="sub-menu-container"><ul class="sub-menu user-login-submenu"><?php 

									foreach ($r as $key => $item ) {
										if ( isset($item["show_in_nav"]) && $item["show_in_nav"] ) {
											?><li class="page-<?= $key ?>">
												<a href="<?= $page_link ?>?p=<?= $item["handler"] ?>"><?= __( $item["nav_label"] ,"xwt")  ?></a>
											</li><?php 
										}
									}
								?></ul></div><?php 
							
							}

						?></li>
						
					</ul><?php

				} else {

					if ( $show_login_btn == "true" ) {
						?><a class="xwt-user-login-btn login-btn" href="<?= $page_link ?>" data-user_type="<?= $user ?>" ><?= __($not_login_text,"xwt") ?></a><?php
					}
					
				}


			?></div><?php 
		}

	}
	
}
