<?php 

namespace cx_cpo\posttype;

include_once(realpath(__DIR__ . "/base/cx_base_posttype.php") ); 

if ( !class_exists("\cx_cpo\posttype\size") ) {

    class size extends \cx_cpo\cx_base_posttype {

   

        protected $post_name_display ="size";


     
        protected $taxonomies = [];

        protected function post_attributes() {
            $atts =  [

                "cx_cpo_size_weightage"=> [
                    "label"=>"gram",
                    'type'  => 'number',
                    "admin_edit_meta_box"     =>"info",
                    "attributes"=> [
                        "id"=> "cx_cpo_size_weightage",
                    ],
                ],
                "cx_cpo_size_price"=> [
                    "label"=>"price",
                    'type'  => 'number',
                    "admin_edit_meta_box"     =>"info",
                    "attributes"=> [
                        "id"=> "cx_cpo_size_price",
                    ],
                ],
                

            ];
            
            return $atts;

        }
        function __construct(){
          
            parent::__construct();
        }

       

        public function setup_front_styles_scripts() {
            //wp_enqueue_style( "jquery.fancybox-style", $this->_plugin_uri . "/assets/third-party/jquery.fancybox-1.3.4.css" );
            //wp_enqueue_script( "jquery.fancybox-script", $this->_plugin_uri . "/assets/third-party/jquery.fancybox-1.3.4.pack.js" );
        }
        protected $supports= [
            'title', 
            //'editor',
            'thumbnail',
            //'comments',
            //'excerpt',
            // 'revisions',
            //'custom-fields'
        ];

        /*
            if assigned then deadline can not be changed

            enduser msg
                - send proposal
                - request exttend deadline
                - send initial version request
                - send complete request
            
            admin buttons
                - assign project
                - un-assign project ( reset publish date, change status to publish )
                - request revision
                - complete project
        */
        protected $posthandler = [
            

        ];

     
        protected function set_up_styles_scripts() {
            

        }

     


    }
}




