<?php 

namespace cx_cpo\posttype;

include_once(realpath(__DIR__ . "/base/cx_base_posttype.php") ); 

if ( !class_exists("\cx_cpo\posttype\mixture") ) {

    class mixture extends \cx_cpo\cx_base_posttype {

   

        protected $post_name_display ="mixture";


     
        protected $taxonomies = [];

        protected function post_attributes() {

            $atts =  [

                "cx_cpo_mixture_weightage"=> [
                    "label"=>"gram",
                    'type'  => 'number',
                    "admin_edit_meta_box"     =>"default",
                    "attributes"=> [
                        "id"=> "cx_cpo_mixture_weightage",
                    ],
                ],
                "cx_cpo_mixture_price"=> [
                    "label"=>"price",
                    'type'  => 'number',
                    "admin_edit_meta_box"     =>"default",
                    "attributes"=> [
                        "id"=> "cx_cpo_mixture_price",
                    ],
                ],
                

            ];
            foreach (\get_posts_as_options('cx_cpo_size') as $id => $s) {
                
                $t = sanitize_title( $s );
                $t = explode("-", $t);
                $t = implode(" ", $t);

                $atts["cx_cpo_mixture_weightage_" . $id] = [
                    "label"=>$s . " weightage",
                    'type'  => 'number',

                    "admin_edit_meta_box"     =>$t,
                    "attributes"=> [
                        "id"=> "cx_cpo_mixture_weightage_" . $id,
                    ],
                ];

                $atts["cx_cpo_mixture_price_" . $id] = [
                    "label"=>$s . " price",
                    'type'  => 'number',
                    "default"=>0,
                    "admin_edit_meta_box"     =>$t,
                    "attributes"=> [
                        "id"=> "cx_cpo_mixture_price_" . $id,
                    ],
                ];
               

            }
            
            return $atts;
        }
        function __construct(){
          
            parent::__construct();
        }

       

        public function setup_front_styles_scripts() {
            //wp_enqueue_style( "jquery.fancybox-style", $this->_plugin_uri . "/assets/third-party/jquery.fancybox-1.3.4.css" );
            //wp_enqueue_script( "jquery.fancybox-script", $this->_plugin_uri . "/assets/third-party/jquery.fancybox-1.3.4.pack.js" );
        }
        protected $supports= [
            'title', 
            //'editor',
            'thumbnail',
            //'comments',
            //'excerpt',
            // 'revisions',
            //'custom-fields'
        ];

        /*
            if assigned then deadline can not be changed

            enduser msg
                - send proposal
                - request exttend deadline
                - send initial version request
                - send complete request
            
            admin buttons
                - assign project
                - un-assign project ( reset publish date, change status to publish )
                - request revision
                - complete project
        */
        protected $posthandler = [
            

        ];

     
        protected function set_up_styles_scripts() {
            

        }

     


    }
}




