<?php 

namespace cx_cpo;

if (!class_exists("\\cx_cpo\\cx_base_posttype")) {


	class cx_base_posttype extends cx_base {

		// required
		protected $post_attribute_list = [];
		protected $posthandler = [];
		/*
		protected $posthandler = [

	        "cx_form_type" => [ // key in from 

	            "cx_freelancerprojects_freelancer_signup"=> [ 	// value in form
	            	"pathtofile", 		// path to file
	            	"class_name",		// model class name
	            	"function_name"  	// public function
	            ],

	        ]
	    ];
		*/

		// optional

		protected $post_name_display ="";
		protected $post_labels = [];
		protected $supports = [];
		protected $post_register_attrs = [];
		protected $form_post_wraper = "";


		protected $posttype_name = "";

		// private defaults
		
		private $post_labels_default = [];
		private $post_labels_list = [
			'name',
			'singular_name',
			'add_new',
			'add_new_item',
			'edit',
			'edit_item',
			'new_item',
			'view',
			'view_item',
			'search_items',
			'not_found',
			'not_found_in_trash',
			'parent',
		];


		
		private $supports_default = [ 
			'title', 
			'editor',
			'author',
			'thumbnail',
			'excerpt',
			'trackbacks',
			'comments',
			'revisions',
			'custom-fields'
		];
		private $default_post_register_attrs= [
			'public' => true,
	        'menu_position' => 15,
	        'taxonomies' => array( ),
	        'menu_icon' => "",
	        'has_archive' => true,
	        'status' => "public",

		];
		protected $taxonomies = [];
		 
		function __construct(){

			parent::__construct();

			$this->post_attribute_list = $this->post_attributes();


			// setting up posttype_name
			$called_class = get_called_class();
			$called_class_expd  = explode("\\", $called_class);
			$actual_name_last = $called_class_expd[ count($called_class_expd) - 1];
			$this->class_last_name = $actual_name_last;

			
			
			$actual_name = $this->get_plugin_namespace() . "_" . $actual_name_last;
			
			if ( strlen($actual_name) > 20 ) {
				$actual_name = explode("_", $actual_name);
				$actual_name = $actual_name[0] . "_" . $actual_name[2];
			}
			if ( strlen($actual_name) > 20 ) {
				$actual_name = explode("_", $actual_name);
				$actual_name = $actual_name[1];
			}
			if ( strlen($actual_name) > 20 ) {
				$actual_name = substr($actual_name, 0, 20);
				
			}



			$this->class_actual_name = $actual_name_last;

			if ( !strlen($this->posttype_name) ){
				$this->posttype_name = $actual_name;
			}
			if ( !strlen($this->post_name_display) ) {
				$this->post_name_display = implode(" ", explode("_", $actual_name) ) ;

			}
			/*
				setting up labels
			*/
			$posttype_name = $this->post_name_display;
			
			
			$this->post_labels_default = [
				'name' 					=> sprintf( __( '%s', 'cx' ), $posttype_name ), 
	            'singular_name' 		=> sprintf( __( '%s', 'cx' ), $posttype_name ), 
	            'add_new' 				=> sprintf( __( 'Add New  %s', 'cx' ), $posttype_name ), 
	            'add_new_item' 			=> sprintf( __( 'Add New  %s', 'cx' ), $posttype_name ), 
	            'edit' 					=> sprintf( __( 'Edit', 'cx' ), $posttype_name ), 
	            'edit_item' 			=> sprintf( __( 'Edit %s', 'cx' ), $posttype_name ), 
	            'new_item' 				=> sprintf( __( 'New %s', 'cx' ), $posttype_name ),
	            'view' 					=> sprintf( __( 'View', 'cx' ), $posttype_name ),
	            'view_item' 			=> sprintf( __( 'View %s', 'cx' ), $posttype_name ),
	            'search_items' 			=> sprintf( __( 'Search %s', 'cx' ), $posttype_name ),
	            'not_found' 			=> sprintf( __( 'No %s found', 'cx' ), $posttype_name ),
	            'not_found_in_trash' 	=> sprintf( __( 'No %s found in Trash', 'cx' ), $posttype_name ),
	            'parent' 				=> sprintf( __( 'Parent %s', 'cx' ), $posttype_name ),
			];

			foreach ($this->post_labels_list as $label) {
				if ( !isset($this->post_labels[$label]) ) {
					$this->post_labels[$label] = $this->post_labels_default[$label];
				}
			}
			
			// support default
			if ( !count($this->supports )) {
				$this->supports = $this->supports_default;
			}

			foreach ($this->default_post_register_attrs as $key => $value) {
				if ( !isset($this->post_register_attrs[$key]) ) {
					$this->post_register_attrs[$key] = $value;
				}
			}
			

			
			if ( !strlen($this->form_post_wraper) ) {
				$this->form_post_wraper = "";
			}


			add_action( 'manage_'.$this->posttype_name.'_posts_custom_column', [$this,"custom_column_content"],10,3);
			
			add_filter( 'manage_edit-'.$this->posttype_name.'_columns', [$this,"custom_column_header"], 10, 2);
			add_filter( 'manage_edit-'.$this->posttype_name.'_sortable_columns',  [$this,"custom_sortable_header"] );
			add_filter( 'pre_get_posts',  [$this,"sortable_header_query"] );
			add_filter( 'posts_orderby',  [$this,"sortable_custom_orderby"] , 10, 2 );


			add_action( 'init', [$this,"register_posttype"]);
			add_action( 'admin_init', [$this,"register_posttype_metaboxes"]);
			add_action( 'save_post', [$this,"save_posttype_attrs"], 10, 2 );
			add_action( 'admin_notices', array( $this, '_admin_notices' ) );

			//$this->initilize_post_attributes();
			add_action( 'wp_loaded', [ $this, 'initilize_post_attributes' ] );


			
			// adding actions and filter
			$this->set_up_actions();
			$this->set_up_filters();
			$this->set_up_shortcodes();

			
			$this->set_up_styles_scripts_base();

			$this->set_up_post_handlers();
			// foreach(glob(__DIR__  . "/../". get_called_class().  "/controllers/*.php") as $file){
    
			//     require_once($file);
			    
			// }


			add_filter( 'template_include',[$this,"_template_include"] );

			


			
		}

		// resetting the post attibutes after wp complete loaded so all the function will be avaiable
		public function initilize_post_attributes () {

			$class = $this->class_last_name;
			$this->post_attribute_list = apply_filters("cx_posttype_".$class."_attributes", $this->post_attributes() );
			
			$default_attr_attr = [
				"show_in_admin_gird"	=>0,
		        "show_in_admin_edit"	=>1,
		        "admin_edit_meta_box"  	=> $this->posttype_name . " Options",
			];
			
			// add defualt vals to attrs
			foreach ($this->post_attribute_list as $key => $attr) {
				foreach ($default_attr_attr as $attr_key => $default_value) {
					if ( !isset($attr[$attr_key]) ){
						$this->post_attribute_list[$key][$attr_key] = $default_value;
					}
				}
			}

			//var_dump($this->post_attribute_list);


		}
		protected function post_save_notices() {

		}
		public function _admin_notices() {
			$msg = cx_get_session_msg_html();
			echo $msg;
			$this->post_save_notices();

		}
		public function setup_front_styles_scripts() {
			
		}
		public function _template_include( $template_path ) {

		    global $_plugin_uri;
		    global $post;


		   	
		    $condition_my_pages = 0;

		    if ( get_post_type() == $this->posttype_name ) {

		      	$this->setup_front_styles_scripts();
		 
		        if ( is_single() ) {

		            if ( $theme_file = locate_template( array ( 'single-'.$this->posttype_name.'.php' ) ) ) {
		                $template_path = $theme_file;
		            } else {

		            	
		                $path = $this->_plugin_path . 'template/posttype/'.$this->posttype_name.'/single-'.$this->posttype_name.'.php';

		                if ( file_exists($path)) {
		                	$template_path = $path;
		                }
		            }
		        }

		        if ( is_archive() ) {

		            if ( $theme_file = locate_template( array ( 'archive-'.$this->posttype_name.'.php' ) ) ) {

		                $template_path = $theme_file;

		            } else {

		            	$path = $this->_plugin_path . 'template/posttype/'.$this->posttype_name.'/archive-'.$this->posttype_name.'.php';
		            	
		            	if ( file_exists($path)) {
		                	$template_path = $path;
		                }


		                
		            
		            }
		        }
		      

		    }
		    
		    return $template_path;
		}

		public function insert_post_data($data , $postarr){
			return $data;
		}
		public function _insert_post_data($data =[], $postarr =[]){
			if( $data[ 'post_type' ] === $this->posttype_name ) {
				$updated = $this->insert_post_data($data , $postarr);
				return ($updated) ?  $updated : $data;
			}
		}
		private function set_up_filters(){
			// $path = realpath(__DIR__ . "/../". get_called_class() ."/" );
			
			// foreach(glob($path. "/filters/*.php") as $file){
	    		
	    
			//   	require_once $file;
			//     $function_name = basename($file,".php");
			//     $action_name = "";

			//     $f_arr =  explode("_",$function_name);
			//     $f_arr = array_slice($f_arr, 4);
			//     $filter_name = implode("_", $f_arr);
			    
			//     // add the action 
			// 	add_filter( $filter_name ,  $function_name );
			// }
		}
		public static function get_attributes(){
			$self = new static;
			return $self->post_attribute_list;
		}
		public static function get_attributes_value($post_id, $prefix = "", $remove_prefix = 1) {

			$data = static::get_attributes_raw_value($post_id, $prefix = "", $remove_prefix = 1);
			if ( method_exists(get_called_class(), "attributes_values_adaptor") )	{
				$data = static::attributes_values_adaptor($data);
			}
			$data = apply_filters( "posttype_" . get_post_type($post_id) . "_attributes_value" , $data);

			return $data;
		}
		public static function get_attributes_raw_value($post_id, $prefix = "", $remove_prefix = 1){

			$self = new static;
			$attrs =  $self->post_attribute_list;
			

			if ( !strlen($prefix) ) {
				$prefix = array_keys($attrs)[0];
				$prefix = explode("_", $prefix);
				$prefix = array_slice($prefix, 0,3);
				$prefix = implode("_", $prefix) . "_";
			}
			
			$return = [];
			foreach ($attrs as $key => $value) {
				$elem_key =  $key;
				if ( $remove_prefix ) {
					$elem_key = str_replace($prefix, "", $key);
				}
				$elemes = get_post_meta( $post_id, $key );
				if ( count($elemes) >1 ) {
					$return[$elem_key] = $elemes;
				} else {
					$return[$elem_key] = $elemes[0];
				}
				
			}

			
			return $return;
		}
		// public static function get_posthandels(){
		// 	$self = new static;
		// 	return $self->posthandler;
		// }
		private function set_up_actions(){
			// $path = realpath(__DIR__ . "/../". get_called_class() ."/" );
			// // actions
			// foreach(glob($path . "/actions/*.php") as $file){
			    
			//     require_once $file;
			//     $function_name = basename($file,".php");
			//     $action_name = "";

			//     $f_arr =  explode("_",$function_name);
			//     $f_arr = array_slice($f_arr, 4);
			//     $action_name = implode("_", $f_arr);

			//     // add the action 
			// 	add_action( $action_name ,  $function_name );
			  
			// }
		}
		private function set_up_shortcodes() {
			// $path = realpath(__DIR__ . "/". get_called_class() ."/" );
			// foreach(glob($path. "/shortcodes/*.php") as $file){
    
			//     require $file;
			//     $filename = basename($file);
			//     $code = substr( $filename, 0,strlen($filename) - 4 );
			//     $function_name = $code. "_function"; 
			//     if (  function_exists($function_name)) {
			//     	add_shortcode( $code, $function_name );
			//     }
			    
			    
			// }

		}
		protected function after_register(){}
		public function register_posttype() {

			$attrs = $this->post_register_attrs;
			$attrs["labels"] = $this->post_labels;
			$attrs["supports"] = $this->supports;
			$attrs["taxonomies"] = $this->taxonomies;

			
			// var_dump($this->posttype_name,$attrs);

			\register_post_type($this->posttype_name,$attrs);

			$this->after_register();


		}

		public function register_posttype_metaboxes(){
			$this->posttype_before_metaboxes();
			$this->posttype_additional_metaboxes();

			
			$meta_box_list = [];
			foreach ($this->post_attribute_list as $key => $value) {
				if ( $value["show_in_admin_edit"] && isset($value["admin_edit_meta_box"]) ) {
					if ( !in_array($value["admin_edit_meta_box"], $meta_box_list )) {
						$meta_box_list[] = $value["admin_edit_meta_box"];
					}
				}
			}
			

			foreach ($meta_box_list as $meta_box_name) {

				$box_id = implode("_", explode("\\", get_called_class()) )  . "__" . sanitize_title($meta_box_name);
				add_meta_box( 
					$box_id ,
			        $meta_box_name,
			        [$this,'render_meta_box'],
			        $this->posttype_name, 
			        'normal', 'high'
			    );
			}
			$this->posttype_after_metaboxes();
		}
		
		protected function set_up_post_handlers() {
			cx_add_global_posthandels($this->posthandler);
 		}
 		public function get_meta_box_class($class){
 			return $class;
 		}
 		public function _get_meta_box_class(){

 			global $post;
 			if ( !$post->ID ) {
 				return "";
 			}
 			$class = [];
 			$attrs = $this->get_attributes();
 			foreach ($attrs as $key => $info) {
 				if(  isset($info["add_in_metabox_class"]) && $info["add_in_metabox_class"] ){
 					$_class= get_post_meta($post->ID,$key,1);
 					$_class= sanitize_title($_class);
 					$_class=$key ."--".$_class;
 					$class[] = $_class;

 				}
 			}
 			$new_classes=$this->get_meta_box_class($class);
 			$return_classes =  ( $new_classes ) ? $new_classes : $new_classes;
 			$class_str = "";
 			foreach ($return_classes as $value) {
 				$class_str .= " $value ";

 			}
 			return $class_str;
 			
 		}
 		
 		protected function before_meta_box_render($args) {

 		}
 		protected function after_meta_box_render() {

 		}

		public function render_meta_box($p,$args){

			wp_enqueue_media();
			
			$this->before_meta_box_render($args);

			$this->render_additional_meta_box($p,$args);

			$metabox = explode("__", $args["id"]);
			$metabox = $metabox[ count($metabox) - 1];
			$metabox = implode(" ", explode("-", $metabox));
			
			$attrs_to_render = [];
			foreach ($this->post_attribute_list as $key => $value) {
				
				if ( $metabox == $value["admin_edit_meta_box"] ) {
					$attrs_to_render[$key] = $value;
				}
			}
			$meta_box_callback = implode("_", explode(" ", $metabox));
			$meta_box_callback = "meta_box_" . $meta_box_callback;

			if ( method_exists($this,$meta_box_callback . "_before")) {
				$fun = $meta_box_callback. "_before";
				$this->$fun($p,$args,$attrs_to_render);
			}
			
			
			$h = $this->helper("render");


			$classes = $this->_get_meta_box_class();
			?><div class="hs-metabox-feilds-container <?php echo $classes; ?>"><?php
				foreach ($attrs_to_render as $key => $e) {

					if ( $e["show_in_admin_edit"] ) {
						$key_post = $this->posttype_name . "[" .$key .  "]";

						$val = null;
						if ($p->ID) {
							$val = get_post_meta( $p->ID , $key );
							if ( count($val) == 1) $val = $val[0];
						}
						$method_name =  "before_populate_" . $key;
						if ( method_exists($this, $method_name) ) {
							$return = $this->$method_name($val ,$e);
							if ( isset($return) ) {
								
								$val = isset($return["value"] ) ? $return["value"] : $val;
								$e = isset($return["options"] ) ? $return["options"] : $e;

							}
						}
						$h->render_form_field($key_post, $val ,$e);
					}
					
				}
			?></div><?php

			if ( method_exists($this,$meta_box_callback . "_after")) {
				$fun = $meta_box_callback. "_after";
				$this->$fun($p,$args,$attrs_to_render);
			}
			$this->after_meta_box_render();

		}
		public function save_posttype_attrs($pid, $p) {
			
			if ( $p->post_type == $this->posttype_name ) {

		        if ( !$pid ) return;

		    	$postdata = $_POST[$this->posttype_name];
		    	$this->before_save_additional_posttype_attrs($pid, $p, $postdata);
		    	
		    	if ( isset($postdata)) {
		    		foreach ($this->post_attribute_list as $key => $info) {
			            if ( isset( $postdata[$key]) ) {

			            	if ( is_array($postdata[$key]) && isset($info['save_in_multiple_record']) && $info['save_in_multiple_record'] == 1) {

			            		delete_post_meta($pid, $key);
			            		foreach ($postdata[$key] as $post_val ) {
			            			add_post_meta( $pid, $key, $post_val );		
			            		}
			            	} else {
			            		update_post_meta( $pid, $key, $postdata[$key] );	
			            	}
			                
			            }
			        } 
		    	}  
		    	$this->save_additional_posttype_attrs($pid, $p, $postdata);
	    	}
	    	

	    	

		}
		public function custom_column_content($column_name) {
			
			global $post;
			$this->custom_column_additional_content($column_name);

			foreach ($this->post_attribute_list as $key => $opt) {
	            if ( isset($opt["show_in_admin_gird"]) && $opt["show_in_admin_gird"] && $column_name ==$key ) {
	                
	                $value = get_post_meta( $post->ID ,$key ,1);

	                $method_name = "render_gird_column_" . $key;
	                $class_value = $value;
	                if ( is_array($class_value)) {
	                	$class_value = implode("-", $class_value);
	                }
	                ?><div data-method="<?= $method_name ?>" class="
	                	wp-grid-col-val 
	                	grid-col-<?php echo $column_name; ?> 
	                	col-val-<?php echo sanitize_title($class_value); ?>" 
	                	data-colval="<?php echo $value ?>"><?php

		                if ( method_exists($this,$method_name) ) {
		                	echo apply_filters($method_name,$this->$method_name($value,$post ));
		                } else {
		                	echo apply_filters($method_name,$value);
		                }
		            ?></div><?php
	               	return 0;
	            }
	        }

		}
		public function custom_column_header($cat_columns) {
			

			foreach ($this->post_attribute_list as $key => $opt) {
	            if ( isset($opt["show_in_admin_gird"]) && $opt["show_in_admin_gird"] ) {
	            	$label= $opt["label"];
	            	if ( $opt["admin_gird_label"] ) {
	            		$label= $opt["admin_gird_label"];
	            	}
	                $cat_columns[$key] = $label;
	            }
	        }
	       

	        $col_edit = $this->custom_column_additional_header($cat_columns);
	        
	        if( $col_edit ){
	        	return $col_edit;
	        } else {
	        	return $cat_columns;
	        }
		}
		public function custom_sortable_header( $sortable_columns ) {
			foreach ($this->post_attribute_list as $key => $opt) {
				if ( isset($opt["show_in_admin_gird"]) && $opt["show_in_admin_gird"] ) { 
					if ( isset($opt["admin_gird_sortable"]) && $opt["admin_gird_sortable"] ) { 
						$sortable_columns[$key] = $key;
					}
				}
			}

			return $sortable_columns;
		}
		public function sortable_header_query( $query ) {
			
			if ( !is_admin()) return $query;
			if ( !is_archive( $this->posttype_name )) return $query;
			if ( !is_post_type_archive( $this->posttype_name )) return $orderby;
			if ( !$query->is_main_query()) return $query;

			$orderby = $query->get( 'orderby' );
			if ( isset($this->post_attribute_list[$orderby])) {

				$opt = $this->post_attribute_list[$orderby];
				
				$query->set( 'meta_key', $orderby );
				$query->set( 'orderby', 'meta_value' );
				if ( isset($opt['admin_gird_sortable_type'] )) {
					$query->set( 'meta_type' , $opt['admin_gird_sortable_type'] );   	
				}
				
			}
			return $query;
		}
		public function sortable_custom_orderby($orderby, $query) {
			
			if ( !is_admin()) return $orderby;
			if ( !is_archive( $this->posttype_name )) return $orderby;
			if ( !$query->is_main_query()) return $orderby;
			if ( !is_post_type_archive( $this->posttype_name )) return $orderby;


			
			$orderby = $query->get( 'orderby' );
			$meta_key = $query->get( 'meta_key' );
			$order = $query->get( 'order' );

			if ( isset($this->post_attribute_list[$meta_key])) {

				$opt = $this->post_attribute_list[$meta_key];
				if ( isset($opt['admin_gird_sortable_custom_query'] )) {
					$orderby =  $opt['admin_gird_sortable_custom_query'] . $order;	
				}


			}
			
			return $orderby;
		}


		// for adding customer meta boxs on override
		protected function render_additional_meta_box($p,$args) {

		}
		// for adding js one time
		protected function posttype_before_metaboxes() {

		}
		// for adding things after the meta box
		protected function posttype_after_metaboxes() {

		}
		
		// for adding customer meta boxs on override
		protected function save_additional_posttype_attrs($pid, $p, $post) {

		}
		// for adding customer meta boxs on override
		protected function before_save_additional_posttype_attrs($pid, $p, $post) {

		}

		// for adding customer meta boxs on override
		protected function posttype_additional_metaboxes() {

		}
		// for adding customer meta boxs on override
		protected function custom_column_additional_header($cols) {
			return $cols;
		}
		protected function custom_column_additional_content($cols) {

		}

		protected function set_up_styles_scripts(){

			
		}

		protected function set_up_styles_scripts_base() {
			$this->set_up_styles_scripts();

			$actual_name = $this->class_actual_name;
			
			$class = get_called_class();
			

			$plugin_path = realpath(__DIR__ . "/../");
			$path_exp = explode("/", $plugin_path);
			$plugin_name =  $path_exp[ count($path_exp) - 1];


			$url = $this->get_plugin_uri() ;

	        $path = realpath($this->get_plugin_path() . "/asset/posttypes/$actual_name/");
	       

	        if ( $path ) {
				if ( is_admin() ) {
		           

					if ( file_exists($path. '/admin.css' )) {
						wp_enqueue_style( 
			                $class . '-adminstyles', 
			                "$url/asset/posttypes/$actual_name/admin.css"
			            );
					}
					if ( file_exists($path. '/admin.js' )) {
						wp_enqueue_script( 
			                $class . '-adminscript', 
			                "$url/asset/posttypes/$actual_name/admin.js" 
			            );
					}


		        } else {

		        	if ( file_exists($path. '/front.css' )) {
						wp_enqueue_style( 
			                $class . '-frontstyles', 
			                "$url/asset/posttypes/$actual_name/front.css"
			            );
					}
					if ( file_exists($path. '/front.js' )) {
						wp_enqueue_script( 
			                $class . '-frontscript', 
			                "$url/asset/posttypes/$actual_name/front.js"
			            );
					}

		        }
		    }
		}

	}
}
