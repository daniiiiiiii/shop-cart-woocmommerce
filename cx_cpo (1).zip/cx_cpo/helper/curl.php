<?php

namespace cx_cpo\helper;

if (!class_exists("cx_cpo\\\helper\\curl")) {

	class curl  { 

		public static function post($api_url, $post_data = [] , $header = []) {
			//var_dump($post_data);
			$curl = curl_init($api_url);
			curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, 1);
			curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
			curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
			curl_setopt($curl, CURLOPT_POST, 1);
			curl_setopt($curl, CURLOPT_POSTFIELDS, $post_data);
			curl_setopt($curl, CURLOPT_HTTPHEADER, $header);
			$result = curl_exec($curl); 
			curl_close($curl);
			return $result;

		}
		public static function get($api_url,$header = []) {
			//var_dump($post_data);
			$curl = curl_init($api_url);
			curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, 1);
			curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
			curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
			curl_setopt($curl, CURLOPT_HTTPHEADER, $header);
			//curl_setopt($curl, CURLOPT_POST, 1);
			//curl_setopt($curl, CURLOPT_POSTFIELDS, $post_data);
			$result = curl_exec($curl); 
			curl_close($curl);
			return $result;

			
		}
		
		
	}
}