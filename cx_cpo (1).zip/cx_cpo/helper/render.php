<?php

namespace cx_cpo\helper;

if (!class_exists("cx_cpo\\\helper\\render")) {
	
	class render extends \cx_cpo\cx_base {
		
		// new less code versions
		public function form_field($name,$val = null,$e) {


			$this->render_form_field($name,$val,$e);
		}
		public function table($d, $i = null) {
			if ( is_null($d)) return;
			
			$this->table_render($d , $i);
		}
		public function form($d) {
			if ( is_null($d)) return;
			
			$this->form_render($d);
		}
		public function list($list =[]) {
			if ( is_null($list)) return;

			?><ul class="list-container-ul"><?php 
			foreach ($list as $key => $value) {
				if ( is_array($value)) {
					?><li class="list-item <?= sanitize_title($key) ?> ">
						<strong><?= $this->__($key,"cx") ?>: </strong>
						<div class="inner-list-container"><?php 
							$this->list($value);
						?></div>
					</li><?php 
					
				} else {
					if (strlen($value)) { 
						?><li class="list-item <?= sanitize_title($key) ?> ">
							<strong><?= $this->__($key,"cx") ?>: </strong>
							<span class="<?= sanitize_title($key) ?>-value list-item-value"><?= $this->__($value,"cx") ?></span>
						</li><?php 
					}
				}
				
			}
			?></ul><?php 
		}
		public function tr_list($list) {
			if ( is_null($list)) return;

			foreach ($list as $key => $value) {
				if (strlen($value)) { 
					?><tr class="tr <?= sanitize_title($key) ?> "><th class="th"><?= $this->__($key,"cx") ?>: </th><td class="<?= sanitize_title($key) ?>-value td-value"><?= $this->__($value,"cx") ?></td></tr><?php 
				}
			}

		}

		/**
		 * Return the slug of a string to be used in a URL.
		 *
		 * @return String
		 */
		public function slugify($text){
		    // replace non letter or digits by -
		    $text = preg_replace('~[^\pL\d]+~u', '-', $text);

		    // transliterate
		    $text = iconv('utf-8', 'us-ascii//TRANSLIT', $text);

		    // remove unwanted characters
		    $text = preg_replace('~[^-\w]+~', '', $text);

		    // trim
		    $text = trim($text, '-');

		    // remove duplicated - symbols
		    $text = preg_replace('~-+~', '-', $text);

		    // lowercase
		    $text = strtolower($text);

		    if (empty($text)) {
		      return 'n-a';
		    }

		    return $text;
		}
		public function html_attribute_string($list) {
			$str = "";
			foreach ($list as $key => $value) {
				
				if ( is_numeric($key) ) {
					if ( strlen($value) ) $str .=  addslashes($value) . " ";
					continue; 
				}

				if ( !is_array($value) && !strlen($value) && !is_numeric($key)) {
					if ( strlen($key) ) $str .=  addslashes($key) . " ";
					continue; 
				}


				if ( is_array($value) ) {
					$val_str = "";
					foreach ($value as $k => $v) {
						$val_str .=  addslashes($v) . " ";
					}
				} else {
					$val_str =  addslashes($value);
				}
				$str .= ( $key . '="' . $val_str  . '" ' );
				
			}
			return $str;
		}
		private function add_defaults_to_array( $src , $defaults ) {
			foreach ($defaults as $key => $value) {
				
				if  ( !isset($src[$key]) ) {

					$src[$key] = $value;

				} else {

					if ( is_array($value) || is_array($src[$key]) ) {
						if ( is_array($value) && !is_array($src[$key])) {
							$src[$key] = [$src[$key]];
						}
						if ( !is_array($value) && is_array($src[$key])) {
							$value = [$value];
						}
						$src[$key] = array_merge($value, $src[$key]);
					}
					
					
					

				}
				
				
			}
			return $src;
		}
		public function render_form_field($name = "",$val = null,$e){

			$defaults = [
				"type"	=> "text",
				"placeholder"=> "",
				//"required"=> 0,
				"default"=> "",
				"show_label_as_option" => 0,
				"options_assoc" => 0,
				"show_label" =>1,
				
			];
			$e = $this->add_defaults_to_array($e , $defaults);

			$e["label"] = isset( $e["label"] ) ? $e["label"] : $name;
			$e["value"] =  ( $val ) ? $val : $e["default"];
			if ( is_array($e["value"])) {
				foreach ($e["value"] as $key => $value) {
					$e["value"][$key] = stripcslashes( htmlspecialchars($value));
				}
			} else {
				$e["value"] = stripcslashes( htmlspecialchars($e["value"]));	
			}
			
			// creatng empty array
			$e["attributes"] = isset( $e["attributes"] ) ? $e["attributes"] : [];

			

			$e["wraper_attributes"] = isset( $e["wraper_attributes"] ) ? $e["wraper_attributes"] : [];
			
			// wraper class
			$wraper_attributes_default = [
				"class"=> [ 
					"form-field", 
					"hs-form-field", 
					$this->slugify( $e["label"] ) . "-wraper",
				],

			];

			$attributes_default = [
				"class"=> [
					$e["type"] . "-form-field",
					"hs-form-field-element",
				],
			];


			$e["wraper_attributes"] = $this->add_defaults_to_array($e["wraper_attributes"] , $wraper_attributes_default);
			$e["attributes"] = $this->add_defaults_to_array($e["attributes"] , $attributes_default);

			
			if ( isset($e["required"]) ) { 
				$e["attributes"]["class"][] = "required";
				$e["attributes"]["required"] = "";
			}

			if ( isset($e["multiple"]) ) { 
				$e["attributes"]["multiple"] = 1;
			}

			foreach ($e["attributes"] as $key => $value) {
				if ( $key == "multiple") {
					if ( $value == "true" || $value || intval($value)  ) {
						$name =  $name . "[]";
						break;
					}
				}
				if ( is_numeric($key) && $value == "multiple"  ) {
					$name =  $name . "[]";
					break;
				}
			}
			

			$e["attributes"]["name"] = $name;
			$e["attributes"]["placeholder"] = $this->__($e["placeholder"],"cx");
			
			$e["attributes"]["value"] = $e["value"];


			

			$wraper_attributes_string = $this->html_attribute_string( $e["wraper_attributes"] );
			


			if (  $e["type"] != "hidden" ) {

				?><div <?= $wraper_attributes_string ?> ><?php 
					if ( $e["show_label"] ) {

						?><label><?php 
							echo $this->__($e["label"],"cx");
							if ( $e["required"] ) {
								?><span class="red"> *</span><?php
							}
						 ?></label><?php 
					}	
			}
			?><div class="field-wraper"><?php 
				switch ($e["type"]) {

							case 'custom_html':
								echo $e["html"];
							break;

							case 'textarea':

								unset($e["attributes"]["value"]);

								$attributes_string = $this->html_attribute_string( $e["attributes"] );

								?><textarea <?= $attributes_string ?> ><?php 
									echo $e["value"];

								?></textarea><?php

							break;

							case 'select':
								
								unset($e["attributes"]["value"]);
								
								$attributes_string = $this->html_attribute_string( $e["attributes"] );

								?><select  <?= $attributes_string ?>  ><?php 

									if ( $e["show_label_as_option"]){
										?><option > select <?php echo $this->__($e["label"],"cx") ?></option><?php 
									}
							
									$assoc = ( count(array_filter(array_keys($e["options"]), 'is_string')) || $e["options_assoc"] ) ? 1 : 0;

									foreach ($e["options"] as $k => $v) {

										if ( is_array($v)) {
											?><optgroup label="<?php echo $k; ?>"><?php 

												foreach ($v as $actual_key => $actual_value) {
													$s = "";
													$a_val = ( $assoc ) ? $actual_key : $actual_value;
													if (isset($e["value"])) {

														

														if ( is_array($e["value"]) ) {

															foreach ($e["value"] as $vvv) {
																if ( ($vvv == $a_val ) ) {
																	$s =   "selected";	continue;
																}
															}
														} else {

															$s = ($e["value"] == $a_val)  ? "selected" : "";
															
														}
														
													}
													
													?><option value="<?php echo $a_val ?>" <?php echo $s?> ><?php echo $this->__($actual_value,"cx"); ?></option><?php
												}
											?></optgroup><?php

										} else {

											$s = "";
											$a_val = ( $assoc ) ? $k : $v;

											if (isset($e["value"])) {
												if ( is_array($e["value"]) ) {

													foreach ($e["value"] as $vvv) {
														if ( ($vvv == $a_val ) ) {
															$s =   "selected";	continue;
														}
														
													}
												} else {

													$s = ($e["value"] == $a_val)  ? "selected" : "";
													
												}
												
											}
											
											

											?><option value="<?php echo $a_val ?>" <?php echo $s?> ><?php echo $this->__($v,"cx"); ?></option><?php 
										}
									}
								?></select><?php
							break;

							case 'checkbox':

								
								$id = isset($e["attributes"]["id"]) ? $e["attributes"]["id"] : "from-checkbox-" .  $this->slugify($name);

								?><ul class="checkbox-container" id="<?= $id ?>"><?php 

									$value_set = $e["value"];
									if ( !is_array($value_set)) {
										$value_set = [$value_set];
									}
									$value_set =array_map("strval", $value_set);
									

									foreach ($e["options"] as $key => $val) {
										
										$attr = $e["attributes"];

										$value = "";
										$label = "";
										

										if ( $e["options_assoc"] ) {
											$value = $key;
											
										} else {
											$value = $val;

										}
										
										
										$label = $val;
										$attr ["value"] = $value;
										$attr ["type"] = "checkbox";
										unset($attr ["checked"]);

										if (   in_array(strval($value), $value_set)) {
											$attr ["checked"] ="checked";
										}
										
										$attr ["id"] = $this->slugify(
												"form-elem-" . $attr ["name"] . $attr ["value"] );
										
										if ( isset($e["options_attributes"])) {
											if (  isset($e["options_attributes"][$value]) ) {
												$opt_attrs = $e["options_attributes"][$value];
												if ( is_array($opt_attrs)) {
													$attr  = array_merge( $attr  , $opt_attrs );
												}
												
											}

										}
										$attributes_string = $this->html_attribute_string( $attr  );
										?><li>
											<input <?= $attributes_string ?> >
											<label for="<?= $attr["id"] ?>"><?php echo $this->__($label,"cx"); ?></label>
										</li><?php
									}
								?></ul><?php
							break;

							case 'radio':
								$id = ($e["attributes"]["id"]);
								$id = isset($id) ? $id : "from-radio-" .  $this->slugify($name);

								?><ul class="radio-container" id="<?= $id ?>"><?php 

									$value_set = [$e["value"]];
									
									

									foreach ($e["options"] as $key => $val) {
										$attr = $e["attributes"];

										$value = "";
										$label = "";
										$checked = "";
										if ( $e["options_assoc"] ) {
											$value = $key;
											
										} else {
											$value = $val;

										}
										unset($attr["checked"]);
										if ( in_array($value, $value_set)) {
											$attr["checked"] = "checked";
										} 
										
										$label = $val;
										$attr["value"] = $value;
										$attr["type"] = "radio";
										
										

										
										$attr["id"] = $this->slugify(
												"form-elem-" . $attr["name"] . $attr["value"] );
										
										if ( isset($e["options_attributes"])) {
											if (  isset($e["options_attributes"][$value]) ) {
												$opt_attrs = $e["options_attributes"][$value];
												if ( is_array($opt_attrs)) {
													$attr = array_merge( $attr , $opt_attrs );
												}
												
											}

										}
										$attributes_string = $this->html_attribute_string( $attr );
										?><li>
											<input <?= $attributes_string ?> >
											<label for="<?= $attr["id"] ?>"><?php echo $this->__($label,"cx"); ?></label>
										</li><?php

									}
								?></ul><?php
							break;


							
							default:
								
								$e["attributes"]["value"] = $e["value"];
								$e["attributes"]["type"] = $e["type"];

								$attributes_string = $this->html_attribute_string( $e["attributes"] );

								?><input  <?= $attributes_string ?> /><?php 
								
							break;
				}
				
				if ( isset($e["comment"])) {
					?><span class="comment"><i class="icon-info info"></i><span><?= $this->__($e["comment"],"cx") ?></span></span><?php
				}

				if (isset($e["after"]) ) {
					echo $e["after"];

				}
			?></div><?php
			if ( $e["type"] != "hidden" ) {
				?></div><?php 
			}

		}
		// render form 

		// render table
		private function print_vell_value($val , $k , $row , $inst = null) {
			if ( $inst ) {
				$method =  'cell_render_' . $k;
				if ( method_exists($inst, $method )) {
					$val = $inst->$method($val , $row , $k );
					
				}
			} 
			echo $val;	
			
			
		}
		public function table_render($d, $inst = null) {

			$d["fieldSet_type"] = ( is_array($d["fieldSet"][0]) ) ?  "array" : "object";
			
			$total = 0;
			?><div class="search-list"><?php
				?><table class="box"><?php
				?><thead><?php
						foreach ( $d["fieldNames"] as $k => $value) {
							$colname =  ( isset($value["label"])) ? $value["label"] : $k
							
							?><th><?php echo $this->__($colname,"cx"); ?></th><?php
						}
					?></thead><?php
					?><tbody><?php
						$rownumber = 0;
						foreach ($d["fieldSet"] as $k => $row) {

							?><tr><?php
							foreach ( $d["fieldNames"] as $k => $v) {

								$v["type"] = (!isset($v["type"])) ? "text" : $v["type"];
								$v["type"] = (isset($v["index"])) ? "index" : $v["type"];
								
								?><td><?php
								//var_dump($v["type"]);

								switch ($v["type"]) {
										case 'index':
											$val =   ( $d["fieldSet_type"]  == "array" )  ? $row[$v["index"]] :  $row->{$v["index"]}; 
											$this->print_vell_value($val , $k , $row , $inst);
											
											break;
										case 'subsitute':
											
											$f = $v["field"];
											$key = ( $d["fieldSet_type"]  == "array" )  ? $row[$f] :  $row->{$f}; 
											// var_dump($key);
											// var_dump($v["values"]);
											$val = $v["values"][$key];
											$this->print_vell_value($val , $k , $row , $inst);
											break;

										case 'text':

											$val = cx_string_parser( $v["value"] ,  $row );
											$this->print_vell_value( $val , $k , $row , $inst);
											break;
										/* 
										case 'eval':
										case 'function':

										*/	
										default:
											$val = cx_string_parser( $v["value"] ,  $row );
											$this->print_vell_value( $val , $k , $row , $inst);
											break;
									}
								?></td><?php		
								
								
							}
							if ( isset($d["total"]["index"])) $total = $total + intval( ( $d["fieldSet_type"]  == "array" )  ? $row[$d["total"]["index"]] :  $row->{$d["total"]["index"]} );
							?></tr><?php
							$rownumber++;
						}
						
					?></tbody><?php
					?><tfoot><?php
						
						if ( isset($d["total"]["index"])) {
							?><tr><?php
							
								?><td> <?= $this->__("total","cx") ?> <?php
									echo $d["total"]["index"] . "  :  ";
									echo $total;
								?></td><?php
								
							?></tr><?php
						}
						
					?></tfoot><?php

				?></table><?php
				?><div><?php
							
					?><p><?php
						echo   $this->__("total rows  :  ","cx") . $rownumber;
						
					?></p><?php
					
				?></div><?php
			?></div><?php

		}
		public function form_render($d) {

			// $ci =& get_instance();

			$defaults = [
				"render_groups"=>1,
				"method"=>"get",
				"enctype"=>"application/x-www-form-urlencoded",
				"show_label"=>1,
				'action'=> '',
			];
			$d = $this->add_defaults_to_array($d, $defaults);
			

			?><form action="#" method="<?php echo $d["method"]; ?>" class="form hs-form cx-render-form " id="form-action-<?php echo $d["action"]; ?>" 
				enctype="<?php echo $d["enctype"]; ?>"><?php 
				

				$d["submit"] = isset( $d["submit"] ) ? $d["submit"] : array("value" => "Submit", "attributes"=>array());
				$d["submit"]["value"] = isset( $d["submit"]["value"] ) ? $d["submit"]["value"] : "Submit";
				$d["submit"]["attributes"] = isset( $d["submit"]["attributes"] ) ? $d["submit"]["attributes"] : array();
				// proprocessing attrs

				$sections = [];
				$hiddens = [];
				
				$d["elements"] = count($d["elements"]) ? $d["elements"] : [];

				foreach ($d["elements"] as $name => $e) { 
					
					$d["elements"][$name]["value"] = (isset($e["value"])) ? $e["value"] : null;
					$d["elements"][$name]["type"] = (isset($e["type"])) ? $e["type"] : "text";
					$e = $d["elements"][$name];
					
					if ( $d["show_label"] == 0 && !isset($e["show_label"])) {
						$e["show_label"] = 0;
					}
					if ( $d["render_groups"] ) {

						if ( $e["type"] == "hidden" ) {
							
							$hiddens[$name] = $e;
						
						} else {
							$e["group"] = (isset($e["group"])) ? $e["group"] : "general";
							if ( !isset( $sections[$e["group"]] ) ) $sections[ $e["group"] ] = [];
							$sections[ $e["group"] ][$name] = $e;
						}

						
					}
				}


				if ( !$d["render_groups"] ) {
					foreach ($d["elements"] as $name => $e) {
						// show label or not
						$this->render_form_field($name, $e["value"] ,$e);
					
					}
				} else {

					foreach ($sections as $key => $attrs) {
						?><section class='form-section <?= $this->slugify( $key ) ?>'>
							<header><?= $this->__($key,"cx") ?></header>
							<div class="section-attribute"><?php 

								foreach ($attrs as $name => $e) {
									$this->render_form_field($name, $e["value"] ,$e);
								}

							?></div>
						</section><?php
					}
					?><div class='hidden-fields'><?php 

						foreach ($hiddens as $name => $e) {
							$this->render_form_field($name, $e["value"] ,$e);
						}

					?></div><?php

				}
				if ( isset($d["submit"]) ) {
				    if ( isset($d["submit"]["custom_html"]) ) {
				        echo $d["submit"]["custom_html"];
				    } else {
				        $attrs = $d["submit"]["attributes"];
        				$attrs = ( count($attrs)) ? $attrs : [];
        				$attrs["type"] = "submit";
        				$attrs["value"] = ( isset($d["submit"]["value"]) ) ? $d["submit"]["value"] : "submit";
        				
        
        				$attributes_string = $this->html_attribute_string( $attrs );

				        ?><input <?= $attributes_string ?> /><?php
				    }
				}

			?></form><?php
		}
		
	}
}
