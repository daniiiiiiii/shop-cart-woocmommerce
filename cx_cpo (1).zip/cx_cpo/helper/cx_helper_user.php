<?php

if (!class_exists("cx_helper_user")) {

	class cx_helper_user  {

		protected $user_id = null;
		protected $userdata = null;


		public function __construct() {

			if ( get_current_user_id() ) {

				$this->user_id = get_current_user_id();
				$this->userdata = get_userdata( $this->user_id );
			}
			
		}
		public function get_userdata() {
			return $this->userdata;
		} 
		public function has_role($id,$role) {
			$admin_ids = [];
			$administrator = get_users([
				'role'=> [$role],
				"fields"=>["id"],
			]);
			foreach ($administrator as $a) {
				if ( strval($a->id) == strval($id)  ){
					return 1;
				}
			}
			return 0;
		}
		public function is_admin($id) {
			return $this->has_role($id ,'administrator' );
		}
		public function get_users_as_options($args,$feild = "user_login" ) {
			$args = !isset($args) ? [] : $args;

			$users = get_users($args);
			$return_data = [];
			foreach ($users as $u) {
				$return_data[$u->ID] = $u->{$feild} ;
			}
			return $return_data;
		}

	}

}