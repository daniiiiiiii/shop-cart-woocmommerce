<?php

if ( !function_exists("to_array")) {
	function to_array($d) {
		return json_decode(json_encode($d), true);
	}
}

if ( !function_exists("string_formater")) {
	function string_formater( $text , $data) {
		
		$matches = array();
		preg_match_all( '/\{(.*?)\}/i' ,  $text , $matches );
		foreach ($matches[1] as  $v) {
			
			if ( strpos($v, "function_") !== FALSE ) {

				$m = array();
				preg_match_all( '/\((.*?)\)/i' ,  $v , $m );

				$val = isset($data[$m[1][0]]) ? $data[$m[1][0]] : $m[1][0];
				$f = str_replace("function_", "", $v);
				$f = substr($f, 0 , strpos($f, "("));
				if ( function_exists( $f ) ) $text_formated = $f( $val );

				$text = str_replace( "{".$v."}" , $text_formated , $text);

			} else {
				if ( is_object($data)  ){
					if ( isset($data->$v ) ) $text = str_replace( "{".$v."}" , $data->$v , $text);	
				} else {
					if ( isset($data[$v]) ) $text = str_replace( "{".$v."}" , $data[$v] , $text);	
				}
				
			}
			
		}
		return $text;
	}
}
if ( !function_exists("string_formater")) {
	function sanatize_string($str) {
		return strtolower( str_replace(" ", "-", $str) );
	}
}
if ( !function_exists("math_eval")) {
	function math_eval($ma) {
		$Cal = new cx_field_calculate();
		return $Cal->calculate($ma);
	}
}
if (!class_exists("cx_field_calculate")) {
	class cx_field_calculate {
	    const PATTERN = '/(?:\-?\d+(?:\.?\d+)?[\+\-\*\/])+\-?\d+(?:\.?\d+)?/';

	    const PARENTHESIS_DEPTH = 10;

	    public function calculate($input){
	        if(strpos($input, '+') != null || strpos($input, '-') != null || strpos($input, '/') != null || strpos($input, '*') != null){
	            //  Remove white spaces and invalid math chars
	            $input = str_replace(',', '.', $input);
	            $input = preg_replace('[^0-9\.\+\-\*\/\(\)]', '', $input);

	            //  Calculate each of the parenthesis from the top
	            $i = 0;
	            while(strpos($input, '(') || strpos($input, ')')){
	                $input = preg_replace_callback('/\(([^\(\)]+)\)/', 'self::callback', $input);

	                $i++;
	                if($i > self::PARENTHESIS_DEPTH){
	                    break;
	                }
	            }

	            //  Calculate the result
	            if(preg_match(self::PATTERN, $input, $match)){
	                return $this->compute($match[0]);
	            }

	            return 0;
	        }

	        return $input;
	    }

	    private function compute($input){
	        $compute = create_function('', 'return '.$input.';');

	        return 0 + $compute();
	    }

	    private function callback($input){
	        if(is_numeric($input[1])){
	            return $input[1];
	        }
	        elseif(preg_match(self::PATTERN, $input[1], $match)){
	            return $this->compute($match[0]);
	        }

	        return 0;
	    }
	}
}



if ( !function_exists("is_assoc")) {
	function is_assoc($array){
	   $keys = array_keys($array);
	   return $keys !== array_keys($keys);
	}
}

if ( !function_exists("genrate_random_alphanumeric_key")) {
	function genrate_random_alphanumeric_key($k = 16) {
		$grammer = 'abcdefghijklmnopqrstuvwxyz0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ';
		$max = strlen($grammer) - 1;
		$str = "";
		for ($i=0; $i < $k; $i++) { 
			$str .= $grammer[mt_rand(0, $max)];
		}
		return $str;
	}
}

